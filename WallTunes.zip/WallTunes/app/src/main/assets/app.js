/* ==========================================================================
   WallTunes — phone app

   Talks to the little server running on the TV. Two rules throughout:

   1. Buttons react immediately and reconcile afterwards. The TV is one hop
      away on a home network, but "one hop" still means a visible pause if
      you wait for it before redrawing.
   2. Nothing that changes state happens without the PIN. Reading does not
      need it, so the page renders before you have typed anything.
   ========================================================================== */

const $ = (id) => document.getElementById(id);

let state = { songs: [], library: [], upNext: [], playing: false, shuffle: true };
let playlists = [];
let favourites = new Set();
let filter = '';
let sortBy = localStorage.getItem('wt-sort') || 'title';
let gridView = localStorage.getItem('wt-view') !== 'list';
let seeking = false;           // do not fight the user's thumb
let pin = localStorage.getItem('wt-pin') || '';

/* ---------------------------------------------------------------- PIN */

const withPin = (url) => url + (url.includes('?') ? '&' : '?') + 'pin=' + encodeURIComponent(pin);

async function post(url) {
  const r = await fetch(withPin(url), { method: 'POST' });
  if (r.status === 401) { lockOut(); throw new Error('pin'); }
  if (!r.ok) {
    let msg = 'That did not work.';
    try { msg = (await r.text()) || msg; } catch (e) {}
    throw new Error(msg);
  }
  return r;
}

/** Fire and forget, but surface a real reason if it fails. */
function send(url, okMsg) {
  post(url).then(() => { if (okMsg) toast(okMsg); refresh(); })
           .catch((e) => { if (e.message !== 'pin') toast(e.message); refresh(); });
}

function lockOut() {
  pin = '';
  localStorage.removeItem('wt-pin');
  $('app').hidden = true;
  $('gate').hidden = false;
  $('pinInput').value = '';
}

function unlock() { $('gate').hidden = true; $('app').hidden = false; }

$('pinInput').addEventListener('input', async (e) => {
  const v = e.target.value.replace(/[^0-9]/g, '');
  e.target.value = v;
  $('pinErr').hidden = true;
  if (v.length !== 4) return;
  try {
    const r = await fetch('/api/verify?pin=' + encodeURIComponent(v), { method: 'POST' });
    if (!r.ok) throw new Error();
    pin = v;
    localStorage.setItem('wt-pin', v);
    unlock(); refresh(); loadPlaylists();
  } catch (err) {
    $('pinErr').hidden = false;
    e.target.value = '';
  }
});

/* ------------------------------------------------------------- Helpers */

const clean = (n) => n.replace(/\.[^.]+$/, '');
const artUrl = (n) => '/api/art?name=' + encodeURIComponent(n);

function time(ms) {
  if (!ms || ms < 0) return '0:00';
  const s = Math.round(ms / 1000);
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

let toastTimer;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

/** An <img> that quietly becomes a note when the song has no cover. */
function cover(song, cls) {
  const img = document.createElement('img');
  img.loading = 'lazy';
  img.className = cls || '';
  img.alt = '';
  img.src = artUrl(song);
  img.onerror = () => {
    const ph = document.createElement('div');
    ph.className = 'none ' + (cls || '');
    ph.textContent = '♪';
    img.replaceWith(ph);
  };
  return img;
}

/* ----------------------------------------------------------------- Tabs */

const TABS = ['now', 'lib', 'queue', 'pl'];
function showTab(which) {
  for (const t of TABS) {
    $('tab-' + t).setAttribute('aria-selected', String(t === which));
    $('p-' + t).hidden = t !== which;
  }
}
TABS.forEach((t) => { $('tab-' + t).onclick = () => showTab(t); });

/* ------------------------------------------------------------- Polling */

/**
 * Take a state payload from either transport and redraw.
 *
 * positionAt records when it arrived, so the seek bar can be advanced
 * locally between updates. That is what lets the server stay quiet: it only
 * speaks when something actually changes, and the phone fills in the
 * seconds by itself.
 */
function applyState(next) {
  state = next;
  state.positionAt = Date.now();
  $('offline').hidden = true;
  renderNow();
  renderLibrary();
  renderQueue();
}

/** Live position, extrapolated since the last update. */
function livePosition() {
  const base = state.position || 0;
  if (!state.playing || !state.positionAt) return base;
  return Math.min(base + (Date.now() - state.positionAt), state.duration || Infinity);
}

async function refresh() {
  try {
    const r = await fetch('/api/state', { cache: 'no-store' });
    applyState(await r.json());
  } catch (e) {
    $('offline').hidden = false;
  }
}

/* ------------------------------------------------------------- Events */

let events = null;
let pollTimer = null;

function startPolling(ms) {
  clearInterval(pollTimer);
  pollTimer = setInterval(refresh, ms);
}

/**
 * Prefer SSE, fall back to polling.
 *
 * The fallback is not decoration: EventSource is unavailable in a few older
 * mobile browsers, and a proxy or a sleeping phone can kill the connection.
 * Polling continues underneath at a much slower rate so a dropped feed
 * degrades to "slightly stale" rather than "frozen".
 */
function connectEvents() {
  if (!('EventSource' in window)) { startPolling(3000); return; }
  try {
    events = new EventSource('/api/events');

    events.onmessage = (e) => {
      try { applyState(JSON.parse(e.data)); } catch (err) {}
    };

    events.onopen = () => { startPolling(30000); };

    events.onerror = () => {
      // EventSource retries on its own, but if the TV went away entirely
      // that retry loop is silent, so polling picks up the slack.
      $('offline').hidden = false;
      startPolling(3000);
    };
  } catch (e) {
    startPolling(3000);
  }
}

async function loadPlaylists() {
  try {
    const r = await fetch('/api/playlists', { cache: 'no-store' });
    const d = await r.json();
    playlists = d.playlists || [];
    favourites = new Set(d.favourites || []);
    renderPlaylists();
    renderNow();
  } catch (e) { /* the offline banner covers this */ }
}

/* ------------------------------------------------------- Now playing */

let lastArtSong = null;

function renderNow() {
  const has = (state.songs || []).length > 0;
  $('npTitle').textContent = has ? (state.title || 'Starting up') : 'Nothing playing yet';
  $('npArtist').textContent = has ? (state.artist || '') : 'Add some songs from the Library tab.';
  $('playIcon').setAttribute('d', state.playing ? 'M6 5h4v14H6zM14 5h4v14h-4z' : 'M8 5v14l11-7z');
  $('shuffle').setAttribute('aria-pressed', String(!!state.shuffle));

  const cur = state.current;
  $('favourite').setAttribute('aria-pressed', String(cur ? favourites.has(cur) : false));

  // Only rebuild the artwork when the song actually changes, or the image
  // flickers every three seconds.
  if (cur !== lastArtSong) {
    lastArtSong = cur;
    const wrap = document.querySelector('.art-wrap');
    wrap.innerHTML = '';
    if (cur) wrap.appendChild(cover(cur));
    else {
      const ph = document.createElement('div');
      ph.className = 'none'; ph.textContent = '♪';
      wrap.appendChild(ph);
    }
  }

  const dur = state.duration || 0;
  const pos = livePosition();
  if (!seeking) {
    $('seek').value = dur > 0 ? Math.round((pos / dur) * 1000) : 0;
  }
  $('tElapsed').textContent = time(pos);
  $('tDuration').textContent = dur > 0 ? time(dur) : '';

  if (document.activeElement !== $('vol') && typeof state.volume === 'number') {
    $('vol').value = state.volume;
  }
}

$('toggle').onclick = () => {
  // Flip the icon now; the poll will confirm.
  state.playing = !state.playing;
  renderNow();
  send('/api/control?action=toggle');
};
$('prev').onclick = () => send('/api/control?action=prev');
$('next').onclick = () => send('/api/control?action=next');
$('shuffle').onclick = () => {
  state.shuffle = !state.shuffle;
  renderNow();
  send('/api/control?action=shuffle');
};
$('favourite').onclick = () => {
  const cur = state.current;
  if (!cur) return;
  if (favourites.has(cur)) favourites.delete(cur); else favourites.add(cur);
  renderNow();
  post('/api/favourite?name=' + encodeURIComponent(cur)).then(loadPlaylists).catch(() => {});
};

$('seek').addEventListener('input', () => { seeking = true; });
$('seek').addEventListener('change', (e) => {
  const dur = state.duration || 0;
  seeking = false;
  if (dur > 0) send('/api/control?action=seek&name=' + Math.round((e.target.value / 1000) * dur));
});

let volTimer;
$('vol').addEventListener('input', (e) => {
  // Dragging fires constantly; only the resting value is worth sending.
  clearTimeout(volTimer);
  const v = e.target.value;
  volTimer = setTimeout(() => post('/api/settings?' +
    (state.isNight ? 'nightVolume' : 'dayVolume') + '=' + v).catch(() => {}), 220);
});

/* ----------------------------------------------------------- Library */

function libraryRows() {
  const rows = (state.library && state.library.length)
    ? state.library.slice()
    : (state.songs || []).map((n) => ({ name: n, title: clean(n), artist: '', duration: 0, added: 0 }));

  const by = {
    title: (a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }),
    artist: (a, b) => (a.artist || '~').localeCompare(b.artist || '~', undefined, { sensitivity: 'base' }),
    added: (a, b) => (b.added || 0) - (a.added || 0),
    plays: (a, b) => (b.plays || 0) - (a.plays || 0),
  }[sortBy];

  const f = filter.toLowerCase();
  return rows
    .filter((r) => !f || r.title.toLowerCase().includes(f) || (r.artist || '').toLowerCase().includes(f))
    .sort(by);
}

function renderLibrary() {
  const body = $('libBody');
  const rows = libraryRows();
  const total = (state.library || state.songs || []).length;

  body.innerHTML = '';

  if (!total) {
    body.innerHTML =
      '<div class="empty"><b>No songs yet</b>Tap "Add songs" to send music to the TV.</div>';
    return;
  }
  if (!rows.length) {
    body.innerHTML = '<div class="empty"><b>Nothing matches</b>Try a different search.</div>';
    return;
  }

  if (gridView) {
    const grid = document.createElement('div');
    grid.className = 'grid';
    for (const r of rows) {
      const cell = document.createElement('button');
      cell.className = 'cell' + (r.name === state.current ? ' on' : '');
      cell.appendChild(cover(r.name));
      const b = document.createElement('b'); b.textContent = r.title;
      const s = document.createElement('span'); s.textContent = r.artist || '';
      cell.append(b, s);
      cell.onclick = () => send('/api/control?action=play&name=' + encodeURIComponent(r.name));
      cell.oncontextmenu = (e) => { e.preventDefault(); songSheet(r); };
      grid.appendChild(cell);
    }
    body.appendChild(grid);
  } else {
    const ul = document.createElement('ul');
    ul.className = 'rows';
    for (const r of rows) {
      const li = document.createElement('li');
      if (r.name === state.current) li.className = 'on';
      li.appendChild(cover(r.name));

      const meta = document.createElement('button');
      meta.className = 'meta';
      const b = document.createElement('b'); b.textContent = r.title;
      const s = document.createElement('span');
      s.textContent = [r.artist, r.duration ? time(r.duration) : ''].filter(Boolean).join('  ·  ');
      meta.append(b, s);
      meta.onclick = () => send('/api/control?action=play&name=' + encodeURIComponent(r.name));

      const more = document.createElement('button');
      more.className = 'more';
      more.setAttribute('aria-label', 'More options for ' + r.title);
      more.textContent = '⋯';
      more.onclick = () => songSheet(r);

      li.append(meta, more);
      ul.appendChild(li);
    }
    body.appendChild(ul);
  }
}

$('search').oninput = (e) => { filter = e.target.value; renderLibrary(); };
$('sort').value = sortBy;
$('sort').onchange = (e) => {
  sortBy = e.target.value;
  localStorage.setItem('wt-sort', sortBy);
  renderLibrary();
};
$('viewToggle').onclick = () => {
  gridView = !gridView;
  localStorage.setItem('wt-view', gridView ? 'grid' : 'list');
  renderLibrary();
};

/* ------------------------------------------------------------- Sheets */

function openSheet(build) {
  const sheet = $('sheet');
  sheet.innerHTML = '';
  build(sheet);
  sheet.classList.add('open');
  $('scrim').classList.add('open');
}
function closeSheet() {
  $('sheet').classList.remove('open');
  $('scrim').classList.remove('open');
}
$('scrim').onclick = closeSheet;

function sheetRow(parent, label, fn, danger) {
  const b = document.createElement('button');
  b.className = 'row' + (danger ? ' danger' : '');
  b.textContent = label;
  b.onclick = () => { closeSheet(); fn(); };
  parent.appendChild(b);
}

function songSheet(row) {
  openSheet((s) => {
    const h = document.createElement('h2'); h.textContent = row.title;
    const p = document.createElement('p'); p.className = 'sub'; p.textContent = row.artist || '';
    s.append(h, p);

    sheetRow(s, 'Play now', () =>
      send('/api/control?action=play&name=' + encodeURIComponent(row.name)));
    sheetRow(s, 'Play next', () =>
      send('/api/queue/next?name=' + encodeURIComponent(row.name), 'Playing next'));
    sheetRow(s, 'Add to Up Next', () =>
      send('/api/queue/add?name=' + encodeURIComponent(row.name), 'Added to Up Next'));

    if (playlists.length) {
      for (const pl of playlists) {
        sheetRow(s, 'Add to "' + pl.name + '"', () =>
          send('/api/playlist/add?id=' + encodeURIComponent(pl.id) +
               '&name=' + encodeURIComponent(row.name), 'Added to ' + pl.name));
      }
    }

    sheetRow(s, 'Delete from the TV', () => {
      if (confirm('Delete ' + row.title + ' from the TV? This cannot be undone.')) {
        send('/api/delete?name=' + encodeURIComponent(row.name), 'Deleted');
      }
    }, true);
  });
}

/* ------------------------------------------------------------ Up Next */

function renderQueue() {
  const body = $('queueBody');
  const q = state.upNext || [];
  body.innerHTML = '';

  if (!q.length) {
    body.innerHTML =
      '<div class="empty"><b>Nothing queued</b>Use the ⋯ menu on a song, or hold OK on the TV remote.</div>';
    return;
  }

  const clear = document.createElement('button');
  clear.className = 'pill';
  clear.style.cssText = 'width:100%;margin:10px 0 14px';
  clear.textContent = 'Clear Up Next';
  clear.onclick = () => send('/api/queue/clear', 'Cleared');
  body.appendChild(clear);

  const ul = document.createElement('ul');
  ul.className = 'queue';
  q.forEach((name, i) => {
    const li = document.createElement('li');
    li.draggable = true;
    li.dataset.index = String(i);

    const grip = document.createElement('div');
    grip.className = 'grip';
    grip.textContent = '≡';

    const meta = document.createElement('div');
    meta.className = 'meta';
    const b = document.createElement('b'); b.textContent = clean(name);
    meta.appendChild(b);

    const rm = document.createElement('button');
    rm.className = 'more';
    rm.setAttribute('aria-label', 'Remove ' + clean(name));
    rm.textContent = '×';
    rm.onclick = () => send('/api/queue/remove?name=' + encodeURIComponent(name));

    li.append(grip, meta, rm);
    wireDrag(li, ul, q);
    ul.appendChild(li);
  });
  body.appendChild(ul);
}

/**
 * Drag to reorder.
 *
 * Reordering is done by replaying it as remove-then-reinsert through the
 * queue endpoints, because the server owns the order and the phone is only
 * ever a view of it.
 */
function wireDrag(li, ul, names) {
  li.addEventListener('dragstart', (e) => {
    li.classList.add('dragging');
    e.dataTransfer.setData('text/plain', li.dataset.index);
  });
  li.addEventListener('dragend', () => li.classList.remove('dragging'));
  li.addEventListener('dragover', (e) => { e.preventDefault(); li.classList.add('over'); });
  li.addEventListener('dragleave', () => li.classList.remove('over'));
  li.addEventListener('drop', (e) => {
    e.preventDefault();
    li.classList.remove('over');
    const from = parseInt(e.dataTransfer.getData('text/plain'), 10);
    const to = parseInt(li.dataset.index, 10);
    if (isNaN(from) || isNaN(to) || from === to) return;

    const next = names.slice();
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);

    // Optimistic: show the new order at once, then rebuild it on the TV.
    state.upNext = next;
    renderQueue();
    rebuildQueue(next);
  });
}

async function rebuildQueue(order) {
  try {
    await post('/api/queue/clear');
    for (const n of order) await post('/api/queue/add?name=' + encodeURIComponent(n));
    refresh();
  } catch (e) {
    if (e.message !== 'pin') toast('Could not reorder');
    refresh();
  }
}

/* --------------------------------------------------------- Playlists */

function renderPlaylists() {
  const body = $('plBody');
  body.innerHTML = '';

  if (!playlists.length) {
    body.innerHTML =
      '<div class="empty"><b>No playlists yet</b>Make one, then add songs from the ⋯ menu.</div>';
    return;
  }

  const ul = document.createElement('ul');
  ul.className = 'pl';
  for (const pl of playlists) {
    const li = document.createElement('li');

    const meta = document.createElement('button');
    meta.className = 'meta';
    const b = document.createElement('b'); b.textContent = pl.name;
    const s = document.createElement('span');
    s.textContent = pl.count === 1 ? '1 song' : pl.count + ' songs';
    meta.append(b, s);
    meta.onclick = () => {
      if (!pl.count) { toast('That playlist is empty'); return; }
      send('/api/playlist/play?id=' + encodeURIComponent(pl.id), 'Playing ' + pl.name);
    };

    const more = document.createElement('button');
    more.className = 'more';
    more.setAttribute('aria-label', 'Options for ' + pl.name);
    more.textContent = '⋯';
    more.onclick = () => playlistSheet(pl);

    li.append(meta, more);
    ul.appendChild(li);
  }
  body.appendChild(ul);
}

function playlistSheet(pl) {
  openSheet((s) => {
    const h = document.createElement('h2'); h.textContent = pl.name;
    const p = document.createElement('p'); p.className = 'sub';
    p.textContent = pl.count === 1 ? '1 song' : pl.count + ' songs';
    s.append(h, p);

    sheetRow(s, 'Play', () => {
      if (!pl.count) { toast('That playlist is empty'); return; }
      send('/api/playlist/play?id=' + encodeURIComponent(pl.id), 'Playing ' + pl.name);
    });
    sheetRow(s, 'Rename', () => {
      const name = prompt('Rename playlist', pl.name);
      if (name && name.trim()) {
        post('/api/playlist/rename?id=' + encodeURIComponent(pl.id) +
             '&name=' + encodeURIComponent(name.trim()))
          .then(loadPlaylists).catch(() => toast('Could not rename'));
      }
    });
    sheetRow(s, 'Delete playlist', () => {
      if (confirm('Delete "' + pl.name + '"? The songs stay on the TV.')) {
        post('/api/playlist/delete?id=' + encodeURIComponent(pl.id))
          .then(loadPlaylists).catch(() => toast('Could not delete'));
      }
    }, true);
  });
}

$('newList').onclick = () => {
  const name = prompt('Name this playlist');
  if (!name || !name.trim()) return;
  post('/api/playlist/create?name=' + encodeURIComponent(name.trim()))
    .then(() => { toast('Created'); loadPlaylists(); })
    .catch(() => toast('Could not create that'));
};

/* --------------------------------------------------------- Uploading */

/**
 * Chunked, resumable, two at a time.
 *
 * A single POST of a 40MB file is all-or-nothing: lose wifi at 90% and the
 * whole thing starts again. Sending it in pieces means a hiccup costs one
 * chunk, and the TV is asked where to resume rather than being told.
 *
 * Two concurrent files, not more: the TV is a streaming stick writing to
 * slow internal storage, and beyond two everything simply gets slower
 * together.
 */
const CHUNK = 512 * 1024;
const LANES = 2;
const RETRIES = 3;

let pending = [];          // files waiting for a lane
let active = 0;            // lanes currently busy
let done = 0, total = 0;   // for the tray
let dupChoice = null;

function uploadAll(files) {
  const ok = files.filter((f) => /\.(mp3|m4a|aac|flac|ogg|oga|opus|wav|lrc)$/i.test(f.name));
  const skipped = files.length - ok.length;
  if (skipped > 0) toast(skipped + (skipped === 1 ? ' file was' : ' files were') + ' not music, skipped');
  if (!ok.length) return;

  dupChoice = null;
  pending = pending.concat(ok);
  total += ok.length;
  pump();
}

function pump() {
  while (active < LANES && pending.length) {
    active++;
    sendFile(pending.shift())
      .catch(() => {})
      .then(() => {
        active--;
        done++;
        tray();
        if (pending.length) pump();
        else if (active === 0) finishTray();
      });
  }
  tray();
}

function tray() {
  const t = $('tray');
  if (!pending.length && active === 0) return;
  t.hidden = false;
  const left = pending.length + active;
  $('trayText').textContent =
    left === 1 ? 'Sending 1 file' : 'Sending ' + left + ' files';
}

function finishTray() {
  $('tray').hidden = true;
  $('trayBar').style.width = '0%';
  done = 0; total = 0;
  refresh();
}

function setBar(pct) { $('trayBar').style.width = pct + '%'; }

/** Ask the TV how much of this file it already has. */
async function resumeOffset(file) {
  try {
    const r = await fetch('/api/upload/status?name=' + encodeURIComponent(file.name) +
                          '&size=' + file.size, { cache: 'no-store' });
    if (!r.ok) return 0;
    return (await r.json()).offset || 0;
  } catch (e) {
    return 0;
  }
}

async function sendFile(file, replace) {
  let offset = await resumeOffset(file);
  if (offset > 0 && offset < file.size) {
    toast('Resuming ' + file.name);
  }

  let tries = 0;
  while (offset < file.size) {
    const end = Math.min(offset + CHUNK, file.size);
    let res;
    try {
      res = await putChunk(file, offset, end, replace);
    } catch (e) {
      // A dropped connection is expected, not exceptional. Back off a
      // little, re-ask where we are, and carry on.
      if (++tries > RETRIES) { toast('Gave up on ' + file.name); return; }
      await new Promise((r) => setTimeout(r, 400 * tries));
      offset = await resumeOffset(file);
      continue;
    }

    if (res.status === 401) { lockOut(); pending = []; return; }

    if (res.status === 409) {
      const body = res.body || {};
      if (body.error === 'offset') {
        // The TV and the phone disagreed about progress. It wins.
        offset = body.offset || 0;
        continue;
      }
      // Duplicate. Ask once, then apply the same answer to the batch.
      if (dupChoice === null) {
        dupChoice = confirm(
          (body.existing || file.name) + ' is already on the TV.' +
          '\n\nOK replaces duplicates in this batch.' +
          '\nCancel skips them.'
        ) ? 'replace' : 'skip';
      }
      if (dupChoice === 'replace') return sendFile(file, true);
      toast('Skipped ' + file.name);
      return;
    }

    if (!res.ok) { toast(res.text || ('Could not send ' + file.name)); return; }

    tries = 0;
    offset = res.body.offset;
    setBar(Math.round((offset / file.size) * 100));
    if (res.body.done) return;
  }
}

function putChunk(file, from, to, replace) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    let url = '/api/upload/chunk?name=' + encodeURIComponent(file.name) +
              '&size=' + file.size + '&offset=' + from;
    if (replace) url += '&replace=1';
    xhr.open('POST', withPin(url));

    xhr.onload = () => {
      let body = {};
      try { body = JSON.parse(xhr.responseText); } catch (e) {}
      resolve({ status: xhr.status, ok: xhr.status === 200, body, text: xhr.responseText });
    };
    xhr.onerror = () => reject(new Error('network'));
    xhr.ontimeout = () => reject(new Error('timeout'));
    xhr.send(file.slice(from, to));
  });
}

$('addBtn').onclick = () => $('picker').click();
$('picker').onchange = (e) => { uploadAll([...e.target.files]); e.target.value = ''; };

/* -------------------------------------------------------------- Start */

if (pin) { unlock(); loadPlaylists(); } else { lockOut(); }
refresh();
connectEvents();

// Advances the seek bar between updates. Redrawing a clock locally costs
// nothing; asking the TV for the time every second costs a request.
setInterval(() => { if (!$('app').hidden && state.playing) renderNow(); }, 1000);

setInterval(() => { if (!$('app').hidden) loadPlaylists(); }, 20000);

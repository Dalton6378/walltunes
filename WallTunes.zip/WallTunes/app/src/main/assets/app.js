/* ==========================================================================
   WallTunes — phone app

   Talks to the little server running on the TV. Two rules throughout:

   1. Buttons react immediately and reconcile afterwards. The TV is one hop
      away on a home network, but "one hop" still means a visible pause if
      you wait for it before redrawing.
   2. Nothing that changes state happens without the PIN. Reading does not
      need it, so the page renders before you have typed anything.
   ========================================================================== */

const $ = (id) => document.getElementById(id);

let state = { songs: [], library: [], upNext: [], playing: false, shuffle: true };
let playlists = [];
let favourites = new Set();
let filter = '';
let sortBy = localStorage.getItem('wt-sort') || 'title';
let gridView = localStorage.getItem('wt-view') !== 'list';
let seeking = false;           // do not fight the user's thumb
let pin = localStorage.getItem('wt-pin') || '';

/**
 * Multi-select in the Library.
 *
 * Deliberately not remembered across reloads: coming back to a page that
 * still has forty songs ticked, with no memory of why, is alarming.
 */
let selecting = false;
let selection = new Set();

/** Which playlist is open, or null for the list of playlists. */
let openList = null;

/* ---------------------------------------------------------------- PIN */

const withPin = (url) => url + (url.includes('?') ? '&' : '?') + 'pin=' + encodeURIComponent(pin);

async function post(url) {
  const r = await fetch(withPin(url), { method: 'POST' });
  if (r.status === 401) { lockOut(); throw new Error('pin'); }
  if (!r.ok) {
    let msg = 'That did not work.';
    try { msg = (await r.text()) || msg; } catch (e) {}
    throw new Error(msg);
  }
  return r;
}

/** Fire and forget, but surface a real reason if it fails. */
function send(url, okMsg) {
  post(url).then(() => { if (okMsg) toast(okMsg); refresh(); })
           .catch((e) => { if (e.message !== 'pin') toast(e.message); refresh(); });
}

/**
 * Send a list of song names to an endpoint that takes repeated `name`
 * parameters.
 *
 * Split into batches because this all travels in the query string, and a
 * request line with two hundred filenames in it is the kind of thing a
 * small embedded server is entitled to reject. Batches go one after another
 * rather than at once: the TV is a cheap stick, and the point of a bulk
 * endpoint is fewer round trips, not a burst of parallel ones.
 */
async function postMany(base, names, extra) {
  const BATCH = 25;
  let done = 0;
  for (let i = 0; i < names.length; i += BATCH) {
    const slice = names.slice(i, i + BATCH);
    const q = slice.map((n) => 'name=' + encodeURIComponent(n)).join('&');
    await post(base + (base.includes('?') ? '&' : '?') + q + (extra ? '&' + extra : ''));
    done += slice.length;
  }
  return done;
}

function lockOut() {
  pin = '';
  localStorage.removeItem('wt-pin');
  $('app').hidden = true;
  $('gate').hidden = false;
  $('pinInput').value = '';
}

function unlock() { $('gate').hidden = true; $('app').hidden = false; }

$('pinInput').addEventListener('input', async (e) => {
  const v = e.target.value.replace(/[^0-9]/g, '');
  e.target.value = v;
  $('pinErr').hidden = true;
  if (v.length !== 4) return;
  try {
    const r = await fetch('/api/verify?pin=' + encodeURIComponent(v), { method: 'POST' });
    if (!r.ok) throw new Error();
    pin = v;
    localStorage.setItem('wt-pin', v);
    unlock(); refresh(); loadPlaylists();
  } catch (err) {
    $('pinErr').hidden = false;
    e.target.value = '';
  }
});

/* ------------------------------------------------------------- Helpers */

const clean = (n) => n.replace(/\.[^.]+$/, '');
const artUrl = (n) => '/api/art?name=' + encodeURIComponent(n);

function time(ms) {
  if (!ms || ms < 0) return '0:00';
  const s = Math.round(ms / 1000);
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

let toastTimer;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

/** An <img> that quietly becomes a note when the song has no cover. */
function cover(song, cls) {
  const img = document.createElement('img');
  img.loading = 'lazy';
  img.className = cls || '';
  img.alt = '';
  img.src = artUrl(song);
  img.onerror = () => {
    const ph = document.createElement('div');
    ph.className = 'none ' + (cls || '');
    ph.textContent = '♪';
    img.replaceWith(ph);
  };
  return img;
}

/* ----------------------------------------------------------------- Tabs */

const TABS = ['now', 'lib', 'queue', 'pl'];
function showTab(which) {
  for (const t of TABS) {
    $('tab-' + t).setAttribute('aria-selected', String(t === which));
    $('p-' + t).hidden = t !== which;
  }
  // Leaving the Library ends the selection: a floating action bar over the
  // wrong screen, acting on songs you can no longer see, is a trap.
  if (which !== 'lib' && selecting) setSelecting(false);
}
TABS.forEach((t) => { $('tab-' + t).onclick = () => showTab(t); });

/* ------------------------------------------------------------- Polling */

/**
 * Take a state payload from either transport and redraw.
 *
 * positionAt records when it arrived, so the seek bar can be advanced
 * locally between updates. That is what lets the server stay quiet: it only
 * speaks when something actually changes, and the phone fills in the
 * seconds by itself.
 */
function applyState(next) {
  state = next;
  state.positionAt = Date.now();
  $('offline').hidden = true;
  renderNow();
  renderLibrary();
  renderQueue();
  // Only when a playlist is open: its rows highlight whatever is playing,
  // and redrawing the whole Lists tab on every event would be wasteful.
  if (openList !== null) renderPlaylists();
}

/** Live position, extrapolated since the last update. */
function livePosition() {
  const base = state.position || 0;
  if (!state.playing || !state.positionAt) return base;
  return Math.min(base + (Date.now() - state.positionAt), state.duration || Infinity);
}

async function refresh() {
  try {
    const r = await fetch('/api/state', { cache: 'no-store' });
    applyState(await r.json());
  } catch (e) {
    $('offline').hidden = false;
  }
}

/* ------------------------------------------------------------- Events */

let events = null;
let pollTimer = null;

function startPolling(ms) {
  clearInterval(pollTimer);
  pollTimer = setInterval(refresh, ms);
}

/**
 * Prefer SSE, fall back to polling.
 *
 * The fallback is not decoration: EventSource is unavailable in a few older
 * mobile browsers, and a proxy or a sleeping phone can kill the connection.
 * Polling continues underneath at a much slower rate so a dropped feed
 * degrades to "slightly stale" rather than "frozen".
 */
function connectEvents() {
  if (!('EventSource' in window)) { startPolling(3000); return; }
  try {
    events = new EventSource('/api/events');

    events.onmessage = (e) => {
      try { applyState(JSON.parse(e.data)); } catch (err) {}
    };

    events.onopen = () => { startPolling(30000); };

    events.onerror = () => {
      // EventSource retries on its own, but if the TV went away entirely
      // that retry loop is silent, so polling picks up the slack.
      $('offline').hidden = false;
      startPolling(3000);
    };
  } catch (e) {
    startPolling(3000);
  }
}

async function loadPlaylists() {
  try {
    const r = await fetch('/api/playlists', { cache: 'no-store' });
    const d = await r.json();
    playlists = d.playlists || [];
    favourites = new Set(d.favourites || []);
    renderPlaylists();
    renderNow();
  } catch (e) { /* the offline banner covers this */ }
}

/* ------------------------------------------------------- Now playing */

let lastArtSong = null;

function renderNow() {
  const has = (state.songs || []).length > 0;
  $('npTitle').textContent = has ? (state.title || 'Starting up') : 'Nothing playing yet';
  $('npArtist').textContent = has ? (state.artist || '') : 'Add some songs from the Library tab.';
  $('playIcon').setAttribute('d', state.playing ? 'M6 5h4v14H6zM14 5h4v14h-4z' : 'M8 5v14l11-7z');
  $('shuffle').setAttribute('aria-pressed', String(!!state.shuffle));

  const cur = state.current;
  $('favourite').setAttribute('aria-pressed', String(cur ? favourites.has(cur) : false));
  syncLyricCard();

  // Only rebuild the artwork when the song actually changes, or the image
  // flickers every three seconds.
  if (cur !== lastArtSong) {
    lastArtSong = cur;
    const wrap = document.querySelector('.art-wrap');
    wrap.innerHTML = '';
    if (cur) wrap.appendChild(cover(cur));
    else {
      const ph = document.createElement('div');
      ph.className = 'none'; ph.textContent = '♪';
      wrap.appendChild(ph);
    }
  }

  const dur = state.duration || 0;
  const pos = livePosition();
  if (!seeking) {
    $('seek').value = dur > 0 ? Math.round((pos / dur) * 1000) : 0;
  }
  $('tElapsed').textContent = time(pos);
  $('tDuration').textContent = dur > 0 ? time(dur) : '';

  if (document.activeElement !== $('vol') && typeof state.volume === 'number') {
    $('vol').value = state.volume;
  }
}

$('toggle').onclick = () => {
  // Flip the icon now; the poll will confirm.
  state.playing = !state.playing;
  renderNow();
  send('/api/control?action=toggle');
};
$('prev').onclick = () => send('/api/control?action=prev');
$('next').onclick = () => send('/api/control?action=next');
$('shuffle').onclick = () => {
  state.shuffle = !state.shuffle;
  renderNow();
  send('/api/control?action=shuffle');
};
$('favourite').onclick = () => {
  const cur = state.current;
  if (!cur) return;
  if (favourites.has(cur)) favourites.delete(cur); else favourites.add(cur);
  renderNow();
  post('/api/favourite?name=' + encodeURIComponent(cur)).then(loadPlaylists).catch(() => {});
};

$('seek').addEventListener('input', () => { seeking = true; });
$('seek').addEventListener('change', (e) => {
  const dur = state.duration || 0;
  seeking = false;
  if (dur > 0) send('/api/control?action=seek&name=' + Math.round((e.target.value / 1000) * dur));
});

let volTimer;
$('vol').addEventListener('input', (e) => {
  // Dragging fires constantly; only the resting value is worth sending.
  clearTimeout(volTimer);
  const v = e.target.value;
  volTimer = setTimeout(() => post('/api/settings?' +
    (state.isNight ? 'nightVolume' : 'dayVolume') + '=' + v).catch(() => {}), 220);
});

/* ----------------------------------------------------------- Library */

function libraryRows() {
  const rows = (state.library && state.library.length)
    ? state.library.slice()
    : (state.songs || []).map((n) => ({ name: n, title: clean(n), artist: '', duration: 0, added: 0 }));

  const by = {
    title: (a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }),
    artist: (a, b) => (a.artist || '~').localeCompare(b.artist || '~', undefined, { sensitivity: 'base' }),
    added: (a, b) => (b.added || 0) - (a.added || 0),
    plays: (a, b) => (b.plays || 0) - (a.plays || 0),
  }[sortBy];

  const f = filter.toLowerCase();
  return rows
    .filter((r) => !f || r.title.toLowerCase().includes(f) || (r.artist || '').toLowerCase().includes(f))
    .sort(by);
}

function renderLibrary() {
  const body = $('libBody');
  const rows = libraryRows();
  const total = (state.library || state.songs || []).length;

  body.innerHTML = '';

  if (!total) {
    body.innerHTML =
      '<div class="empty"><b>No songs yet</b>Tap "Add songs" to send music to the TV.</div>';
    return;
  }
  if (!rows.length) {
    body.innerHTML = '<div class="empty"><b>Nothing matches</b>Try a different search.</div>';
    return;
  }

  if (gridView) {
    const grid = document.createElement('div');
    grid.className = 'grid';
    for (const r of rows) {
      // A wrapper, not a bare button: the cell needs a second control on
      // top of it, and a button inside a button is invalid HTML.
      const cell = document.createElement('div');
      cell.className = 'cell' + (r.name === state.current ? ' on' : '');

      if (selecting && selection.has(r.name)) cell.className += ' picked';

      const tap = document.createElement('button');
      tap.className = 'cell-tap';
      tap.appendChild(cover(r.name));
      const b = document.createElement('b'); b.textContent = r.title;
      const sub = document.createElement('span'); sub.textContent = r.artist || '';
      tap.append(b, sub);
      tap.onclick = () => {
        if (selecting) togglePick(r.name);
        else send('/api/control?action=play&name=' + encodeURIComponent(r.name));
      };
      if (selecting) {
        tap.setAttribute('role', 'checkbox');
        tap.setAttribute('aria-checked', String(selection.has(r.name)));
      }

      // An explicit button rather than a long press. contextmenu never fires
      // on iOS Safari, and grid is the default view — so relying on it left
      // iPhone users with no way to reach this menu at all.
      // While selecting, the corner shows whether this one is ticked
      // instead of offering a menu — a menu for a single song makes no
      // sense when the whole point is that several are chosen.
      const more = document.createElement('button');
      more.className = 'cell-more' + (selecting ? ' tick' : '');
      if (selecting) {
        more.setAttribute('aria-hidden', 'true');
        more.tabIndex = -1;
        more.textContent = selection.has(r.name) ? '✓' : '';
        more.onclick = (e) => { e.stopPropagation(); togglePick(r.name); };
      } else {
        more.setAttribute('aria-label', 'More options for ' + r.title);
        more.textContent = '⋯';
        more.onclick = (e) => { e.stopPropagation(); songSheet(r); };
      }

      cell.append(tap, more);
      grid.appendChild(cell);
    }
    body.appendChild(grid);
  } else {
    const ul = document.createElement('ul');
    ul.className = 'rows';
    for (const r of rows) {
      const li = document.createElement('li');
      li.className = (r.name === state.current ? 'on' : '') +
                     (selecting && selection.has(r.name) ? ' picked' : '');
      li.appendChild(cover(r.name));

      const meta = document.createElement('button');
      meta.className = 'meta';
      const b = document.createElement('b'); b.textContent = r.title;
      const s = document.createElement('span');
      s.textContent = [r.artist, r.duration ? time(r.duration) : ''].filter(Boolean).join('  ·  ');
      meta.append(b, s);
      meta.onclick = () => {
        if (selecting) togglePick(r.name);
        else send('/api/control?action=play&name=' + encodeURIComponent(r.name));
      };
      if (selecting) {
        meta.setAttribute('role', 'checkbox');
        meta.setAttribute('aria-checked', String(selection.has(r.name)));
      }

      const more = document.createElement('button');
      more.className = 'more';
      if (selecting) {
        more.setAttribute('aria-hidden', 'true');
        more.tabIndex = -1;
        more.textContent = selection.has(r.name) ? '✓' : '○';
        more.onclick = () => togglePick(r.name);
      } else {
        more.setAttribute('aria-label', 'More options for ' + r.title);
        more.textContent = '⋯';
        more.onclick = () => songSheet(r);
      }

      li.append(meta, more);
      ul.appendChild(li);
    }
    body.appendChild(ul);
  }
}

$('search').oninput = (e) => { filter = e.target.value; renderLibrary(); };
$('sort').value = sortBy;
$('sort').onchange = (e) => {
  sortBy = e.target.value;
  localStorage.setItem('wt-sort', sortBy);
  renderLibrary();
};
$('viewToggle').onclick = () => {
  gridView = !gridView;
  localStorage.setItem('wt-view', gridView ? 'grid' : 'list');
  renderLibrary();
};

/* ------------------------------------------------------------ Lyrics */

/**
 * The words, on the Playing tab, under the song they belong to.
 *
 * Deliberately part of the page rather than something you open: lyrics are
 * to be glanced at while the song plays, and anything you have to go and
 * fetch is something you mostly do not bother with.
 */
let lyricLines = [];
let lyricSynced = false;
let lyricSong = null;
let lyricState = '';
let lyricActive = -1;

/** Redraw the card when the song changes; called from renderNow. */
function syncLyricCard() {
  const song = state.current || null;
  if (song === lyricSong) return;
  lyricSong = song;
  lyricLines = [];
  lyricActive = -1;
  $('lyricFor').textContent = song ? (state.title || clean(song)) : 'Lyrics';
  $('lyricBox').innerHTML = '';
  if (!song) {
    setLyricMessage('Nothing playing.');
    return;
  }
  setLyricMessage('Loading…');
  loadLyrics(song);
}

function setLyricMessage(text) {
  const box = $('lyricBox');
  box.innerHTML = '';
  const p = document.createElement('p');
  p.className = 'lyric-msg';
  p.textContent = text;
  box.appendChild(p);
}

async function loadLyrics(song) {
  let data;
  try {
    const r = await fetch('/api/lyrics?name=' + encodeURIComponent(song), { cache: 'no-store' });
    data = await r.json();
  } catch (e) {
    data = { state: 'error', error: 'Could not reach the TV.', lines: [] };
  }
  if (lyricSong !== song) return;              // the song moved on

  lyricLines = data.lines || [];
  lyricSynced = !!data.synced;
  lyricState = data.state || '';
  lyricActive = -1;

  const box = $('lyricBox');
  box.classList.toggle('plain', !lyricSynced);

  if (!lyricLines.length) {
    setLyricMessage(
      lyricState === 'looking' ? 'Looking for lyrics…' :
      lyricState === 'off' ? 'Automatic lyrics are turned off.' :
      lyricState === 'error' ? (data.error || 'Could not reach the lyrics service.') :
      'No lyrics found for this song.');
    return;
  }

  box.innerHTML = '';
  for (const line of lyricLines) {
    const el = document.createElement('p');
    el.textContent = line.text;
    box.appendChild(el);
  }
  markActiveLine();
}

/**
 * Light up the line being sung and keep it in view.
 *
 * Only scrolls when the line actually changes, so it does not fight a thumb
 * that is reading ahead. Scrolling is confined to the lyrics box, so the
 * page underneath never moves.
 */
function markActiveLine() {
  const box = $('lyricBox');
  if (!lyricLines.length || !lyricSynced) return;

  const pos = livePosition();
  let idx = -1;
  for (let i = 0; i < lyricLines.length; i++) {
    if (lyricLines[i].t <= pos) idx = i; else break;
  }
  if (idx === lyricActive) return;
  lyricActive = idx;

  const kids = box.children;
  for (let i = 0; i < kids.length; i++) kids[i].className = (i === idx ? 'on' : '');
  if (idx >= 0 && kids[idx]) {
    box.scrollTo({
      top: Math.max(0, kids[idx].offsetTop - box.clientHeight / 2 + kids[idx].offsetHeight / 2),
      behavior: 'smooth',
    });
  }
}

/**
 * Re-ask while the answer is still "looking".
 *
 * The TV fetches in the background, so the words can turn up a few seconds
 * after the song started. Polling stops the moment there is something to
 * show, which is why this costs nothing in the normal case.
 */
setInterval(() => {
  if ($('app').hidden || !lyricSong) return;
  if (lyricLines.length || lyricState === 'off') return;
  loadLyrics(lyricSong);
}, 5000);

/** The active line, on its own clock: the seek bar redraws once a second. */
setInterval(() => {
  if (!$('app').hidden && state.playing) markActiveLine();
}, 250);

$('lyricRetry').onclick = () => {
  if (!lyricSong) return;
  const song = lyricSong;
  setLyricMessage('Looking again…');
  post('/api/lyrics/refetch?name=' + encodeURIComponent(song))
    .then(() => setTimeout(() => { if (lyricSong === song) loadLyrics(song); }, 1500))
    .catch((e) => { if (e.message !== 'pin') toast(e.message); });
};

$('lyricCheck').onclick = async () => {
  setLyricMessage('Checking…');
  try {
    const r = await fetch('/api/lyrics/check', { cache: 'no-store' });
    const d = await r.json();
    toast(d.message);
    if (lyricSong) loadLyrics(lyricSong);
  } catch (e) {
    toast('Could not reach the TV');
  }
};

$('lyricToggle').onclick = async () => {
  // Read the current setting rather than tracking it: this button is
  // pressed about twice a year and a stale local copy is a bug waiting.
  let on = true;
  try {
    const r = await fetch('/api/lyrics/state', { cache: 'no-store' });
    on = (await r.json()).enabled;
  } catch (e) { /* assume on; the POST below will tell us otherwise */ }

  try {
    await post('/api/settings?autoLyrics=' + (on ? '0' : '1'));
    $('lyricToggle').textContent = on ? 'Turn on' : 'Turn off';
    toast(on ? 'Automatic lyrics off' : 'Looking for lyrics');
    if (lyricSong) loadLyrics(lyricSong);
  } catch (e) {
    if (e.message !== 'pin') toast(e.message);
  }
};

/* --------------------------------------------------- Selecting songs */

function setSelecting(on) {
  selecting = on;
  if (!on) selection.clear();
  $('selectBtn').setAttribute('aria-pressed', String(on));
  // Lets the upload tray and toast move clear of the action bar.
  document.body.classList.toggle('selecting', on);
  renderSelbar();
  renderLibrary();
}

function togglePick(name) {
  if (selection.has(name)) selection.delete(name);
  else selection.add(name);
  renderSelbar();
  renderLibrary();
}

function renderSelbar() {
  const bar = $('selbar');
  bar.hidden = !selecting;
  const n = selection.size;
  $('selCount').textContent = n === 1 ? '1 selected' : n + ' selected';
  $('selAddTo').disabled = n === 0;
  // Offer whichever of select-all / select-none is the useful one.
  const all = libraryRows();
  const everything = all.length > 0 && all.every((r) => selection.has(r.name));
  $('selAll').textContent = everything ? 'None' : 'All';
}

$('selectBtn').onclick = () => setSelecting(!selecting);
$('selCancel').onclick = () => setSelecting(false);

$('selAll').onclick = () => {
  const all = libraryRows();
  // Acts on what is on screen, so a search then "All" selects the matches
  // rather than silently roping in the whole library.
  const everything = all.length > 0 && all.every((r) => selection.has(r.name));
  if (everything) selection.clear();
  else all.forEach((r) => selection.add(r.name));
  renderSelbar();
  renderLibrary();
};

$('selAddTo').onclick = () => addToSheet([...selection]);

/**
 * "Put these somewhere" — the sheet that both the multi-select bar and a
 * single song's menu lead to, so the choice looks the same either way.
 */
function addToSheet(names) {
  if (!names.length) return;
  openSheet((s) => {
    const h = document.createElement('h2');
    h.textContent = names.length === 1 ? 'Add this song to' : 'Add ' + names.length + ' songs to';
    s.appendChild(h);

    const p = document.createElement('p');
    p.className = 'sub';
    p.textContent = 'Songs already in a playlist are not added twice.';
    s.appendChild(p);

    sheetRow(s, 'New playlist…', async () => {
      const name = prompt('Name the playlist');
      if (!name || !name.trim()) return;
      try {
        // Create and fill in one request, so a dropped connection cannot
        // leave an empty playlist behind. Only the FIRST batch may create
        // it — sending the rest the same way would make a new playlist per
        // batch — so the id comes back and the remainder is added to it.
        const first = names.slice(0, 25);
        const q = first.map((n) => 'name=' + encodeURIComponent(n)).join('&');
        const r = await post('/api/playlist/create-with?title=' +
                             encodeURIComponent(name.trim()) + '&' + q);
        const rest = names.slice(25);
        if (rest.length) {
          const { id } = await r.json();
          await postMany('/api/playlist/add-many?id=' + encodeURIComponent(id), rest);
        }
        toast('Added to ' + name.trim());
        setSelecting(false);
        loadPlaylists();
      } catch (e) {
        if (e.message !== 'pin') toast(e.message);
      }
    });

    for (const pl of playlists) {
      sheetRow(s, pl.name, async () => {
        try {
          await postMany('/api/playlist/add-many?id=' + encodeURIComponent(pl.id), names);
          toast('Added to ' + pl.name);
          setSelecting(false);
          loadPlaylists();
        } catch (e) {
          if (e.message !== 'pin') toast(e.message);
        }
      });
    }

    sheetRow(s, 'Up Next', async () => {
      try {
        for (const n of names) await post('/api/queue/add?name=' + encodeURIComponent(n));
        toast(names.length === 1 ? 'Added to Up Next' : names.length + ' added to Up Next');
        setSelecting(false);
        refresh();
      } catch (e) {
        if (e.message !== 'pin') toast(e.message);
      }
    });
  });
}

/* ------------------------------------------------------------- Sheets */

function openSheet(build) {
  const sheet = $('sheet');
  sheet.innerHTML = '';
  build(sheet);
  sheet.classList.add('open');
  $('scrim').classList.add('open');
}
function closeSheet() {
  $('sheet').classList.remove('open');
  $('scrim').classList.remove('open');
}
$('scrim').onclick = closeSheet;

function sheetRow(parent, label, fn, danger) {
  const b = document.createElement('button');
  b.className = 'row' + (danger ? ' danger' : '');
  b.textContent = label;
  b.onclick = () => { closeSheet(); fn(); };
  parent.appendChild(b);
}

function songSheet(row) {
  openSheet((s) => {
    const h = document.createElement('h2'); h.textContent = row.title;
    const p = document.createElement('p'); p.className = 'sub'; p.textContent = row.artist || '';
    s.append(h, p);

    sheetRow(s, 'Play now', () =>
      send('/api/control?action=play&name=' + encodeURIComponent(row.name)));
    sheetRow(s, 'Play next', () =>
      send('/api/queue/next?name=' + encodeURIComponent(row.name), 'Playing next'));
    sheetRow(s, 'Add to Up Next', () =>
      send('/api/queue/add?name=' + encodeURIComponent(row.name), 'Added to Up Next'));

    // One entry rather than a row per playlist: with a dozen lists the
    // menu became a wall of near-identical lines, and the interesting
    // choice — which list — deserves its own screen.
    sheetRow(s, 'Add to playlist…', () => addToSheet([row.name]));

    sheetRow(s, 'Find lyrics again', () =>
      send('/api/lyrics/refetch?name=' + encodeURIComponent(row.name),
           'Looking for lyrics'));

    sheetRow(s, 'Delete from the TV', () => {
      if (confirm('Delete ' + row.title + ' from the TV? This cannot be undone.')) {
        send('/api/delete?name=' + encodeURIComponent(row.name), 'Deleted');
      }
    }, true);
  });
}

/* ------------------------------------------------------------ Up Next */

function renderQueue() {
  const body = $('queueBody');
  const q = state.upNext || [];
  body.innerHTML = '';

  if (!q.length) {
    body.innerHTML =
      '<div class="empty"><b>Nothing queued</b>Use the ⋯ menu on a song, or hold OK on the TV remote.</div>';
    return;
  }

  const clear = document.createElement('button');
  clear.className = 'pill';
  clear.style.cssText = 'width:100%;margin:10px 0 14px';
  clear.textContent = 'Clear Up Next';
  clear.onclick = () => send('/api/queue/clear', 'Cleared');
  body.appendChild(clear);

  const ul = document.createElement('ul');
  ul.className = 'queue';
  q.forEach((name, i) => {
    const li = document.createElement('li');
    li.draggable = true;
    li.dataset.index = String(i);

    const grip = document.createElement('div');
    grip.className = 'grip';
    grip.textContent = '≡';

    const meta = document.createElement('div');
    meta.className = 'meta';
    const b = document.createElement('b'); b.textContent = clean(name);
    meta.appendChild(b);

    const rm = document.createElement('button');
    rm.className = 'more';
    rm.setAttribute('aria-label', 'Remove ' + clean(name));
    rm.textContent = '×';
    rm.onclick = () => send('/api/queue/remove?name=' + encodeURIComponent(name));

    li.append(grip, meta, rm);
    wireDrag(li, ul, q);
    ul.appendChild(li);
  });
  body.appendChild(ul);
}

/**
 * Drag to reorder.
 *
 * Reordering is done by replaying it as remove-then-reinsert through the
 * queue endpoints, because the server owns the order and the phone is only
 * ever a view of it.
 */
function wireDrag(li, ul, names) {
  li.addEventListener('dragstart', (e) => {
    li.classList.add('dragging');
    e.dataTransfer.setData('text/plain', li.dataset.index);
  });
  li.addEventListener('dragend', () => li.classList.remove('dragging'));
  li.addEventListener('dragover', (e) => { e.preventDefault(); li.classList.add('over'); });
  li.addEventListener('dragleave', () => li.classList.remove('over'));
  li.addEventListener('drop', (e) => {
    e.preventDefault();
    li.classList.remove('over');
    const from = parseInt(e.dataTransfer.getData('text/plain'), 10);
    const to = parseInt(li.dataset.index, 10);
    if (isNaN(from) || isNaN(to) || from === to) return;

    const next = names.slice();
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);

    // Optimistic: show the new order at once, then rebuild it on the TV.
    state.upNext = next;
    renderQueue();
    rebuildQueue(next);
  });
}

async function rebuildQueue(order) {
  try {
    await post('/api/queue/clear');
    for (const n of order) await post('/api/queue/add?name=' + encodeURIComponent(n));
    refresh();
  } catch (e) {
    if (e.message !== 'pin') toast('Could not reorder');
    refresh();
  }
}

/* --------------------------------------------------------- Playlists */

function renderPlaylists() {
  // One of the two views, never both.
  const inside = openList !== null && playlists.some((p) => p.id === openList);
  $('plList').hidden = inside;
  $('plDetail').hidden = !inside;
  if (inside) { renderPlaylistDetail(); return; }
  // A playlist deleted from elsewhere must not leave us on a dead screen.
  if (openList !== null) openList = null;

  const body = $('plBody');
  body.innerHTML = '';

  if (!playlists.length) {
    body.innerHTML =
      '<div class="empty"><b>No playlists yet</b>' +
      'Make one, then use Add songs to fill it.</div>';
    return;
  }

  const ul = document.createElement('ul');
  ul.className = 'pl';
  for (const pl of playlists) {
    const li = document.createElement('li');

    const meta = document.createElement('button');
    meta.className = 'meta';
    const b = document.createElement('b'); b.textContent = pl.name;
    const s = document.createElement('span');
    s.textContent = pl.count === 1 ? '1 song' : pl.count + ' songs';
    meta.append(b, s);
    // Opens it. Playing is one tap further in, because "what is in this?"
    // is asked far more often than "play all of it right now", and the
    // wrong guess here replaces whatever is currently on.
    meta.onclick = () => openPlaylist(pl.id);

    const more = document.createElement('button');
    more.className = 'more';
    more.setAttribute('aria-label', 'Options for ' + pl.name);
    more.textContent = '⋯';
    more.onclick = () => playlistSheet(pl);

    li.append(meta, more);
    ul.appendChild(li);
  }
  body.appendChild(ul);
}

function playlistSheet(pl) {
  openSheet((s) => {
    const h = document.createElement('h2'); h.textContent = pl.name;
    const p = document.createElement('p'); p.className = 'sub';
    p.textContent = pl.count === 1 ? '1 song' : pl.count + ' songs';
    s.append(h, p);

    sheetRow(s, 'Play', () => {
      if (!pl.count) { toast('That playlist is empty'); return; }
      send('/api/playlist/play?id=' + encodeURIComponent(pl.id), 'Playing ' + pl.name);
    });
    sheetRow(s, 'Rename', () => {
      const name = prompt('Rename playlist', pl.name);
      if (name && name.trim()) {
        post('/api/playlist/rename?id=' + encodeURIComponent(pl.id) +
             '&name=' + encodeURIComponent(name.trim()))
          .then(loadPlaylists).catch(() => toast('Could not rename'));
      }
    });
    sheetRow(s, 'Delete playlist', () => {
      if (confirm('Delete "' + pl.name + '"? The songs stay on the TV.')) {
        post('/api/playlist/delete?id=' + encodeURIComponent(pl.id))
          .then(loadPlaylists).catch(() => toast('Could not delete'));
      }
    }, true);
  });
}

/* --------------------------------------------------- One playlist */

function openPlaylist(id) {
  openList = id;
  renderPlaylists();
}

function closePlaylist() {
  openList = null;
  renderPlaylists();
}

$('plBack').onclick = closePlaylist;

/**
 * The contents of one playlist.
 *
 * Rendered from the same `playlists` payload the list view uses — the song
 * names were always in there, they were simply never shown, so this needs
 * no extra request and stays correct whenever the list reloads.
 */
function renderPlaylistDetail() {
  const pl = playlists.find((p) => p.id === openList);
  if (!pl) { closePlaylist(); return; }

  $('plName').textContent = pl.name;
  $('plCount').textContent = pl.count === 1 ? '1 song' : pl.count + ' songs';
  $('plPlay').disabled = !pl.count;

  $('plPlay').onclick = () =>
    send('/api/playlist/play?id=' + encodeURIComponent(pl.id), 'Playing ' + pl.name);
  $('plAdd').onclick = () => songPicker(pl);
  $('plMore').onclick = () => playlistSheet(pl);

  const body = $('plSongs');
  body.innerHTML = '';

  if (!pl.count) {
    body.innerHTML =
      '<div class="empty"><b>Nothing in here yet</b>Tap "Add songs" to pick some.</div>';
    return;
  }

  // Names to rows, so titles and artwork match the rest of the app.
  const byName = {};
  for (const r of (state.library || [])) byName[r.name] = r;

  const ul = document.createElement('ul');
  ul.className = 'rows';
  for (const name of pl.songs) {
    const r = byName[name] || { name: name, title: clean(name), artist: '', duration: 0 };
    const li = document.createElement('li');
    if (name === state.current) li.className = 'on';
    li.appendChild(cover(name));

    const meta = document.createElement('button');
    meta.className = 'meta';
    const b = document.createElement('b'); b.textContent = r.title;
    const sp = document.createElement('span');
    sp.textContent = [r.artist, r.duration ? time(r.duration) : ''].filter(Boolean).join('  ·  ');
    meta.append(b, sp);
    meta.onclick = () => send('/api/control?action=play&name=' + encodeURIComponent(name));

    const rm = document.createElement('button');
    rm.className = 'more';
    rm.setAttribute('aria-label', 'Remove ' + r.title + ' from ' + pl.name);
    rm.textContent = '−';
    rm.onclick = () =>
      post('/api/playlist/remove?id=' + encodeURIComponent(pl.id) +
           '&name=' + encodeURIComponent(name))
        .then(() => { toast('Removed'); loadPlaylists(); })
        .catch((e) => { if (e.message !== 'pin') toast('Could not remove that'); });

    li.append(meta, rm);
    ul.appendChild(li);
  }
  body.appendChild(ul);
}

/**
 * Pick songs to put in a playlist.
 *
 * A searchable list of everything not already in it, with running totals —
 * the flow someone actually wants when filling a new playlist, rather than
 * going back to the Library and adding one song at a time.
 */
function songPicker(pl) {
  const have = new Set(pl.songs || []);
  const chosen = new Set();
  const all = (state.library || []).filter((r) => !have.has(r.name));

  openSheet((s) => {
    const h = document.createElement('h2'); h.textContent = 'Add to ' + pl.name;
    s.appendChild(h);

    if (!all.length) {
      const p = document.createElement('p');
      p.className = 'sub';
      p.textContent = 'Every song on the TV is already in this playlist.';
      s.appendChild(p);
      return;
    }

    const search = document.createElement('input');
    search.className = 'search';
    search.type = 'search';
    search.placeholder = 'Search ' + all.length + ' songs';
    search.setAttribute('aria-label', 'Search songs to add');
    s.appendChild(search);

    const list = document.createElement('ul');
    list.className = 'rows pick';
    s.appendChild(list);

    const done = document.createElement('button');
    done.className = 'pill primary wide sticky';
    s.appendChild(done);

    const refreshDone = () => {
      done.textContent = chosen.size
        ? 'Add ' + chosen.size + (chosen.size === 1 ? ' song' : ' songs')
        : 'Choose some songs';
      done.disabled = chosen.size === 0;
    };

    const draw = () => {
      const f = search.value.toLowerCase();
      const rows = all.filter((r) => !f ||
        r.title.toLowerCase().includes(f) || (r.artist || '').toLowerCase().includes(f));

      list.innerHTML = '';
      if (!rows.length) {
        const e = document.createElement('li');
        e.className = 'none-row';
        e.textContent = 'Nothing matches that.';
        list.appendChild(e);
        return;
      }

      // Capped: a sheet is not the place to lay out a thousand rows, and
      // searching is the faster way through a big library anyway.
      for (const r of rows.slice(0, 120)) {
        const li = document.createElement('li');
        if (chosen.has(r.name)) li.className = 'picked';

        const btn = document.createElement('button');
        btn.className = 'meta';
        btn.setAttribute('role', 'checkbox');
        btn.setAttribute('aria-checked', String(chosen.has(r.name)));
        const b = document.createElement('b'); b.textContent = r.title;
        const sp = document.createElement('span'); sp.textContent = r.artist || '';
        btn.append(b, sp);
        btn.onclick = () => {
          if (chosen.has(r.name)) chosen.delete(r.name);
          else chosen.add(r.name);
          refreshDone();
          draw();
        };

        const tick = document.createElement('span');
        tick.className = 'tickmark';
        tick.textContent = chosen.has(r.name) ? '✓' : '';

        li.append(btn, tick);
        list.appendChild(li);
      }

      if (rows.length > 120) {
        const more = document.createElement('li');
        more.className = 'none-row';
        more.textContent = 'Showing 120 of ' + rows.length + '. Search to narrow it down.';
        list.appendChild(more);
      }
    };

    search.oninput = draw;
    done.onclick = async () => {
      const names = [...chosen];
      if (!names.length) return;
      closeSheet();
      try {
        await postMany('/api/playlist/add-many?id=' + encodeURIComponent(pl.id), names);
        toast(names.length === 1 ? 'Added 1 song' : 'Added ' + names.length + ' songs');
        loadPlaylists();
      } catch (e) {
        if (e.message !== 'pin') toast(e.message);
      }
    };

    refreshDone();
    draw();
  });
}

$('newList').onclick = () => {
  const name = prompt('Name this playlist');
  if (!name || !name.trim()) return;
  post('/api/playlist/create?name=' + encodeURIComponent(name.trim()))
    .then(() => { toast('Created'); loadPlaylists(); })
    .catch(() => toast('Could not create that'));
};

/* --------------------------------------------------------- Uploading */

/**
 * Chunked, resumable, two at a time.
 *
 * A single POST of a 40MB file is all-or-nothing: lose wifi at 90% and the
 * whole thing starts again. Sending it in pieces means a hiccup costs one
 * chunk, and the TV is asked where to resume rather than being told.
 *
 * Two concurrent files, not more: the TV is a streaming stick writing to
 * slow internal storage, and beyond two everything simply gets slower
 * together.
 */
const CHUNK = 512 * 1024;
const LANES = 2;
const RETRIES = 3;

let pending = [];          // files waiting for a lane
let active = 0;            // lanes currently busy
let done = 0, total = 0;   // for the tray
let dupChoice = null;

/**
 * The library as it looked before this batch of uploads started.
 *
 * The TV renames a clashing file — "Song (2).mp3" — so the phone cannot
 * know what a song ended up being called. Diffing against this afterwards
 * is the only honest way to find out what actually arrived, and it is what
 * makes "add what you just uploaded to a playlist" possible at all.
 */
let libraryBefore = null;

function uploadAll(files) {
  const ok = files.filter((f) => /\.(mp3|m4a|aac|flac|ogg|oga|opus|wav|lrc)$/i.test(f.name));
  const skipped = files.length - ok.length;
  if (skipped > 0) toast(skipped + (skipped === 1 ? ' file was' : ' files were') + ' not music, skipped');
  if (!ok.length) return;

  dupChoice = null;
  // Only at the start of a quiet period, so files dropped in while an
  // upload is already running still count as one batch.
  if (!pending.length && active === 0) {
    libraryBefore = new Set((state.library || []).map((r) => r.name));
  }
  pending = pending.concat(ok);
  total += ok.length;
  pump();
}

function pump() {
  while (active < LANES && pending.length) {
    active++;
    sendFile(pending.shift())
      .catch(() => {})
      .then(() => {
        active--;
        done++;
        tray();
        if (pending.length) pump();
        else if (active === 0) finishTray();
      });
  }
  tray();
}

function tray() {
  const t = $('tray');
  if (!pending.length && active === 0) return;
  t.hidden = false;
  const left = pending.length + active;
  $('trayText').textContent =
    left === 1 ? 'Sending 1 file' : 'Sending ' + left + ' files';
}

function finishTray() {
  $('tray').hidden = true;
  $('trayBar').style.width = '0%';
  done = 0; total = 0;
  refresh().then(offerToFile);
}

/**
 * Having just sent songs to the TV, offer to put them somewhere.
 *
 * This is the moment the intent is clearest — you chose these files
 * seconds ago — and without it filing them means finding each one again in
 * a library that just got bigger.
 */
function offerToFile() {
  const before = libraryBefore;
  libraryBefore = null;
  if (!before) return;

  const fresh = (state.library || [])
    .map((r) => r.name)
    .filter((n) => !before.has(n));
  if (!fresh.length) return;

  toast(fresh.length === 1 ? 'Added 1 song' : 'Added ' + fresh.length + ' songs');
  // Nowhere to file them yet and nothing to choose between: the Up Next
  // option alone is not worth a sheet popping up unasked.
  if (!playlists.length) return;
  addToSheet(fresh);
}

function setBar(pct) { $('trayBar').style.width = pct + '%'; }

/** Ask the TV how much of this file it already has. */
async function resumeOffset(file) {
  try {
    const r = await fetch('/api/upload/status?name=' + encodeURIComponent(file.name) +
                          '&size=' + file.size, { cache: 'no-store' });
    if (!r.ok) return 0;
    return (await r.json()).offset || 0;
  } catch (e) {
    return 0;
  }
}

async function sendFile(file, replace) {
  let offset = await resumeOffset(file);
  if (offset > 0 && offset < file.size) {
    toast('Resuming ' + file.name);
  }

  let tries = 0;
  while (offset < file.size) {
    const end = Math.min(offset + CHUNK, file.size);
    let res;
    try {
      res = await putChunk(file, offset, end, replace);
    } catch (e) {
      // A dropped connection is expected, not exceptional. Back off a
      // little, re-ask where we are, and carry on.
      if (++tries > RETRIES) { toast('Gave up on ' + file.name); return; }
      await new Promise((r) => setTimeout(r, 400 * tries));
      offset = await resumeOffset(file);
      continue;
    }

    if (res.status === 401) { lockOut(); pending = []; return; }

    if (res.status === 409) {
      const body = res.body || {};
      if (body.error === 'offset') {
        // The TV and the phone disagreed about progress. It wins.
        offset = body.offset || 0;
        continue;
      }
      // Duplicate. Ask once, then apply the same answer to the batch.
      if (dupChoice === null) {
        dupChoice = confirm(
          (body.existing || file.name) + ' is already on the TV.' +
          '\n\nOK replaces duplicates in this batch.' +
          '\nCancel skips them.'
        ) ? 'replace' : 'skip';
      }
      if (dupChoice === 'replace') return sendFile(file, true);
      toast('Skipped ' + file.name);
      return;
    }

    if (!res.ok) { toast(res.text || ('Could not send ' + file.name)); return; }

    tries = 0;
    offset = res.body.offset;
    setBar(Math.round((offset / file.size) * 100));
    if (res.body.done) return;
  }
}

function putChunk(file, from, to, replace) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    let url = '/api/upload/chunk?name=' + encodeURIComponent(file.name) +
              '&size=' + file.size + '&offset=' + from;
    if (replace) url += '&replace=1';
    xhr.open('POST', withPin(url));

    xhr.onload = () => {
      let body = {};
      try { body = JSON.parse(xhr.responseText); } catch (e) {}
      resolve({ status: xhr.status, ok: xhr.status === 200, body, text: xhr.responseText });
    };
    xhr.onerror = () => reject(new Error('network'));
    xhr.ontimeout = () => reject(new Error('timeout'));
    xhr.send(file.slice(from, to));
  });
}

$('addBtn').onclick = () => $('picker').click();
$('picker').onchange = (e) => { uploadAll([...e.target.files]); e.target.value = ''; };

/* -------------------------------------------------------------- Start */

if (pin) { unlock(); loadPlaylists(); } else { lockOut(); }
refresh();
connectEvents();

// Advances the seek bar between updates. Redrawing a clock locally costs
// nothing; asking the TV for the time every second costs a request.
setInterval(() => { if (!$('app').hidden && state.playing) renderNow(); }, 1000);

setInterval(() => { if (!$('app').hidden) loadPlaylists(); }, 20000);

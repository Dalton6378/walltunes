package com.itsdalton.walltunes

import android.graphics.Bitmap

/**
 * A cheap, good-enough blur for the full-bleed artwork background.
 *
 * Deliberately a plain function over bitmaps with no Android UI types: it
 * cannot touch a View, so it cannot accidentally be called on the main
 * thread and get away with it.
 *
 * Why this rather than RenderEffect or RenderScript:
 *
 *  - RenderEffect.createBlurEffect is API 31+. minSdk here is 22, and Fire OS
 *    lags Android badly, so on the actual hardware it simply is not there.
 *  - RenderScript is deprecated and was never reliable across Fire OS builds.
 *
 * The trick that makes it fast enough is doing almost no work: the source is
 * decoded at roughly 64px (via the caller's existing sampled decode), blurred
 * at that size, and then handed to an ImageView which scales it up on the
 * GPU. Upscaling a blurred 64px image looks identical to blurring a large
 * one, because blurring has already destroyed the detail that the extra
 * pixels would have carried. Three box passes approximate a Gaussian closely
 * enough that nobody will ever see the difference on a wall.
 */
object Blur {

    /**
     * @param radius window is (2*radius+1) px at the SOURCE size, so on a
     *   64px bitmap a radius of 4 is already a very soft blur.
     * @param passes three box passes is the usual approximation of Gaussian.
     */
    fun blur(source: Bitmap, radius: Int = 4, passes: Int = 3): Bitmap? {
        val w = source.width
        val h = source.height
        if (w < 3 || h < 3) return null

        // Clamp so a tiny source cannot produce a window wider than itself.
        val r = radius.coerceIn(1, minOf(w, h) / 2 - 1).coerceAtLeast(1)

        return try {
            val a = IntArray(w * h)
            source.getPixels(a, 0, w, 0, 0, w, h)
            val b = IntArray(w * h)

            repeat(passes) {
                horizontal(a, b, w, h, r)
                vertical(b, a, w, h, r)
            }

            // RGB_565 halves the memory and the background has no alpha.
            Bitmap.createBitmap(a, w, h, Bitmap.Config.RGB_565)
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Sliding-window box blur across each row.
     *
     * The window total is carried from pixel to pixel — one add and one
     * subtract each step — so cost is O(pixels), independent of radius.
     * Edges clamp to the nearest pixel rather than wrapping or darkening,
     * which would show as a vignette once the image is scaled up.
     */
    private fun horizontal(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0
            var sg = 0
            var sb = 0

            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, w - 1)]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
            }

            for (x in 0 until w) {
                dst[row + x] =
                    (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)

                val out = src[row + (x - r).coerceIn(0, w - 1)]
                val inc = src[row + (x + r + 1).coerceIn(0, w - 1)]
                sr += ((inc shr 16) and 0xFF) - ((out shr 16) and 0xFF)
                sg += ((inc shr 8) and 0xFF) - ((out shr 8) and 0xFF)
                sb += (inc and 0xFF) - (out and 0xFF)
            }
        }
    }

    /** The same sliding window, down each column. */
    private fun vertical(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0
            var sg = 0
            var sb = 0

            for (i in -r..r) {
                val p = src[i.coerceIn(0, h - 1) * w + x]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
            }

            for (y in 0 until h) {
                dst[y * w + x] =
                    (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)

                val out = src[(y - r).coerceIn(0, h - 1) * w + x]
                val inc = src[(y + r + 1).coerceIn(0, h - 1) * w + x]
                sr += ((inc shr 16) and 0xFF) - ((out shr 16) and 0xFF)
                sg += ((inc shr 8) and 0xFF) - ((out shr 8) and 0xFF)
                sb += (inc and 0xFF) - (out and 0xFF)
            }
        }
    }
}

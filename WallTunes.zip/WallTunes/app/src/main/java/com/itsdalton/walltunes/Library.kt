package com.itsdalton.walltunes

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Playlists, favourites and play counts, stored in filesDir/library.json.
 *
 * THE RULE THIS FILE EXISTS TO HONOUR: none of this is the truth about your
 * music. The truth is the files in filesDir/music, listed by
 * PlaybackService.songFiles(). Everything here is an enhancement layered on
 * top, which means the file can be deleted, truncated or filled with garbage
 * and WallTunes still boots and still plays every song you own. That is a
 * structural guarantee, not a promise about careful coding: nothing in the
 * playback path reads this file.
 *
 * Consequences of that rule, made concrete:
 *
 *  - every load is wrapped, and any failure yields an empty model rather
 *    than an exception;
 *  - a playlist entry that no longer matches a file on disk is skipped when
 *    read, so deleting a song can never strand a playlist in a broken state;
 *  - writes are atomic (temp file, then rename), the same approach
 *    UploadServer already uses for uploads, so a power cut mid-save leaves
 *    the previous file intact rather than a half-written one.
 */
class Library(private val dir: File) {

    data class Playlist(
        val id: String,
        var name: String,
        val songs: MutableList<String>,
        val created: Long
    )

    private val file get() = File(dir, "library.json")

    private val playlists = mutableListOf<Playlist>()
    private val favourites = mutableSetOf<String>()
    private val playCounts = mutableMapOf<String, Int>()

    /** Corrected title and artist, by filename. See [setMeta]. */
    private val meta = mutableMapOf<String, Pair<String, String>>()

    private val lock = Any()
    private var loaded = false

    /** Every disk write happens here, never on the main thread. */
    private val io = Executors.newSingleThreadExecutor { r ->
        Thread(r, "walltunes-library").apply { isDaemon = true }
    }

    // ---------- Persistence ----------

    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        try {
            if (!file.exists()) return
            val root = JSONObject(file.readText())

            val pls = root.optJSONArray("playlists") ?: JSONArray()
            for (i in 0 until pls.length()) {
                val o = pls.optJSONObject(i) ?: continue
                // Not `ifEmpty { continue }`: Kotlin 1.9 does not allow
                // break/continue out of an inline lambda.
                val id = o.optString("id")
                if (id.isEmpty()) continue
                val songs = mutableListOf<String>()
                val arr = o.optJSONArray("songs") ?: JSONArray()
                for (j in 0 until arr.length()) {
                    arr.optString(j).takeIf { it.isNotEmpty() }?.let { songs.add(it) }
                }
                playlists.add(
                    Playlist(
                        id = id,
                        name = o.optString("name").ifEmpty { "Playlist" },
                        songs = songs,
                        created = o.optLong("created", System.currentTimeMillis())
                    )
                )
            }

            val favs = root.optJSONArray("favourites") ?: JSONArray()
            for (i in 0 until favs.length()) {
                favs.optString(i).takeIf { it.isNotEmpty() }?.let { favourites.add(it) }
            }

            val counts = root.optJSONObject("playCounts") ?: JSONObject()
            for (key in counts.keys()) playCounts[key] = counts.optInt(key, 0)

            // Absent in files written by earlier versions, which is why it
            // is read defensively rather than assumed: an old library.json
            // must keep working untouched.
            val metas = root.optJSONObject("meta") ?: JSONObject()
            for (key in metas.keys()) {
                val o = metas.optJSONObject(key) ?: continue
                meta[key] = o.optString("title") to o.optString("artist")
            }
        } catch (e: Exception) {
            // Corrupt, truncated, or written by something else entirely.
            // Start empty: the music still plays, and the next save rewrites
            // a clean file. Losing playlists is bad; refusing to boot on a
            // wall-mounted TV is worse.
            playlists.clear()
            favourites.clear()
            playCounts.clear()
            meta.clear()
        }
    }

    /**
     * Serialise now, write later.
     *
     * save() is called from the main thread — bumpPlayCount runs on every
     * track change — so the disk write must not happen there. The JSON is
     * built synchronously while the lock is already held, then handed as a
     * finished string to a single background thread. That sidesteps
     * re-locking entirely and keeps every write in order.
     */
    private fun save() {
        val text = try {
            buildJson()
        } catch (e: Exception) {
            return
        }
        try {
            io.execute { writeAtomically(text) }
        } catch (e: Exception) {
            // Executor rejected the job (shutting down). The in-memory model
            // is still correct; only this write is lost.
        }
    }

    private fun writeAtomically(text: String) {
        try {
            dir.mkdirs()
            // Atomic: a crash mid-write leaves the old file untouched.
            val tmp = File(dir, "library.json.tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(file)) {
                // Some filesystems refuse rename onto an existing file.
                file.delete()
                tmp.renameTo(file)
            }
        } catch (e: Exception) {
            // A failed save costs the last change, never the music.
        }
    }

    private fun buildJson(): String =
        JSONObject()
            .put("version", 1)
            .put("playlists", JSONArray().apply {
                playlists.forEach { p ->
                    put(
                        JSONObject()
                            .put("id", p.id)
                            .put("name", p.name)
                            .put("created", p.created)
                            .put("songs", JSONArray().apply { p.songs.forEach { put(it) } })
                    )
                }
            })
            .put("favourites", JSONArray().apply { favourites.forEach { put(it) } })
            .put("playCounts", JSONObject().apply {
                playCounts.forEach { (k, v) -> put(k, v) }
            })
            .put("meta", JSONObject().apply {
                meta.forEach { (k, v) ->
                    put(k, JSONObject().put("title", v.first).put("artist", v.second))
                }
            })
            .toString()

    // ---------- Playlists ----------

    fun playlists(): List<Playlist> = synchronized(lock) {
        ensureLoaded()
        playlists.map { it.copy(songs = it.songs.toMutableList()) }
    }

    fun createPlaylist(name: String): Playlist = synchronized(lock) {
        ensureLoaded()
        val p = Playlist(
            id = System.currentTimeMillis().toString(36) + "-" + (1000..9999).random(),
            name = name.trim().take(60).ifEmpty { "Playlist" },
            songs = mutableListOf(),
            created = System.currentTimeMillis()
        )
        playlists.add(p)
        save()
        p
    }

    fun renamePlaylist(id: String, name: String): Boolean = synchronized(lock) {
        ensureLoaded()
        val p = playlists.firstOrNull { it.id == id } ?: return false
        p.name = name.trim().take(60).ifEmpty { p.name }
        save()
        true
    }

    fun deletePlaylist(id: String): Boolean = synchronized(lock) {
        ensureLoaded()
        val removed = playlists.removeAll { it.id == id }
        if (removed) save()
        removed
    }

    fun addToPlaylist(id: String, song: String): Boolean = synchronized(lock) {
        ensureLoaded()
        val p = playlists.firstOrNull { it.id == id } ?: return false
        if (!p.songs.contains(song)) {
            p.songs.add(song)
            save()
        }
        true
    }

    /**
     * Add several songs at once.
     *
     * @return how many were new, or -1 if there is no such playlist.
     *
     * One save for the whole batch rather than one per song: adding fifty
     * tracks should not mean fifty rewrites of library.json, and the whole
     * selection landing together means a crash midway cannot leave a
     * playlist holding half of what was asked for.
     */
    fun addManyToPlaylist(id: String, songs: List<String>): Int = synchronized(lock) {
        ensureLoaded()
        val p = playlists.firstOrNull { it.id == id } ?: return -1
        var added = 0
        for (song in songs) {
            if (!p.songs.contains(song)) {
                p.songs.add(song)
                added++
            }
        }
        if (added > 0) save()
        added
    }

    fun removeFromPlaylist(id: String, song: String): Boolean = synchronized(lock) {
        ensureLoaded()
        val p = playlists.firstOrNull { it.id == id } ?: return false
        if (p.songs.remove(song)) save()
        true
    }

    /** Replace the order wholesale — what drag-to-reorder on the phone sends. */
    fun reorderPlaylist(id: String, order: List<String>): Boolean = synchronized(lock) {
        ensureLoaded()
        val p = playlists.firstOrNull { it.id == id } ?: return false
        val known = p.songs.toSet()
        val next = order.filter { known.contains(it) }.toMutableList()
        // Anything the client did not mention keeps its place at the end,
        // so a stale phone view cannot silently drop songs.
        p.songs.filterNot { next.contains(it) }.forEach { next.add(it) }
        p.songs.clear()
        p.songs.addAll(next)
        save()
        true
    }

    /**
     * A playlist's songs, filtered to those that still exist.
     *
     * [existing] is the live set of filenames from disk. Filtering at read
     * time rather than pruning on disk means a song deleted and re-uploaded
     * quietly reappears in the playlists it belonged to.
     */
    fun songsIn(id: String, existing: Set<String>): List<String> = synchronized(lock) {
        ensureLoaded()
        playlists.firstOrNull { it.id == id }?.songs?.filter { existing.contains(it) } ?: emptyList()
    }

    /** Drop a song from every playlist and list. Called when a file is deleted. */
    /**
     * A corrected title and artist for a song.
     *
     * Stored here rather than written into the file: retagging means
     * rewriting audio someone uploaded, and a bad write loses the song.
     * This is reversible, costs nothing, and is the only thing that reads
     * it — if library.json is lost the real tags simply come back.
     */
    fun setMeta(song: String, title: String, artist: String) = synchronized(lock) {
        ensureLoaded()
        if (title.isBlank() && artist.isBlank()) meta.remove(song)
        else meta[song] = title.trim() to artist.trim()
        save()
    }

    /** Corrected title to artist, or null when the file's own tags stand. */
    fun meta(song: String): Pair<String, String>? = synchronized(lock) {
        ensureLoaded()
        meta[song]
    }

    fun forget(song: String) = synchronized(lock) {
        // ensureLoaded first: removing from an empty in-memory model and
        // then loading the file would put the entry straight back.
        ensureLoaded()
        var changed = playlists.fold(false) { acc, p -> p.songs.remove(song) || acc }
        if (favourites.remove(song)) changed = true
        if (playCounts.remove(song) != null) changed = true
        if (meta.remove(song) != null) changed = true
        if (changed) save()
    }

    // ---------- Favourites and counts ----------

    fun isFavourite(song: String): Boolean = synchronized(lock) {
        ensureLoaded()
        favourites.contains(song)
    }

    fun toggleFavourite(song: String): Boolean = synchronized(lock) {
        ensureLoaded()
        val now = if (favourites.contains(song)) {
            favourites.remove(song); false
        } else {
            favourites.add(song); true
        }
        save()
        now
    }

    fun favourites(): Set<String> = synchronized(lock) {
        ensureLoaded()
        favourites.toSet()
    }

    fun playCount(song: String): Int = synchronized(lock) {
        ensureLoaded()
        playCounts[song] ?: 0
    }

    fun bumpPlayCount(song: String) = synchronized(lock) {
        ensureLoaded()
        playCounts[song] = (playCounts[song] ?: 0) + 1
        save()
    }

    // ---------- Wire format ----------

    fun json(existing: Set<String>): JSONObject = synchronized(lock) {
        ensureLoaded()
        JSONObject()
            .put("playlists", JSONArray().apply {
                playlists.forEach { p ->
                    val live = p.songs.filter { existing.contains(it) }
                    put(
                        JSONObject()
                            .put("id", p.id)
                            .put("name", p.name)
                            .put("created", p.created)
                            .put("count", live.size)
                            .put("songs", JSONArray().apply { live.forEach { put(it) } })
                    )
                }
            })
            .put("favourites", JSONArray().apply { favourites.forEach { put(it) } })
    }
}

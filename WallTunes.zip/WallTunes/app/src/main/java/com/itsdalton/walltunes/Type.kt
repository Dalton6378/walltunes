package com.itsdalton.walltunes

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat

/**
 * The app's typeface, applied in code rather than from XML.
 *
 * `android:fontFamily="@font/..."` only resolves as a resource reference on
 * API 26 and above, and minSdk here is 22 — plenty of Fire TV sticks are
 * older than that. `ResourcesCompat.getFont` backports it properly, so this
 * is the one place the family is decided and every screen inherits it.
 *
 * Both faces are static instances cut from the Outfit variable font. That
 * matters: the variable font's default weight is 100 (Thin), so shipping it
 * directly would have rendered the entire UI in hairline on any device that
 * cannot read the weight axis.
 */
object Type {

    private var regular: Typeface? = null
    private var medium: Typeface? = null

    /** Loaded once; a failure falls back to the system sans, never crashes. */
    fun regular(context: Context): Typeface {
        regular?.let { return it }
        val t = load(context, R.font.outfit_regular, Typeface.NORMAL)
        regular = t
        return t
    }

    fun medium(context: Context): Typeface {
        medium?.let { return it }
        val t = load(context, R.font.outfit_medium, Typeface.NORMAL)
        medium = t
        return t
    }

    private fun load(context: Context, id: Int, fallbackStyle: Int): Typeface =
        try {
            ResourcesCompat.getFont(context, id) ?: Typeface.defaultFromStyle(fallbackStyle)
        } catch (e: Exception) {
            // A missing or corrupt font must not take down a music player.
            Typeface.defaultFromStyle(fallbackStyle)
        }

    /**
     * Walk a view tree and apply the family to every TextView.
     *
     * Weight is chosen from the style already on the view: anything the
     * layout marked bold or medium gets the medium face, everything else
     * gets regular. That keeps the decision in the styles where it belongs
     * instead of duplicating a list of view ids here.
     */
    fun apply(root: View) {
        val context = root.context
        when (root) {
            is TextView -> {
                val wantsMedium = root.typeface?.isBold == true ||
                    root.typeface?.style == Typeface.BOLD
                root.typeface = if (wantsMedium) medium(context) else regular(context)
            }
            is ViewGroup -> {
                for (i in 0 until root.childCount) apply(root.getChildAt(i))
            }
        }
    }
}

package com.itsdalton.walltunes

import java.io.File
import java.io.RandomAccessFile

/**
 * Reads the things MediaMetadataRetriever will not give you: lyrics and
 * ReplayGain.
 *
 * Android exposes title, artist and duration and stops there. Both lyrics
 * and volume leveling live in tags the platform simply does not surface, so
 * they need reading by hand. Doing it once, here, means Phase 11's leveling
 * is nearly free — it is the same frames, already parsed.
 *
 * Everything is defensive to the point of paranoia. These are arbitrary
 * files on a machine that must keep playing music for months: a malformed
 * tag returns null, it never throws, and it never reads unbounded amounts
 * into memory.
 */
object Tags {

    /** One lyric line. [atMs] is -1 when the source had no timings. */
    data class Line(val atMs: Long, val text: String)

    data class Lyrics(val lines: List<Line>, val synced: Boolean)

    // ---------- Lyrics ----------

    /**
     * Lyrics for a song, preferring a sidecar .lrc file.
     *
     * The sidecar wins on purpose. It is the only source you can fix
     * yourself: drop Song.lrc next to Song.mp3 and it is picked up, with no
     * tagging software and nothing fetched from the internet.
     */
    fun lyricsFor(song: File): Lyrics? {
        sidecar(song)?.let { return it }
        return embedded(song)
    }

    private fun sidecar(song: File): Lyrics? = try {
        val lrc = File(song.parentFile, song.nameWithoutExtension + ".lrc")
        if (lrc.isFile && lrc.length() in 1..MAX_LYRIC_BYTES) {
            parseLrc(lrc.readText())
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Parse LRC.
     *
     * Format is `[mm:ss.xx] text`, and a single line may carry several
     * timestamps when a chorus repeats — each becomes its own entry.
     * Metadata lines like `[ar:...]` have no digits where a timestamp would
     * be, so they fall out naturally rather than needing a special case.
     */
    fun parseLrc(text: String): Lyrics? {
        val stamp = Regex("""\[(\d{1,3}):([0-5]?\d)(?:[.:](\d{1,3}))?]""")
        val out = mutableListOf<Line>()

        for (raw in text.lineSequence()) {
            val matches = stamp.findAll(raw).toList()
            if (matches.isEmpty()) continue

            val body = raw.substring(matches.last().range.last + 1).trim()
            if (body.isEmpty()) continue

            for (m in matches) {
                val min = m.groupValues[1].toLongOrNull() ?: continue
                val sec = m.groupValues[2].toLongOrNull() ?: continue
                val frac = m.groupValues[3]
                // ".5" means half a second, ".50" means the same, ".500" too.
                val ms = when (frac.length) {
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    3 -> frac.toLong()
                    else -> 0L
                }
                out.add(Line(min * 60_000 + sec * 1_000 + ms, body))
            }
        }

        if (out.isEmpty()) return null
        return Lyrics(out.sortedBy { it.atMs }, synced = true)
    }

    /**
     * Lyrics with no timing: every line carries -1, the same marker the
     * USLT path uses, so the renderer needs no third case.
     */
    fun parsePlain(text: String): Lyrics? {
        val lines = text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { Line(-1L, it) }
            .toList()
        return if (lines.isEmpty()) null else Lyrics(lines, synced = false)
    }

    /**
     * Parse whichever form the text turns out to be.
     *
     * A downloaded file is trusted to be what it claimed, but not blindly:
     * if it says it is synced and no timestamp survives parsing, it is still
     * readable as plain text rather than being thrown away.
     */
    fun parseAny(text: String): Lyrics? = parseLrc(text) ?: parsePlain(text)

    /** Unsynchronised lyrics from an ID3v2 USLT frame. */
    private fun embedded(song: File): Lyrics? {
        val uslt = id3Frame(song, "USLT") ?: return null
        return try {
            // encoding(1) + language(3) + null-terminated descriptor + text
            if (uslt.size < 5) return null
            val encoding = uslt[0].toInt()
            var i = 4
            // Skip the descriptor.
            if (encoding == 1 || encoding == 2) {
                while (i + 1 < uslt.size && !(uslt[i].toInt() == 0 && uslt[i + 1].toInt() == 0)) i += 2
                i += 2
            } else {
                while (i < uslt.size && uslt[i].toInt() != 0) i++
                i += 1
            }
            if (i >= uslt.size) return null

            val text = decode(uslt.copyOfRange(i, uslt.size), encoding)
            val lines = text.lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { Line(-1L, it) }
                .toList()

            if (lines.isEmpty()) null else Lyrics(lines, synced = false)
        } catch (e: Exception) {
            null
        }
    }

    // ---------- ReplayGain (used from Phase 11) ----------

    /**
     * Track gain in dB from a ReplayGain TXXX frame, or null.
     *
     * Values look like "-6.48 dB". Album gain is deliberately ignored:
     * this library is played on shuffle, so track gain is the right choice.
     */
    fun replayGainDb(song: File): Float? {
        val txxx = id3Frames(song, "TXXX")
        for (frame in txxx) {
            try {
                if (frame.isEmpty()) continue
                val encoding = frame[0].toInt()
                val body = decode(frame.copyOfRange(1, frame.size), encoding)
                // description NUL value, but decode() has already dropped
                // the encoding byte, so split on the separator.
                val parts = body.split('\u0000', limit = 2)
                if (parts.size != 2) continue
                if (!parts[0].trim().equals("replaygain_track_gain", ignoreCase = true)) continue
                val number = parts[1].trim().removeSuffix("dB").trim()
                return number.toFloatOrNull()
            } catch (e: Exception) {
                // Next frame.
            }
        }
        return null
    }

    // ---------- ID3v2 ----------

    private fun id3Frame(song: File, id: String): ByteArray? = id3Frames(song, id).firstOrNull()

    /**
     * Every frame with the given id.
     *
     * Only ID3v2.3 and 2.4 are handled — v2.2 used three-character ids and
     * is effectively extinct. Sizes are bounded so a corrupt length field
     * cannot make this allocate wildly.
     */
    private fun id3Frames(song: File, id: String): List<ByteArray> {
        val out = mutableListOf<ByteArray>()
        try {
            if (!song.isFile || song.length() < 10) return out
            RandomAccessFile(song, "r").use { f ->
                val header = ByteArray(10)
                if (f.read(header) != 10) return out
                if (header[0] != 'I'.code.toByte() ||
                    header[1] != 'D'.code.toByte() ||
                    header[2] != '3'.code.toByte()
                ) return out

                val major = header[3].toInt() and 0xFF
                if (major != 3 && major != 4) return out

                val tagSize = synchsafe(header, 6)
                if (tagSize <= 0 || tagSize > MAX_TAG_BYTES) return out

                var pos = 10L
                val end = 10L + tagSize
                val fh = ByteArray(10)

                while (pos + 10 <= end) {
                    f.seek(pos)
                    if (f.read(fh) != 10) break

                    val fid = String(fh, 0, 4, Charsets.ISO_8859_1)
                    // Padding: the rest of the tag is zeroes.
                    if (fid[0] == '\u0000') break

                    // v2.4 sizes are synchsafe; v2.3 sizes are plain.
                    val size = if (major == 4) synchsafe(fh, 4) else beInt(fh, 4)
                    if (size <= 0 || size > MAX_FRAME_BYTES || pos + 10 + size > end) break

                    if (fid == id) {
                        val body = ByteArray(size)
                        f.seek(pos + 10)
                        if (f.read(body) == size) out.add(body)
                    }
                    pos += 10 + size
                }
            }
        } catch (e: Exception) {
            // A tag we cannot read is a song without lyrics, not a crash.
        }
        return out
    }

    /** ID3 sizes use 7 bits per byte so they can never contain 0xFF. */
    private fun synchsafe(b: ByteArray, at: Int): Int =
        ((b[at].toInt() and 0x7F) shl 21) or
            ((b[at + 1].toInt() and 0x7F) shl 14) or
            ((b[at + 2].toInt() and 0x7F) shl 7) or
            (b[at + 3].toInt() and 0x7F)

    private fun beInt(b: ByteArray, at: Int): Int =
        ((b[at].toInt() and 0xFF) shl 24) or
            ((b[at + 1].toInt() and 0xFF) shl 16) or
            ((b[at + 2].toInt() and 0xFF) shl 8) or
            (b[at + 3].toInt() and 0xFF)

    private fun decode(bytes: ByteArray, encoding: Int): String = when (encoding) {
        1 -> String(bytes, Charsets.UTF_16)      // with BOM
        2 -> String(bytes, Charsets.UTF_16BE)    // without
        3 -> String(bytes, Charsets.UTF_8)
        else -> String(bytes, Charsets.ISO_8859_1)
    }.trim('\u0000', ' ', '\n', '\r')

    private const val MAX_TAG_BYTES = 2 * 1024 * 1024
    private const val MAX_FRAME_BYTES = 512 * 1024
    private const val MAX_LYRIC_BYTES = 256L * 1024
}

package com.itsdalton.walltunes

import java.io.InputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * One phone's server-sent-events connection, as a blocking InputStream.
 *
 * NanoHTTPD sends a chunked response by reading from a stream until it ends,
 * so an SSE feed is just a stream that blocks instead of finishing. Every
 * read parks the serving thread until there is something to say, which is
 * exactly the behaviour wanted: no polling, no busy loop, and the phone hears
 * about a change the moment it happens.
 *
 * Chosen over a WebSocket because this traffic only ever goes one way. SSE
 * needs no extra dependency, no handshake to get wrong, and EventSource
 * reconnects by itself when the TV reboots.
 */
class EventStream : InputStream() {

    private val queue = LinkedBlockingQueue<ByteArray>()
    private var current: ByteArray? = null
    private var pos = 0

    @Volatile
    private var closed = false

    /**
     * Queue one SSE message. Safe to call from any thread.
     *
     * @return false once this connection is dead and should be dropped.
     *
     * A phone that walks out of the house does not say goodbye. NanoHTTPD's
     * write fails and its serving thread ends, but nothing tells us — so the
     * backlog is the signal: if messages stop being consumed, nobody is
     * reading. Without this the subscriber set would grow by one every time
     * a phone reconnected, and a wall display runs for months.
     */
    fun push(json: String): Boolean {
        if (closed) return false
        if (queue.size > MAX_BACKLOG) {
            shutdown()
            return false
        }
        // Blank line terminates an event; without it the phone buffers
        // forever waiting for the rest.
        queue.offer(("data: " + json.replace("\n", " ") + "\n\n").toByteArray())
        return true
    }

    fun shutdown() {
        closed = true
        queue.offer(ByteArray(0))   // wake a parked reader so it can finish
    }

    override fun read(): Int {
        val buf = ready() ?: return -1
        val b = buf[pos++].toInt() and 0xFF
        if (pos >= buf.size) current = null
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val buf = ready() ?: return -1
        val n = minOf(len, buf.size - pos)
        System.arraycopy(buf, pos, b, off, n)
        pos += n
        if (pos >= buf.size) current = null
        return n
    }

    /**
     * Block until there are bytes, or the stream is finished.
     *
     * The timeout is the point: with nothing happening for twenty seconds a
     * comment line goes out instead. Phones and home routers drop idle
     * connections, and a silent SSE feed looks idle — the keepalive is what
     * stops the music app going quiet after a few minutes on the sofa.
     */
    private fun ready(): ByteArray? {
        while (true) {
            val buf = current
            if (buf != null && pos < buf.size) return buf
            if (closed && queue.isEmpty()) return null

            val next = queue.poll(20, TimeUnit.SECONDS)
            if (next == null) {
                current = KEEPALIVE
                pos = 0
                return current
            }
            if (next.isEmpty()) return null      // shutdown marker
            current = next
            pos = 0
        }
    }

    companion object {
        /** A comment line: valid SSE, ignored by EventSource. */
        private val KEEPALIVE = ": ping\n\n".toByteArray()

        /**
         * Unread messages tolerated before a connection is presumed dead.
         *
         * Generous enough that a briefly backgrounded phone recovers rather
         * than being dropped, small enough that a phone genuinely gone is
         * noticed within a handful of state changes.
         */
        private const val MAX_BACKLOG = 40
    }
}

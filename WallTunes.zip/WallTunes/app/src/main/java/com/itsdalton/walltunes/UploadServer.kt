package com.itsdalton.walltunes

import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Tiny web server on the TV (port 8080). Open it on your phone to upload songs,
 * delete them, and control playback.
 */
class UploadServer(private val svc: PlaybackService, port: Int) : NanoHTTPD(port) {

    private val audioTypes = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "opus", "wav")

    private val page: String by lazy {
        svc.assets.open("upload.html").bufferedReader().use { it.readText() }
    }

    override fun serve(session: IHTTPSession): Response {
        return try {
            val params = session.parameters
            fun param(key: String): String? = params[key]?.firstOrNull()
            val post = session.method == Method.POST

            when (session.uri) {
                "/", "/index.html" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", page)
                "/api/state" -> json(svc.stateJson())
                "/api/upload" -> if (post) upload(session, param("name")) else bad("Use POST")
                "/api/delete" -> {
                    val name = param("name")?.let { safeName(it) }
                    if (!post || name == null) bad("Missing song name")
                    else { svc.removeSong(name); json("""{"ok":true}""") }
                }
                "/api/control" -> {
                    val action = param("action")
                    if (!post || action == null) bad("Missing action")
                    else { svc.control(action, param("name")); json("""{"ok":true}""") }
                }
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", e.message ?: "Something went wrong")
        }
    }

    private fun upload(session: IHTTPSession, rawName: String?): Response {
        val name = rawName?.let { safeName(it) } ?: return bad("Missing file name")
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in audioTypes) return bad("$name isn't a music file WallTunes can play")
        val length = session.headers["content-length"]?.toLongOrNull() ?: return bad("Missing file size")

        val tmp = File(svc.musicDir, ".upload-" + System.nanoTime())
        try {
            tmp.outputStream().use { copyExactly(session.inputStream, it, length) }
            val dest = uniqueFile(name)
            if (!tmp.renameTo(dest)) throw IOException("Couldn't save $name")
            svc.addSong(dest)
            return json("""{"ok":true}""")
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    private fun copyExactly(input: InputStream, out: OutputStream, length: Long) {
        val buf = ByteArray(64 * 1024)
        var left = length
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw IOException("Upload was cut off")
            out.write(buf, 0, n)
            left -= n
        }
    }

    /** Strips folders and characters that can't be in a file name. */
    private fun safeName(raw: String): String? {
        val cleaned = raw.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\x00-\\x1F:*?\"<>|]"), "_")
            .trim().trimStart('.')
            .take(150)
        return cleaned.ifEmpty { null }
    }

    private fun uniqueFile(name: String): File {
        var f = File(svc.musicDir, name)
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.')
        var n = 2
        while (f.exists()) f = File(svc.musicDir, "$base ($n).$ext").also { n++ }
        return f
    }

    private fun json(body: String) = newFixedLengthResponse(Response.Status.OK, "application/json", body)

    private fun bad(msg: String) = newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", msg)
}

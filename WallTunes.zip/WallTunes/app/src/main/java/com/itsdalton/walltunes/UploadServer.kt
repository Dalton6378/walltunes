package com.itsdalton.walltunes

import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Tiny web server on the TV (port 8080). Open it on your phone to upload songs,
 * delete them, and control playback.
 */
class UploadServer(private val svc: PlaybackService, port: Int) : NanoHTTPD(port) {

    // Playable types come from the service, so the upload filter and the
    // library scanner can never disagree about what counts as a song.
    private val audioTypes = PlaybackService.AUDIO_TYPES

    // Lyrics ride alongside their song: Song.lrc next to Song.mp3. Accepted
    // for upload, but never treated as a library item.
    private val lyricTypes = setOf("lrc")

    private val page: String by lazy {
        svc.assets.open("upload.html").bufferedReader().use { it.readText() }
    }

    override fun serve(session: IHTTPSession): Response {
        return try {
            val params = session.parameters
            fun param(key: String): String? = params[key]?.firstOrNull()
            val post = session.method == Method.POST

            // Anything that changes state needs the PIN shown on the TV.
            // Reading state does not, so the phone page can render before
            // you have typed it.
            fun guarded(block: () -> Response): Response =
                if (!post) bad("Use POST")
                else if (!svc.checkPin(param("pin"))) unauthorized()
                else block()

            when (session.uri) {
                "/", "/index.html" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", page)

                // The phone app's own files. An allowlist rather than a
                // directory serve: this server sits on a home network and
                // should never be able to hand out anything not named here.
                "/app.css" -> asset("app.css", "text/css")
                "/app.js" -> asset("app.js", "application/javascript")
                "/manifest.json" -> asset("manifest.json", "application/manifest+json")
                "/icon.svg" -> asset("icon.svg", "image/svg+xml")

                // Cover art for one song. Browsers cache it hard, which
                // matters: the library grid asks for dozens at once and each
                // one costs a file open on the TV.
                "/api/art" -> art(param("name"))
                "/api/state" -> json(svc.stateJson())
                "/api/settings" ->
                    if (!post) json(svc.settingsJson())
                    else guarded { settings(params); json(svc.settingsJson()) }

                "/api/upload" -> if (!post) bad("Use POST")
                    else if (!svc.checkPin(param("pin"))) unauthorized()
                    else upload(session, param("name"))

                "/api/delete" -> guarded {
                    val name = param("name")?.let { safeName(it) }
                    if (name == null) bad("Missing song name")
                    else { svc.removeSong(name); json("""{"ok":true}""") }
                }

                // Deleting fifty songs one request at a time is slow and
                // leaves the library half-cleared if the phone drops off.
                "/api/delete-many" -> guarded {
                    val names = params["name"].orEmpty().mapNotNull { safeName(it) }
                    if (names.isEmpty()) bad("No songs given")
                    else {
                        names.forEach { svc.removeSong(it) }
                        json(JSONObject().put("ok", true).put("deleted", names.size).toString())
                    }
                }

                "/api/control" -> guarded {
                    val action = param("action")
                    if (action == null) bad("Missing action")
                    else { svc.control(action, param("name")); json("""{"ok":true}""") }
                }

                // ----- Playlists, favourites -----
                // Reading is open like /api/state; every mutation goes
                // through guarded(), so the PIN still gates everything that
                // changes something.
                "/api/playlists" -> json(svc.library.json(existingNames()).toString())

                "/api/playlist/create" -> guarded {
                    val name = param("name").orEmpty()
                    if (name.isBlank()) bad("Give the playlist a name")
                    else {
                        val pl = svc.library.createPlaylist(name)
                        json(JSONObject().put("ok", true).put("id", pl.id).toString())
                    }
                }

                "/api/playlist/rename" -> guarded {
                    val id = param("id"); val name = param("name")
                    if (id == null || name.isNullOrBlank()) bad("Missing playlist or name")
                    else if (svc.library.renamePlaylist(id, name)) ok() else notFound()
                }

                "/api/playlist/delete" -> guarded {
                    val id = param("id")
                    if (id == null) bad("Missing playlist")
                    else if (svc.library.deletePlaylist(id)) ok() else notFound()
                }

                "/api/playlist/add" -> guarded {
                    val id = param("id")
                    val song = param("name")?.let { safeName(it) }
                    if (id == null || song == null) bad("Missing playlist or song")
                    else if (svc.library.addToPlaylist(id, song)) ok() else notFound()
                }

                "/api/playlist/remove" -> guarded {
                    val id = param("id")
                    val song = param("name")?.let { safeName(it) }
                    if (id == null || song == null) bad("Missing playlist or song")
                    else if (svc.library.removeFromPlaylist(id, song)) ok() else notFound()
                }

                // Drag-to-reorder sends the whole order. Songs the client did
                // not mention keep their place, so a stale phone view cannot
                // silently drop tracks.
                "/api/playlist/reorder" -> guarded {
                    val id = param("id")
                    val order = params["name"].orEmpty().mapNotNull { safeName(it) }
                    if (id == null) bad("Missing playlist")
                    else if (svc.library.reorderPlaylist(id, order)) ok() else notFound()
                }

                "/api/playlist/play" -> guarded {
                    val id = param("id")
                    if (id == null) bad("Missing playlist")
                    else if (svc.playPlaylist(id)) ok()
                    else bad("That playlist has no songs that still exist")
                }

                // ----- Up Next -----
                "/api/queue/next" -> guarded {
                    val song = param("name")?.let { safeName(it) }
                    if (song == null) bad("Missing song") else { svc.queue(song, true); ok() }
                }

                "/api/queue/add" -> guarded {
                    val song = param("name")?.let { safeName(it) }
                    if (song == null) bad("Missing song") else { svc.queue(song, false); ok() }
                }

                "/api/queue/remove" -> guarded {
                    val song = param("name")?.let { safeName(it) }
                    if (song == null) bad("Missing song") else { svc.removeFromQueue(song); ok() }
                }

                "/api/queue/clear" -> guarded { svc.clearQueue(); ok() }

                "/api/favourite" -> guarded {
                    val song = param("name")?.let { safeName(it) }
                    if (song == null) bad("Missing song")
                    else json(
                        JSONObject().put("ok", true)
                            .put("favourite", svc.library.toggleFavourite(song)).toString()
                    )
                }

                // Lets the phone confirm a PIN before showing the controls,
                // instead of failing on the first real action.
                "/api/verify" -> if (!post) bad("Use POST")
                    else if (svc.checkPin(param("pin"))) json("""{"ok":true}""") else unauthorized()

                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", e.message ?: "Something went wrong")
        }
    }

    private fun upload(session: IHTTPSession, rawName: String?): Response {
        val name = rawName?.let { safeName(it) } ?: return bad("Missing file name")
        val ext = name.substringAfterLast('.', "").lowercase()
        val isLyrics = ext in lyricTypes
        if (ext !in audioTypes && !isLyrics) {
            return bad("$name isn't a music file WallTunes can play")
        }
        val length = session.headers["content-length"]?.toLongOrNull() ?: return bad("Missing file size")

        // Leave headroom. Filling the TV's internal storage does not just
        // break WallTunes, it breaks the TV — Fire OS starts misbehaving
        // well before the disk is genuinely full.
        val free = svc.freeBytes()
        if (length + HEADROOM_BYTES > free) {
            return bad("Not enough room on the TV for $name. ${mb(free)} MB free, needs ${mb(length)} MB.")
        }

        // Same song twice used to become "song (2).mp3" with no warning, so
        // libraries quietly filled with duplicates. Unless the phone says
        // "replace", refuse and say which song it clashes with.
        val replacing = session.parameters["replace"]?.firstOrNull() == "1" || isLyrics
        if (!replacing) {
            svc.findDuplicate(name, length)?.let { clash ->
                return newFixedLengthResponse(
                    Response.Status.CONFLICT, "application/json",
                    JSONObject().put("error", "duplicate").put("existing", clash).toString()
                )
            }
        }

        val tmp = File(svc.musicDir, ".upload-" + System.nanoTime())
        try {
            tmp.outputStream().use { copyExactly(session.inputStream, it, length) }
            if (replacing && !isLyrics) svc.findDuplicate(name, length)?.let { svc.removeSong(it) }

            // Lyrics overwrite in place by design: re-uploading Song.lrc
            // should replace the old words, not create "Song (2).lrc" that
            // nothing will ever look for.
            val dest = if (isLyrics) File(svc.musicDir, name) else uniqueFile(name)
            if (dest.exists() && isLyrics) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Couldn't save $name")

            if (!isLyrics) svc.addSong(dest)
            return json("""{"ok":true}""")
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    private fun copyExactly(input: InputStream, out: OutputStream, length: Long) {
        val buf = ByteArray(64 * 1024)
        var left = length
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw IOException("Upload was cut off")
            out.write(buf, 0, n)
            left -= n
        }
    }

    /** Strips folders and characters that can't be in a file name. */
    private fun safeName(raw: String): String? {
        val cleaned = raw.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\x00-\\x1F:*?\"<>|]"), "_")
            .trim().trimStart('.')
            .take(150)
        return cleaned.ifEmpty { null }
    }

    private fun uniqueFile(name: String): File {
        var f = File(svc.musicDir, name)
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.')
        var n = 2
        while (f.exists()) f = File(svc.musicDir, "$base ($n).$ext").also { n++ }
        return f
    }

    /** Applies whichever settings were included in the request. */
    private fun settings(params: Map<String, List<String>>) {
        fun int(key: String): Int? = params[key]?.firstOrNull()?.toIntOrNull()

        int("dayVolume")?.let { svc.putSetting("dayVolume", it) }
        int("nightVolume")?.let { svc.putSetting("nightVolume", it) }
        int("nightDim")?.let { svc.putSetting("nightDim", it) }
        int("nightStart")?.let { svc.putHour("nightStart", it) }
        int("nightEnd")?.let { svc.putHour("nightEnd", it) }
        int("sleep")?.let { svc.setSleep(it) }
        params["nightEnabled"]?.firstOrNull()?.let {
            svc.putFlag("nightEnabled", it == "1" || it.equals("true", true))
        }
    }

    /** Filenames that actually exist on disk right now. */
    private fun existingNames(): Set<String> = svc.songFiles().map { it.name }.toSet()

    private fun ok() = json("""{"ok":true}""")

    private fun notFound() =
        newFixedLengthResponse(Response.Status.NOT_FOUND, "application/json", """{"error":"not found"}""")

    /** Serve a bundled asset, or 404. */
    private fun asset(name: String, mime: String): Response = try {
        val bytes = svc.assets.open(name).use { it.readBytes() }
        newFixedLengthResponse(
            Response.Status.OK, mime, bytes.inputStream(), bytes.size.toLong()
        ).apply { addHeader("Cache-Control", "no-cache") }
    } catch (e: Exception) {
        newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
    }

    private fun art(rawName: String?): Response {
        val name = rawName?.let { safeName(it) }
            ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "No song")

        val bytes = svc.artworkFor(name)
            ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "No art")

        // Sniff rather than assume: embedded covers are usually JPEG but PNG
        // is common enough that guessing wrong shows up as a broken image.
        val png = bytes.size > 8 &&
            bytes[0] == 0x89.toByte() && bytes[1] == 'P'.code.toByte() &&
            bytes[2] == 'N'.code.toByte() && bytes[3] == 'G'.code.toByte()

        return newFixedLengthResponse(
            Response.Status.OK,
            if (png) "image/png" else "image/jpeg",
            bytes.inputStream(),
            bytes.size.toLong()
        ).apply {
            // Art for a given filename never changes; if the song is
            // replaced the name changes with it.
            addHeader("Cache-Control", "public, max-age=604800")
        }
    }

    private fun mb(bytes: Long): Long = bytes / 1_048_576

    private fun unauthorized() =
        newFixedLengthResponse(Response.Status.UNAUTHORIZED, "application/json", """{"error":"pin"}""")

    private fun json(body: String) = newFixedLengthResponse(Response.Status.OK, "application/json", body)

    private fun bad(msg: String) = newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", msg)

    companion object {
        /** Never let the library eat the last 300 MB of internal storage. */
        private const val HEADROOM_BYTES = 300L * 1024 * 1024
    }
}

package com.itsdalton.walltunes

import android.content.Context
import android.graphics.Bitmap
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.random.Random

/**
 * A slowly drifting grid of album covers.
 *
 * This is the one part of the app that can plausibly run out of memory, so
 * the budget is fixed in advance rather than discovered in production:
 *
 *   24 tiles, decoded at no more than 256px, in RGB_565.
 *   256 x 256 x 2 bytes = 128 KB each, so ~3 MB for the whole wall.
 *
 * RGB_565 rather than ARGB_8888 because covers are opaque — that alone
 * halves it. The same 24 tiles at 512px in ARGB_8888 would be 24 MB, which
 * on a 1 GB Fire TV already sharing RAM with four other apps is the
 * difference between smooth and swapping.
 *
 * Tiles are created once and reused forever. Drifting repositions the
 * container, never the children, and rotating a cover swaps a bitmap into an
 * existing ImageView. Nothing is allocated per frame.
 */
class ArtWallView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** Where covers come from. Implemented by MainActivity. */
    interface Source {
        fun songNames(): List<String>

        /** Loads off the main thread, calls back on it. Null means no art. */
        fun loadCover(song: String, sizePx: Int, done: (Bitmap?) -> Unit)
    }

    private val tiles = mutableListOf<ImageView>()
    private val shown = arrayOfNulls<String>(TILES)
    private var source: Source? = null
    private var running = false

    private var cols = 6
    private var rows = 4

    // ---------- Lifecycle ----------

    fun start(source: Source) {
        this.source = source
        if (running) return
        running = true
        buildTiles()
        fillAll()
        drift()
        postDelayed(rotate, ROTATE_MS)
    }

    /**
     * Stop and release every bitmap.
     *
     * Called when the mode leaves the screen. Without this the wall's few MB
     * would sit resident behind a now-playing screen that has no use for it,
     * which is exactly the kind of thing that turns into an out-of-memory
     * crash three days into an uptime.
     */
    fun stop() {
        running = false
        removeCallbacks(rotate)
        animate().cancel()
        for (t in tiles) {
            t.animate().cancel()
            t.setImageDrawable(null)
        }
        shown.fill(null)
    }

    // ---------- Grid ----------

    private fun buildTiles() {
        if (tiles.isNotEmpty()) return
        repeat(TILES) {
            val iv = ImageView(context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = 0f
            }
            addView(iv)
            tiles.add(iv)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldW: Int, oldH: Int) {
        super.onSizeChanged(w, h, oldW, oldH)
        if (w == 0 || h == 0) return
        layoutTiles(w, h)
    }

    private fun layoutTiles(w: Int, h: Int) {
        // Roughly square tiles, biased to landscape, always covering more
        // than the screen so drifting never exposes an edge.
        cols = 6
        rows = 4
        val tileW = (w * OVERSCAN / cols).toInt()
        val tileH = (h * OVERSCAN / rows).toInt()
        val offX = ((w - tileW * cols) / 2f).toInt()
        val offY = ((h - tileH * rows) / 2f).toInt()

        tiles.forEachIndexed { i, iv ->
            val c = i % cols
            val r = i / cols
            val lp = LayoutParams(tileW, tileH)
            lp.leftMargin = offX + c * tileW
            lp.topMargin = offY + r * tileH
            iv.layoutParams = lp
        }
    }

    // ---------- Content ----------

    private fun fillAll() {
        val songs = source?.songNames().orEmpty()
        if (songs.isEmpty()) return
        for (i in tiles.indices) assign(i, pick(songs, i))
    }

    /**
     * Choose a song for a tile.
     *
     * A library smaller than the grid repeats covers rather than leaving
     * holes — a wall with gaps in it looks broken, a wall with a repeat looks
     * deliberate.
     */
    private fun pick(songs: List<String>, index: Int): String =
        if (songs.size >= TILES) songs[Random.nextInt(songs.size)]
        else songs[index % songs.size]

    private fun assign(index: Int, song: String) {
        val iv = tiles.getOrNull(index) ?: return
        shown[index] = song
        source?.loadCover(song, TILE_PX) { bmp ->
            if (!running) return@loadCover
            // The tile may have been reassigned while this loaded.
            if (shown[index] != song) return@loadCover
            if (bmp == null) {
                iv.setImageResource(R.drawable.art_placeholder)
            } else {
                iv.setImageBitmap(bmp)
            }
            iv.animate().alpha(TILE_ALPHA).setDuration(TILE_FADE_MS).start()
        }
    }

    /** Swap one tile at a time, slowly, so the wall is never static. */
    private val rotate = object : Runnable {
        override fun run() {
            if (!running) return
            val songs = source?.songNames().orEmpty()
            if (songs.size > 1 && tiles.isNotEmpty()) {
                val i = Random.nextInt(tiles.size)
                val iv = tiles[i]
                val next = songs[Random.nextInt(songs.size)]
                if (next != shown[i]) {
                    iv.animate().alpha(0f).setDuration(TILE_FADE_MS)
                        .withEndAction { if (running) assign(i, next) }.start()
                }
            }
            postDelayed(this, ROTATE_MS)
        }
    }

    // ---------- Motion ----------

    /**
     * A very slow wander. Doubles as burn-in protection, which matters more
     * here than anywhere else: a static grid of bright squares is the worst
     * possible thing to leave on a panel overnight.
     */
    private fun drift() {
        if (!running) return
        animate()
            .translationX(Random.nextInt(-60, 61).toFloat())
            .translationY(Random.nextInt(-40, 41).toFloat())
            .setDuration(DRIFT_MS)
            .setInterpolator(LinearInterpolator())
            .withEndAction { drift() }
            .start()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        // Belt and braces: if the mode is hidden without stop() being called,
        // do not keep animating an invisible view forever.
        if (visibility != View.VISIBLE && running) stop()
    }

    companion object {
        /** The memory budget, in tiles. See the class comment. */
        const val TILES = 24

        /** Never decode a cover larger than this. */
        const val TILE_PX = 256

        private const val OVERSCAN = 1.25f
        private const val TILE_ALPHA = 0.55f
        private const val TILE_FADE_MS = 1200L
        private const val ROTATE_MS = 9_000L
        private const val DRIFT_MS = 45_000L
    }
}

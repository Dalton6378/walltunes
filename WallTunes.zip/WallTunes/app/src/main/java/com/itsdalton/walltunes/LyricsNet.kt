package com.itsdalton.walltunes

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Lyrics from LRCLIB, so songs get words without anyone tagging them.
 *
 * The sidecar-first rule in [Tags] does not change: a .lrc dropped next to a
 * song still wins, and so do embedded tags. This only fills the gap
 * underneath, which in practice is nearly the whole library — almost no
 * music arrives with synchronised lyrics already attached.
 *
 * LRCLIB was chosen because it needs no account, no key and no payment, and
 * because it answers with plain LRC, which is exactly the format
 * [Tags.parseLrc] already reads. What leaves the house is a song title, an
 * artist and a duration; nothing about the device, the library or the
 * listener. The whole thing is switchable off with one setting.
 *
 * Everything here runs off the main thread and every failure is a miss.
 * Lyrics are decoration: no network problem may ever stop music playing.
 */
object LyricsNet {

    private const val TAG = "LyricsNet"
    private const val BASE = "https://lrclib.net"

    /** Identifies the app, as the service asks clients to do. */
    private const val AGENT = "WallTunes/3.0 (https://itsdalton.com)"

    private const val CONNECT_MS = 8_000
    private const val READ_MS = 8_000

    /** A sane ceiling; real lyric files are far below this. */
    private const val MAX_BYTES = 200_000

    /**
     * How close a search hit's duration must be to the song's, in seconds.
     *
     * The same song exists many times over in a crowd-sourced database:
     * album cut, single edit, live version, a video rip with an intro.
     * Duration is the only signal separating them, and choosing wrong is
     * worse than showing nothing — lyrics that drift further out of time
     * with every line are more irritating than a blank screen.
     */
    private const val DURATION_SLOP_SEC = 6

    /** What a lookup produced. */
    sealed class Result {
        /** LRC or plain text, ready for the parser. */
        class Found(val text: String, val synced: Boolean) : Result()

        /** Known to have no words. Never ask again. */
        object Instrumental : Result()

        /** Nobody has these lyrics. Worth asking again much later. */
        object Missing : Result()

        /** Network or server trouble. Worth asking again soon. */
        object Failed : Result()
    }

    /**
     * Look a song up.
     *
     * Two attempts: an exact match on artist, title and duration, then a
     * looser search. The exact endpoint goes first because it cannot return
     * the wrong song, and it is one request rather than a list.
     */
    fun lookup(title: String, artist: String, album: String, durationMs: Long): Result {
        if (title.isBlank()) return Result.Missing
        val durSec = (durationMs / 1000L).toInt()

        try {
            val hit = exact(title, artist, album, durSec)
            if (hit != null) return hit
        } catch (e: Exception) {
            Log.w(TAG, "exact lookup failed: " + e.javaClass.simpleName)
            return Result.Failed
        }

        return try {
            search(title, artist, durSec)
        } catch (e: Exception) {
            Log.w(TAG, "search failed: " + e.javaClass.simpleName)
            Result.Failed
        }
    }

    /** The precise endpoint. null means "nothing there, try the search". */
    private fun exact(title: String, artist: String, album: String, durSec: Int): Result? {
        val url = StringBuilder(BASE).append("/api/get?track_name=").append(enc(title))
        if (artist.isNotBlank()) url.append("&artist_name=").append(enc(artist))
        if (album.isNotBlank()) url.append("&album_name=").append(enc(album))
        if (durSec > 0) url.append("&duration=").append(durSec)

        val body = get(url.toString()) ?: return null      // 404 is not an error
        return fromRecord(JSONObject(body))
    }

    /**
     * The fuzzy endpoint, for when the tags are not quite what the database
     * holds: a featured artist in the title, a remaster suffix, a missing
     * artist tag. Hits are ranked by how close the duration is.
     */
    private fun search(title: String, artist: String, durSec: Int): Result {
        val q = if (artist.isBlank()) title else title + " " + artist
        val body = get(BASE + "/api/search?q=" + enc(q)) ?: return Result.Missing
        val arr = JSONArray(body)
        if (arr.length() == 0) return Result.Missing

        var best: JSONObject? = null
        var bestScore = Int.MAX_VALUE

        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val synced = o.optString("syncedLyrics", "").isNotBlank()
            val plain = o.optString("plainLyrics", "").isNotBlank()
            if (!synced && !plain && !o.optBoolean("instrumental", false)) continue

            // With no duration to check against, the first hit carrying
            // words is the best guess available.
            if (durSec <= 0) {
                best = o
                bestScore = 0
                break
            }

            val d = o.optDouble("duration", -1.0)
            if (d <= 0) continue

            // A synced match is worth a second of slack over an unsynced one.
            val score = Math.abs(d.toInt() - durSec) + (if (synced) 0 else 1)
            if (score < bestScore) {
                bestScore = score
                best = o
            }
        }

        val pick = best ?: return Result.Missing
        if (durSec > 0 && bestScore > DURATION_SLOP_SEC) return Result.Missing
        return fromRecord(pick) ?: Result.Missing
    }

    /** Pull usable text out of one LRCLIB record. */
    private fun fromRecord(o: JSONObject): Result? {
        if (o.optBoolean("instrumental", false)) return Result.Instrumental

        val synced = o.optString("syncedLyrics", "")
        if (synced.isNotBlank()) return Result.Found(synced, true)

        val plain = o.optString("plainLyrics", "")
        if (plain.isNotBlank()) return Result.Found(plain, false)

        // A record carrying no words is, for our purposes, an instrumental.
        return Result.Instrumental
    }

    /**
     * One GET.
     *
     * Returns null for 404 and throws for anything that might succeed on a
     * later try. The caller has to tell those apart: one is a permanent
     * miss, the other is worth retrying.
     */
    private fun get(spec: String): String? {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(spec).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = CONNECT_MS
            conn.readTimeout = READ_MS
            conn.setRequestProperty("User-Agent", AGENT)
            conn.setRequestProperty("Accept", "application/json")
            conn.instanceFollowRedirects = true

            val code = conn.responseCode
            if (code == 404) return null
            if (code != 200) throw IllegalStateException("HTTP " + code)

            val raw = conn.inputStream.use { stream ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) throw IllegalStateException("response too large")
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
            return String(raw, Charsets.UTF_8)
        } finally {
            try {
                conn?.disconnect()
            } catch (e: Exception) {
                // Nothing useful to do; the request is already over.
            }
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // ---------------------------------------------------------------- Cache

    /**
     * Where a downloaded lyric file lives.
     *
     * Deliberately not beside the song. The music directory is the library:
     * [PlaybackService.songFiles] reads it, uploads land in it, and deleting
     * a song from the phone removes what is there. Downloads are a cache and
     * belong somewhere that can be wiped without touching anything real.
     */
    fun cacheFile(dir: File, song: String): File = File(dir, song + ".lrc")

    /**
     * A recorded miss, so a library of obscure songs is not re-asked about
     * on every screen. The file's own timestamp is the retry clock, which
     * means no extra bookkeeping and no state to corrupt.
     */
    fun missFile(dir: File, song: String): File = File(dir, song + ".miss")

    /** Instrumentals never gain words, so this marker never expires. */
    fun instrumentalFile(dir: File, song: String): File = File(dir, song + ".none")
}

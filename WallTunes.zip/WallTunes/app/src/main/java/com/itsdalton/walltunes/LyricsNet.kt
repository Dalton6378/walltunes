package com.itsdalton.walltunes

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Lyrics from LRCLIB, so songs get words without anyone tagging them.
 *
 * The sidecar-first rule in [Tags] does not change: a .lrc dropped next to a
 * song still wins, and so do embedded tags. This only fills the gap
 * underneath, which in practice is nearly the whole library — almost no
 * music arrives with synchronised lyrics already attached.
 *
 * LRCLIB was chosen because it needs no account, no key and no payment, and
 * because it answers with plain LRC, which is exactly the format
 * [Tags.parseLrc] already reads. What leaves the house is a song title, an
 * artist and a duration; nothing about the device, the library or the
 * listener. The whole thing is switchable off with one setting.
 *
 * Everything here runs off the main thread and every failure is a miss.
 * Lyrics are decoration: no network problem may ever stop music playing.
 */
object LyricsNet {

    private const val TAG = "LyricsNet"
    private const val BASE = "https://lrclib.net"

    /** Identifies the app, as the service asks clients to do. */
    private const val AGENT = "WallTunes/3.0 (https://itsdalton.com)"

    private const val CONNECT_MS = 8_000
    private const val READ_MS = 8_000

    /** A sane ceiling; real lyric files are far below this. */
    private const val MAX_BYTES = 200_000

    /**
     * How close a search hit's duration must be to the song's, in seconds.
     *
     * The same song exists many times over in a crowd-sourced database:
     * album cut, single edit, live version, a video rip with an intro.
     * Duration is the only signal separating them, and choosing wrong is
     * worse than showing nothing — lyrics that drift further out of time
     * with every line are more irritating than a blank screen.
     */
    private const val DURATION_SLOP_SEC = 6

    /** What a lookup produced. */
    sealed class Result {
        /** LRC or plain text, ready for the parser. */
        class Found(val text: String, val synced: Boolean) : Result()

        /** Known to have no words. Never ask again. */
        object Instrumental : Result()

        /** Nobody has these lyrics. Worth asking again much later. */
        object Missing : Result()

        /**
         * Network or server trouble. Worth asking again soon.
         *
         * Carries the reason because a failure that cannot be seen is a
         * feature that silently never works: without this the screen just
         * says "looking" forever and nobody can tell why.
         */
        class Failed(val reason: String) : Result()
    }

    /**
     * Tidy a title before searching.
     *
     * Files are named by whoever made them, and a database keyed on real
     * song titles will not match "03 - Song Name (Official Video) [HD]".
     * Everything stripped here is packaging, never part of a song's name.
     */
    fun cleanTitle(raw: String): String {
        var s = raw.replace('_', ' ')
        // Bracketed asides: video, remaster, audio quality, lyric-video tags.
        s = Regex("""[\(\[]\s*(official|lyric|audio|video|hd|hq|4k|mv|m/v|full|remaster(ed)?|explicit|clean|visualizer|live|color coded)[^\)\]]*[\)\]]""",
            RegexOption.IGNORE_CASE).replace(s, " ")
        s = stripTrackNumber(s)
        // Featured artists belong in the artist field, not the title.
        //
        // The leading [\s\(\[]+ is load-bearing: without it "ft" matches
        // inside ordinary words and "Daft Punk - Instant Crush" is cut down
        // to "Da". Requiring a space or a bracket in front means only a
        // standalone "ft" counts.
        s = Regex("""[\s\(\[]+(feat\.?|ft\.?|featuring)\s+[^\)\]]*[\)\]]?\s*$""",
            RegexOption.IGNORE_CASE).replace(s, "")
        return s.replace(Regex("""\s{2,}"""), " ").trim().trim('-', '.', ' ')
    }

    /** "03 ", "03. ", "03 - " at the front of a filename. */
    private fun stripTrackNumber(s: String): String =
        Regex("""^\s*\d{1,3}\s*[-._)]\s*|^\s*\d{1,3}\s+""").replace(s, "")

    /**
     * Guess artist and title from a filename when the tags are empty.
     *
     * "Artist - Title.mp3" is overwhelmingly the convention, and an untagged
     * library is exactly the case that most needs lyrics fetched for it —
     * searching for the whole filename as a title finds nothing.
     *
     * @return artist to title, with artist blank when there is no clue.
     */
    fun splitFilename(base: String): Pair<String, String> {
        // Underscores first, then the track number: "03_-_Artist_-_Song" has
        // to become "Artist - Song" before there is a separator to split on
        // at all, and the number would otherwise be taken for the artist.
        val s = stripTrackNumber(base.replace('_', ' ')).trim()

        // Only the FIRST separator: "Artist - Song - Live" is artist then
        // the rest, not artist, song and a stray third field.
        val m = Regex("""^(.{1,60}?)\s+[-–—]\s+(.+)$""").find(s) ?: return "" to cleanTitle(s)
        val left = m.groupValues[1].trim()
        val right = m.groupValues[2].trim()
        if (left.isBlank()) return "" to cleanTitle(right)
        return cleanTitle(left) to cleanTitle(right)
    }

    /**
     * Look a song up.
     *
     * Two attempts: an exact match on artist, title and duration, then a
     * looser search. The exact endpoint goes first because it cannot return
     * the wrong song, and it is one request rather than a list.
     */
    fun lookup(title: String, artist: String, album: String, durationMs: Long): Result {
        if (title.isBlank()) return Result.Missing
        val durSec = (durationMs / 1000L).toInt()

        // Several goes at saying who this is. The first that produces words
        // wins; a miss just moves on to a looser guess. This is what makes
        // an untagged library work rather than only a well-tagged one.
        val attempts = ArrayList<Pair<String, String>>()
        attempts.add(cleanTitle(title) to artist.trim())
        if (artist.isBlank()) {
            // No artist tag: the filename is the only clue there is.
            val (a, t) = splitFilename(title)
            if (a.isNotBlank()) attempts.add(t to a)
        }
        // Last resort: the title alone, which the search can still match.
        attempts.add(cleanTitle(title) to "")

        var failure: String? = null
        val tried = HashSet<Pair<String, String>>()

        for ((t, a) in attempts) {
            if (t.isBlank() || !tried.add(t to a)) continue
            try {
                val hit = exact(t, a, album, durSec)
                if (hit != null && hit !is Result.Missing) return hit
            } catch (e: Exception) {
                failure = describe(e)
                Log.w(TAG, "exact lookup failed: " + failure)
            }
            try {
                val hit = search(t, a, durSec)
                if (hit !is Result.Missing) return hit
            } catch (e: Exception) {
                failure = describe(e)
                Log.w(TAG, "search failed: " + failure)
            }
        }

        // Every attempt came back empty rather than broken: nobody has it.
        return if (failure == null) Result.Missing else Result.Failed(failure)
    }

    /** A reason a person can act on, not just an exception class name. */
    private fun describe(e: Exception): String {
        val n = e.javaClass.simpleName
        val m = e.message.orEmpty()
        return when {
            n.contains("UnknownHost") -> "No internet connection on the TV"
            n.contains("SSL") || n.contains("Certificate") ->
                "Secure connection refused (" + n + ")"
            n.contains("SocketTimeout") || n.contains("ConnectTimeout") ->
                "The lyrics service timed out"
            m.startsWith("HTTP 429") -> "The lyrics service is rate limiting us"
            m.startsWith("HTTP") -> "The lyrics service said " + m
            else -> n + (if (m.isBlank()) "" else ": " + m)
        }
    }

    /** One live lookup, with the reason on failure, for the diagnostics. */
    fun probe(): String? = try {
        get(BASE + "/api/search?q=" + enc("hello adele"))
        null
    } catch (e: Exception) {
        describe(e)
    }

    /**
     * The precise endpoint. null means "nothing there, try the search".
     *
     * Requires an artist: without one the service answers 400, so there is
     * nothing to be gained by asking and — before this check existed — a
     * great deal to lose, because that 400 looked like a broken connection.
     */
    private fun exact(title: String, artist: String, album: String, durSec: Int): Result? {
        if (artist.isBlank()) return null
        val url = StringBuilder(BASE).append("/api/get?track_name=").append(enc(title))
        url.append("&artist_name=").append(enc(artist))
        if (album.isNotBlank()) url.append("&album_name=").append(enc(album))
        if (durSec > 0) url.append("&duration=").append(durSec)

        val body = get(url.toString()) ?: return null      // 404 is not an error
        return fromRecord(JSONObject(body))
    }

    /**
     * The fuzzy endpoint, for when the tags are not quite what the database
     * holds: a featured artist in the title, a remaster suffix, a missing
     * artist tag. Hits are ranked by how close the duration is.
     */
    private fun search(title: String, artist: String, durSec: Int): Result {
        val q = if (artist.isBlank()) title else title + " " + artist
        val body = get(BASE + "/api/search?q=" + enc(q)) ?: return Result.Missing
        val arr = JSONArray(body)
        if (arr.length() == 0) return Result.Missing

        var best: JSONObject? = null
        var bestScore = Int.MAX_VALUE

        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val synced = o.optString("syncedLyrics", "").isNotBlank()
            val plain = o.optString("plainLyrics", "").isNotBlank()
            if (!synced && !plain && !o.optBoolean("instrumental", false)) continue

            // With no duration to check against, rank by what the entry
            // actually carries. Taking the first hit outright would settle
            // on an instrumental version of a song that has words — and
            // that verdict is recorded permanently, so it has to be right.
            if (durSec <= 0) {
                val rank = if (synced) 0 else if (plain) 1 else 2
                if (rank < bestScore) {
                    bestScore = rank
                    best = o
                }
                if (rank == 0) break        // nothing beats synced words
                continue
            }

            val d = o.optDouble("duration", -1.0)
            if (d <= 0) continue

            // A synced match is worth a second of slack over an unsynced one.
            val score = Math.abs(d.toInt() - durSec) + (if (synced) 0 else 1)
            if (score < bestScore) {
                bestScore = score
                best = o
            }
        }

        val pick = best ?: return Result.Missing
        if (durSec > 0 && bestScore > DURATION_SLOP_SEC) return Result.Missing
        return fromRecord(pick) ?: Result.Missing
    }

    /** Pull usable text out of one LRCLIB record. */
    private fun fromRecord(o: JSONObject): Result? {
        if (o.optBoolean("instrumental", false)) return Result.Instrumental

        val synced = o.optString("syncedLyrics", "")
        if (synced.isNotBlank()) return Result.Found(synced, true)

        val plain = o.optString("plainLyrics", "")
        if (plain.isNotBlank()) return Result.Found(plain, false)

        // A record carrying no words is, for our purposes, an instrumental.
        return Result.Instrumental
    }

    /**
     * One GET.
     *
     * Returns null for 404 and throws for anything that might succeed on a
     * later try. The caller has to tell those apart: one is a permanent
     * miss, the other is worth retrying.
     */
    private fun get(spec: String): String? {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(spec).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = CONNECT_MS
            conn.readTimeout = READ_MS
            conn.setRequestProperty("User-Agent", AGENT)
            conn.setRequestProperty("Accept", "application/json")
            conn.instanceFollowRedirects = true

            val code = conn.responseCode
            // 4xx means this particular request will never work, so it is an
            // answer, not an outage — with one exception. Only 429 and the
            // 5xx range are worth calling a failure and retrying, and only
            // those should ever be reported as something being wrong.
            if (code == 429) throw IllegalStateException("HTTP 429")
            if (code in 400..499) return null
            if (code != 200) throw IllegalStateException("HTTP " + code)

            val raw = conn.inputStream.use { stream ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) throw IllegalStateException("response too large")
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
            return String(raw, Charsets.UTF_8)
        } finally {
            try {
                conn?.disconnect()
            } catch (e: Exception) {
                // Nothing useful to do; the request is already over.
            }
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // ---------------------------------------------------------------- Cache

    /**
     * Where a downloaded lyric file lives.
     *
     * Deliberately not beside the song. The music directory is the library:
     * [PlaybackService.songFiles] reads it, uploads land in it, and deleting
     * a song from the phone removes what is there. Downloads are a cache and
     * belong somewhere that can be wiped without touching anything real.
     */
    fun cacheFile(dir: File, song: String): File = File(dir, song + ".lrc")

    /**
     * A recorded miss, so a library of obscure songs is not re-asked about
     * on every screen. The file's own timestamp is the retry clock, which
     * means no extra bookkeeping and no state to corrupt.
     */
    fun missFile(dir: File, song: String): File = File(dir, song + ".miss")

    /** Instrumentals never gain words, so this marker never expires. */
    fun instrumentalFile(dir: File, song: String): File = File(dir, song + ".none")
}

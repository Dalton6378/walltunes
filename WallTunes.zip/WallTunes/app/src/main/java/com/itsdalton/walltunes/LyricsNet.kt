package com.itsdalton.walltunes

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Lyrics from LRCLIB, so songs get words without anyone tagging them.
 *
 * The sidecar-first rule in [Tags] does not change: a .lrc dropped next to a
 * song still wins, and so do embedded tags. This only fills the gap
 * underneath, which in practice is nearly the whole library — almost no
 * music arrives with synchronised lyrics already attached.
 *
 * LRCLIB was chosen because it needs no account, no key and no payment, and
 * because it answers with plain LRC, which is exactly the format
 * [Tags.parseLrc] already reads. What leaves the house is a song title, an
 * artist and a duration; nothing about the device, the library or the
 * listener. The whole thing is switchable off with one setting.
 *
 * Everything here runs off the main thread and every failure is a miss.
 * Lyrics are decoration: no network problem may ever stop music playing.
 */
object LyricsNet {

    private const val TAG = "LyricsNet"
    private const val BASE = "https://lrclib.net"

    /** Identifies the app, as the service asks clients to do. */
    private const val AGENT = "WallTunes/3.0 (https://itsdalton.com)"

    private const val CONNECT_MS = 8_000
    private const val READ_MS = 8_000

    /** A sane ceiling; real lyric files are far below this. */
    private const val MAX_BYTES = 200_000

    /**
     * How far a candidate's duration may be from the song's, in seconds.
     *
     * The same song exists many times over in a crowd-sourced database:
     * album cut, single edit, live version, a video rip with an intro.
     * Duration is the strongest signal separating them, and choosing wrong
     * is worse than showing nothing — lyrics that drift further out of time
     * with every line are more irritating than a blank screen.
     */
    private const val MAX_DURATION_DELTA_SEC = 12.0

    /**
     * How much of the song the timestamps must span.
     *
     * This is "the lyrics stop partway through" made into a number. Real
     * sheets reach 85-99%; anything that gives up at a third of the way is
     * a fragment, and a fragment on screen looks exactly like a feature
     * that broke halfway.
     */
    private const val MIN_COVERAGE = 0.55

    /** Fewer lines than this is a stub or a placeholder, not a lyric sheet. */
    private const val MIN_LINES = 5

    /** Below these the candidate is a different song, or someone's cover. */
    private const val MIN_TITLE_SIM = 0.60
    private const val MIN_ARTIST_SIM = 0.55

    /** Timestamp form shared with [Tags]; see that parser for the grammar. */
    private val STAMP = Regex("""\[(\d{1,3}):([0-5]?\d)(?:[.:](\d{1,3}))?]""")

    /** What a lookup produced. */
    sealed class Result {
        /** LRC or plain text, ready for the parser. */
        class Found(val text: String, val synced: Boolean) : Result()

        /** Known to have no words. Never ask again. */
        object Instrumental : Result()

        /** Nobody has these lyrics. Worth asking again much later. */
        object Missing : Result()

        /**
         * Network or server trouble. Worth asking again soon.
         *
         * Carries the reason because a failure that cannot be seen is a
         * feature that silently never works: without this the screen just
         * says "looking" forever and nobody can tell why.
         */
        class Failed(val reason: String) : Result()
    }

    /**
     * Tidy a title before searching.
     *
     * Files are named by whoever made them, and a database keyed on real
     * song titles will not match "03 - Song Name (Official Video) [HD]".
     * Everything stripped here is packaging, never part of a song's name.
     */
    fun cleanTitle(raw: String): String {
        var s = raw.replace('_', ' ')
        // Bracketed asides: video, remaster, audio quality, lyric-video tags.
        s = Regex("""[\(\[]\s*(official|lyric|audio|video|hd|hq|4k|mv|m/v|full|remaster(ed)?|explicit|clean|visualizer|live|color coded)[^\)\]]*[\)\]]""",
            RegexOption.IGNORE_CASE).replace(s, " ")
        s = stripTrackNumber(s)
        // Featured artists belong in the artist field, not the title.
        //
        // The leading [\s\(\[]+ is load-bearing: without it "ft" matches
        // inside ordinary words and "Daft Punk - Instant Crush" is cut down
        // to "Da". Requiring a space or a bracket in front means only a
        // standalone "ft" counts.
        s = Regex("""[\s\(\[]+(feat\.?|ft\.?|featuring)\s+[^\)\]]*[\)\]]?\s*$""",
            RegexOption.IGNORE_CASE).replace(s, "")
        return s.replace(Regex("""\s{2,}"""), " ").trim().trim('-', '.', ' ')
    }

    /** "03 ", "03. ", "03 - " at the front of a filename. */
    private fun stripTrackNumber(s: String): String =
        Regex("""^\s*\d{1,3}\s*[-._)]\s*|^\s*\d{1,3}\s+""").replace(s, "")

    /**
     * Guess artist and title from a filename when the tags are empty.
     *
     * "Artist - Title.mp3" is overwhelmingly the convention, and an untagged
     * library is exactly the case that most needs lyrics fetched for it —
     * searching for the whole filename as a title finds nothing.
     *
     * @return artist to title, with artist blank when there is no clue.
     */
    fun splitFilename(base: String): Pair<String, String> {
        // Underscores first, then the track number: "03_-_Artist_-_Song" has
        // to become "Artist - Song" before there is a separator to split on
        // at all, and the number would otherwise be taken for the artist.
        val s = stripTrackNumber(base.replace('_', ' ')).trim()

        // Only the FIRST separator: "Artist - Song - Live" is artist then
        // the rest, not artist, song and a stray third field.
        val m = Regex("""^(.{1,60}?)\s+[-–—]\s+(.+)$""").find(s) ?: return "" to cleanTitle(s)
        val left = m.groupValues[1].trim()
        val right = m.groupValues[2].trim()
        if (left.isBlank()) return "" to cleanTitle(right)
        return cleanTitle(left) to cleanTitle(right)
    }

    /**
     * Look a song up.
     *
     * Two attempts: an exact match on artist, title and duration, then a
     * looser search. The exact endpoint goes first because it cannot return
     * the wrong song, and it is one request rather than a list.
     */
    fun lookup(title: String, artist: String, album: String, durationMs: Long): Result {
        if (title.isBlank()) return Result.Missing
        val durSec = (durationMs / 1000L).toInt()


        // Several goes at saying who this is. The first that produces words
        // wins; a miss just moves on to a looser guess. This is what makes
        // an untagged library work rather than only a well-tagged one.
        val attempts = ArrayList<Pair<String, String>>()
        attempts.add(cleanTitle(title) to artist.trim())
        if (artist.isBlank()) {
            // No artist tag: the filename is the only clue there is.
            val (a, t) = splitFilename(title)
            if (a.isNotBlank()) attempts.add(t to a)
        }
        // Last resort: the title alone, which the search can still match.
        attempts.add(cleanTitle(title) to "")

        var failure: String? = null
        val tried = HashSet<Pair<String, String>>()

        for ((t, a) in attempts) {
            if (t.isBlank() || !tried.add(t to a)) continue
            try {
                val hit = exact(t, a, album, durSec)
                if (hit != null && hit !is Result.Missing) return hit
            } catch (e: Exception) {
                failure = describe(e)
                Log.w(TAG, "exact lookup failed: " + failure)
            }
            try {
                val hit = search(t, a, durationMs)
                if (hit !is Result.Missing) return hit
            } catch (e: Exception) {
                failure = describe(e)
                Log.w(TAG, "search failed: " + failure)
            }
        }

        // Every attempt came back empty rather than broken: nobody has it.
        return if (failure == null) Result.Missing else Result.Failed(failure)
    }

    /** A reason a person can act on, not just an exception class name. */
    private fun describe(e: Exception): String {
        val n = e.javaClass.simpleName
        val m = e.message.orEmpty()
        return when {
            n.contains("UnknownHost") -> "No internet connection on the TV"
            n.contains("SSL") || n.contains("Certificate") ->
                "Secure connection refused (" + n + ")"
            n.contains("SocketTimeout") || n.contains("ConnectTimeout") ->
                "The lyrics service timed out"
            m.startsWith("HTTP 429") -> "The lyrics service is rate limiting us"
            m.startsWith("HTTP") -> "The lyrics service said " + m
            else -> n + (if (m.isBlank()) "" else ": " + m)
        }
    }

    /** One live lookup, with the reason on failure, for the diagnostics. */
    fun probe(): String? = try {
        get(BASE + "/api/search?q=" + enc("hello adele"))
        null
    } catch (e: Exception) {
        describe(e)
    }

    /**
     * The precise endpoint. null means "nothing there, try the search".
     *
     * Requires an artist: without one the service answers 400, so there is
     * nothing to be gained by asking and — before this check existed — a
     * great deal to lose, because that 400 looked like a broken connection.
     */
    private fun exact(title: String, artist: String, album: String, durSec: Int): Result? {
        if (artist.isBlank()) return null
        val url = StringBuilder(BASE).append("/api/get?track_name=").append(enc(title))
        url.append("&artist_name=").append(enc(artist))
        if (album.isNotBlank()) url.append("&album_name=").append(enc(album))
        if (durSec > 0) url.append("&duration=").append(durSec)

        val body = get(url.toString()) ?: return null      // 404 is not an error
        return fromRecord(JSONObject(body))
    }

    /**
     * One entry from the database, with everything needed to judge it.
     *
     * [coverage] is the last timestamp over the song's real length. It is
     * the measurable form of "the lyrics stop partway through": a file
     * covering 40% of a song is a fragment, and on screen a fragment is
     * indistinguishable from lyrics that failed to load.
     */
    class Candidate(
        val index: Int,
        val artist: String,
        val track: String,
        val durationMs: Long,
        val synced: Boolean,
        val text: String,
        val lines: Int,
        val coverage: Double,
        val instrumental: Boolean,
        var score: Double?
    )

    /**
     * Every plausible match, best first, scored.
     *
     * Returned whole — including the ones that were refused — so a person
     * can overrule the choice. Automatic matching is right most of the
     * time, and the remaining times need an answer that is not "too bad".
     */
    fun candidates(title: String, artist: String, durationMs: Long): List<Candidate> {
        val t = cleanTitle(title)
        var a = artist.trim()
        if (a.isBlank()) {
            val (guessA, guessT) = splitFilename(title)
            if (guessA.isNotBlank()) a = guessA
            if (guessA.isNotBlank() && guessT.isNotBlank()) {
                return rank(fetchCandidates(guessT, a), guessT, a, durationMs)
            }
        }
        return rank(fetchCandidates(t, a), t, a, durationMs)
    }

    private fun fetchCandidates(title: String, artist: String): List<Candidate> {
        val q = (title + " " + artist).trim()
        val body = get(BASE + "/api/search?q=" + enc(q)) ?: return emptyList()
        val arr = JSONArray(body)
        val out = ArrayList<Candidate>()

        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val syncedText = o.optString("syncedLyrics", "").trim()
            val plainText = o.optString("plainLyrics", "").trim()
            val instrumental = o.optBoolean("instrumental", false)
            if (syncedText.isEmpty() && plainText.isEmpty() && !instrumental) continue

            val synced = syncedText.isNotEmpty()
            val text = if (synced) syncedText else plainText
            val durMs = (o.optDouble("duration", 0.0) * 1000).toLong()
            val coverage =
                if (synced && durMs > 0) lastStampMs(syncedText).toDouble() / durMs else -1.0

            out.add(
                Candidate(
                    index = out.size,
                    artist = o.optString("artistName", ""),
                    track = o.optString("trackName", ""),
                    durationMs = durMs,
                    synced = synced,
                    text = text,
                    lines = countLines(text, synced),
                    coverage = coverage,
                    instrumental = instrumental,
                    score = null
                )
            )
        }
        return out
    }

    /** Score every candidate and sort; refused ones keep a null score. */
    private fun rank(
        list: List<Candidate>,
        title: String,
        artist: String,
        durationMs: Long
    ): List<Candidate> {
        for (c in list) c.score = scoreOf(c, title, artist, durationMs)
        // Accepted first, best score leading; refused ones stay at the back
        // in their original order so the picker can still offer them.
        return list.sortedWith(compareBy({ it.score == null }, { it.score ?: 0.0 }))
    }

    /**
     * How good a match this is; null refuses it outright.
     *
     * Every refusal here is a specific way of being wrong that was showing
     * up in practice: a cover by someone else, a live cut twice the length,
     * an instrumental of a song with words, a two-line stub, or a sheet
     * that stops a third of the way through.
     */
    private fun scoreOf(c: Candidate, title: String, artist: String, durationMs: Long): Double? {
        if (c.instrumental) return null
        if (c.lines < MIN_LINES) return null

        val titleSim = similar(title, c.track)
        if (titleSim < MIN_TITLE_SIM) return null
        if (artist.isNotBlank() && similar(artist, c.artist) < MIN_ARTIST_SIM) return null

        var s = 0.0
        if (durationMs > 0 && c.durationMs > 0) {
            val delta = Math.abs(c.durationMs - durationMs) / 1000.0
            if (delta > MAX_DURATION_DELTA_SEC) return null
            s += delta
        }
        s += (1.0 - titleSim) * 10
        if (!c.synced) s += 8.0                     // timed words are worth a lot
        if (c.coverage >= 0) {
            if (c.coverage < MIN_COVERAGE) return null
            s += (1.0 - c.coverage) * 12
        }
        return s
    }

    /** The last timestamp in an LRC, in milliseconds. */
    fun lastStampMs(lrc: String): Long {
        var best = 0L
        for (m in STAMP.findAll(lrc)) {
            val min = m.groupValues[1].toLongOrNull() ?: continue
            val sec = m.groupValues[2].toLongOrNull() ?: continue
            val f = m.groupValues[3]
            val ms = when (f.length) {
                1 -> f.toLong() * 100
                2 -> f.toLong() * 10
                3 -> f.toLong()
                else -> 0L
            }
            val at = min * 60_000 + sec * 1_000 + ms
            if (at > best) best = at
        }
        return best
    }

    private fun countLines(text: String, synced: Boolean): Int =
        if (synced) text.lineSequence().count { STAMP.containsMatchIn(it) }
        else text.lineSequence().count { it.isNotBlank() }

    /** Words, lowercased, with punctuation and bracketed asides removed. */
    private fun words(s: String): Set<String> {
        var t = s.lowercase()
        t = Regex("""[\(\[].*?[\)\]]""").replace(t, " ")
        t = Regex("""[^a-z0-9 ]""").replace(t, " ")
        return t.split(' ').filter { it.isNotBlank() }.toSet()
    }

    /**
     * Dice coefficient over word sets.
     *
     * Deliberately not an edit distance: "Queen" against "Queen - Topic"
     * and "Take On Me" against "Take on Me (Remastered)" both need to read
     * as the same thing, and word overlap handles that without caring about
     * order or trailing noise.
     */
    fun similar(a: String, b: String): Double {
        val x = words(a)
        val y = words(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        val shared = x.count { y.contains(it) }
        return 2.0 * shared / (x.size + y.size)
    }

    /**
     * The best candidate the database has, or Missing.
     *
     * Everything that decides "good enough" lives in [scoreOf]; this only
     * asks for the ranking and takes the head of it.
     */
    private fun search(title: String, artist: String, durationMs: Long): Result {
        val ranked = rank(fetchCandidates(title, artist), title, artist, durationMs)
        val best = ranked.firstOrNull { it.score != null } ?: return Result.Missing
        return Result.Found(best.text, best.synced)
    }

    /** Pull usable text out of one LRCLIB record. */
    private fun fromRecord(o: JSONObject): Result? {
        if (o.optBoolean("instrumental", false)) return Result.Instrumental

        val synced = o.optString("syncedLyrics", "")
        if (synced.isNotBlank()) return Result.Found(synced, true)

        val plain = o.optString("plainLyrics", "")
        if (plain.isNotBlank()) return Result.Found(plain, false)

        // A record carrying no words is, for our purposes, an instrumental.
        return Result.Instrumental
    }

    /**
     * One GET.
     *
     * Returns null for 404 and throws for anything that might succeed on a
     * later try. The caller has to tell those apart: one is a permanent
     * miss, the other is worth retrying.
     */
    private fun get(spec: String): String? {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(spec).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = CONNECT_MS
            conn.readTimeout = READ_MS
            conn.setRequestProperty("User-Agent", AGENT)
            conn.setRequestProperty("Accept", "application/json")
            conn.instanceFollowRedirects = true

            val code = conn.responseCode
            // 4xx means this particular request will never work, so it is an
            // answer, not an outage — with one exception. Only 429 and the
            // 5xx range are worth calling a failure and retrying, and only
            // those should ever be reported as something being wrong.
            if (code == 429) throw IllegalStateException("HTTP 429")
            if (code in 400..499) return null
            if (code != 200) throw IllegalStateException("HTTP " + code)

            val raw = conn.inputStream.use { stream ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) throw IllegalStateException("response too large")
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
            return String(raw, Charsets.UTF_8)
        } finally {
            try {
                conn?.disconnect()
            } catch (e: Exception) {
                // Nothing useful to do; the request is already over.
            }
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // ---------------------------------------------------------------- Cache

    /**
     * Where a downloaded lyric file lives.
     *
     * Deliberately not beside the song. The music directory is the library:
     * [PlaybackService.songFiles] reads it, uploads land in it, and deleting
     * a song from the phone removes what is there. Downloads are a cache and
     * belong somewhere that can be wiped without touching anything real.
     */
    fun cacheFile(dir: File, song: String): File = File(dir, song + ".lrc")

    /**
     * A recorded miss, so a library of obscure songs is not re-asked about
     * on every screen. The file's own timestamp is the retry clock, which
     * means no extra bookkeeping and no state to corrupt.
     */
    fun missFile(dir: File, song: String): File = File(dir, song + ".miss")

    /** Instrumentals never gain words, so this marker never expires. */
    fun instrumentalFile(dir: File, song: String): File = File(dir, song + ".none")
}

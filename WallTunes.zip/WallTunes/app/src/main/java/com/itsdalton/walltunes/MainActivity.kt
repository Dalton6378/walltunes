package com.itsdalton.walltunes

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.TransitionDrawable
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.palette.graphics.Palette
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.math.abs
import kotlin.random.Random

class MainActivity : Activity() {

    private var svc: PlaybackService? = null
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var wash: View
    private lateinit var nowPlaying: View
    private lateinit var art: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var progress: ProgressBar
    private lateinit var elapsed: TextView
    private lateinit var duration: TextView
    private lateinit var status: TextView
    private lateinit var clock: View
    private lateinit var addPanel: View
    private lateinit var emptyView: View
    private lateinit var nightDim: View
    private lateinit var version: TextView

    private var lastArtKey: Any? = null
    private var currentWash: Drawable = ColorDrawable(Color.TRANSPARENT)
    private var showAddPanel = true

    // Fallback color pairs for songs without album art
    private val washes = listOf(
        0xFF3A2A6B to 0xFF10162B, 0xFF6B2A3F to 0xFF14102B, 0xFF1F4F5C to 0xFF0E1628,
        0xFF5C4A1F to 0xFF18142A, 0xFF2A5C3A to 0xFF0F1A24
    )

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = render()
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            svc = (binder as PlaybackService.LocalBinder).service.also { it.player.addListener(listener) }
            dimTarget = -1f      // force re-evaluation against the new service
            applyNight()
            showAddress()
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            svc = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        wash = findViewById(R.id.wash)
        nowPlaying = findViewById(R.id.nowPlaying)
        art = findViewById(R.id.art)
        title = findViewById(R.id.title)
        artist = findViewById(R.id.artist)
        progress = findViewById(R.id.progress)
        elapsed = findViewById(R.id.elapsed)
        duration = findViewById(R.id.duration)
        status = findViewById(R.id.status)
        clock = findViewById(R.id.clock)
        addPanel = findViewById(R.id.addPanel)
        emptyView = findViewById(R.id.empty)
        nightDim = findViewById(R.id.nightDim)
        version = findViewById(R.id.version)

        version.text = try {
            "v" + packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }
    }

    override fun onStart() {
        super.onStart()
        val intent = Intent(this, PlaybackService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, connection, BIND_AUTO_CREATE)
        showAddress()
        ui.post(tick)
        ui.post(nightWatch)
        ui.postDelayed(drift, DRIFT_MS)
    }

    override fun onStop() {
        svc?.player?.removeListener(listener)
        unbindService(connection)
        svc = null
        ui.removeCallbacksAndMessages(null)
        super.onStop()
    }

    // ---------- Drawing ----------

    private fun render() {
        val p = svc?.player ?: return
        val empty = p.mediaItemCount == 0
        emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        nowPlaying.visibility = if (empty) View.INVISIBLE else View.VISIBLE
        addPanel.visibility = if (!empty && showAddPanel) View.VISIBLE else View.GONE
        if (empty) return

        val md = p.mediaMetadata
        title.text = svc?.displayTitle()
        artist.text = md.artist ?: md.albumArtist ?: ""
        status.text = when {
            !p.isPlaying && p.shuffleModeEnabled -> "Paused, shuffle on"
            !p.isPlaying -> "Paused"
            p.shuffleModeEnabled -> "Shuffle on"
            else -> ""
        }

        val key = Pair(p.currentMediaItem?.mediaId, md.artworkData?.size)
        if (key != lastArtKey) {
            lastArtKey = key
            showArt(md.artworkData, p.currentMediaItem?.mediaId ?: "")
        }
    }

    private fun showArt(data: ByteArray?, songId: String) {
        val bmp = data?.let { decodeSampled(it, 600) }
        if (bmp != null) {
            art.setImageBitmap(bmp)
            Palette.from(bmp).generate { pal ->
                val fallbackA = 0xFF3A2A6B.toInt()
                val fallbackB = 0xFF10162B.toInt()
                if (pal == null) {
                    setWash(fallbackA, fallbackB)
                } else {
                    val a = pal.getVibrantColor(pal.getMutedColor(fallbackA))
                    setWash(dim(a), pal.getDarkMutedColor(fallbackB))
                }
            }
        } else {
            art.setImageResource(R.drawable.art_placeholder)
            val (a, b) = washes[abs(songId.hashCode()) % washes.size]
            setWash(a.toInt(), b.toInt())
        }
    }

    /** Soft diagonal color wash that crossfades between songs. */
    private fun setWash(top: Int, bottom: Int) {
        val next = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(top, bottom, 0xFF0A0E1C.toInt())
        )
        val t = TransitionDrawable(arrayOf(currentWash, next)).apply { isCrossFadeEnabled = true }
        wash.background = t
        t.startTransition(2000)
        currentWash = next
    }

    private fun dim(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.6).toInt(), (Color.green(c) * 0.6).toInt(), (Color.blue(c) * 0.6).toInt()
    )

    private fun decodeSampled(data: ByteArray, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target) sample *= 2
        return BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private val tick = object : Runnable {
        override fun run() {
            svc?.player?.let { p ->
                val d = p.duration
                val pos = p.currentPosition
                if (d > 0) {
                    progress.progress = (pos * 1000 / d).toInt()
                    duration.text = fmt(d)
                } else {
                    progress.progress = 0
                    duration.text = ""
                }
                elapsed.text = fmt(pos)
            }
            ui.postDelayed(this, 500)
        }
    }

    // Nudge everything a little every minute so nothing burns into the screen.
    private val drift = object : Runnable {
        override fun run() {
            val d = resources.displayMetrics.density
            nowPlaying.animate().translationX(Random.nextInt(-50, 51) * d)
                .translationY(Random.nextInt(-30, 31) * d).setDuration(6000).start()
            clock.animate().translationX(Random.nextInt(-16, 17) * d)
                .translationY(Random.nextInt(-10, 11) * d).setDuration(6000).start()
            addPanel.animate().translationX(Random.nextInt(-16, 17) * d)
                .translationY(Random.nextInt(-10, 11) * d).setDuration(6000).start()
            ui.postDelayed(this, DRIFT_MS)
        }
    }

    // ---------- Night mode ----------

    /**
     * Re-checks the night window every half minute and eases the overlay to
     * match. Half a minute is plenty — the window only changes on the hour,
     * and the slow fade is the point: a wall display should never snap to
     * black while you are looking at it.
     */
    private val nightWatch = object : Runnable {
        override fun run() {
            applyNight()
            ui.postDelayed(this, 30_000)
        }
    }

    private var dimTarget = -1f

    private fun applyNight() {
        val s = svc ?: return
        val target = if (s.isNight()) (s.nightDim.coerceIn(0, 95) / 100f) else 0f
        if (target == dimTarget) return
        dimTarget = target

        // Long fade, so in a dark room the change is almost subliminal.
        nightDim.animate().alpha(target).setDuration(4000).start()

        // The QR panel is the brightest thing on screen. Hide it at night,
        // unless the library is empty and it is the only useful content.
        val hidePanel = target > 0f && s.player.mediaItemCount > 0
        addPanel.animate().alpha(if (hidePanel) 0f else 1f).setDuration(1500).start()
    }


    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ---------- Phone link ----------

    private fun showAddress() {
        val ip = localIp()
        val url = if (ip != null) "http://$ip:${PlaybackService.PORT}" else null
        val label = url ?: "Connect the TV to Wi-Fi to add songs"
        // The PIN gates uploads, deletes and settings. Showing it on the TV
        // is the whole security model: if you can read the screen you are in
        // the room, and anyone in the room may control the music. Without it
        // every device on the wifi could wipe the library.
        val pin = svc?.pin()
        findViewById<TextView>(R.id.addUrl).text =
            if (url != null && pin != null) "Add songs\n$url\nPIN $pin"
            else if (url != null) "Add songs\n$url"
            else label
        findViewById<TextView>(R.id.emptyUrl).text =
            if (url != null && pin != null) "$label\nPIN $pin" else label
        if (url != null) {
            findViewById<ImageView>(R.id.qr).setImageBitmap(qr(url, 300))
            findViewById<ImageView>(R.id.emptyQr).setImageBitmap(qr(url, 600))
        }
    }

    private fun localIp(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    } catch (e: Exception) {
        null
    }

    private fun qr(text: String, size: Int): Bitmap {
        val m = QRCodeWriter().encode(
            text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1)
        )
        val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) Color.BLACK else Color.WHITE }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.RGB_565)
    }

    // ---------- Remote ----------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val s = svc ?: return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> s.control("toggle")

            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_NEXT,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> s.control("next")

            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
            KeyEvent.KEYCODE_MEDIA_REWIND -> s.control("prev")

            KeyEvent.KEYCODE_DPAD_UP -> {
                s.control("shuffle")
                Toast.makeText(this, if (s.player.shuffleModeEnabled) "Shuffle on" else "Shuffle off", Toast.LENGTH_SHORT).show()
            }

            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MENU -> {
                showAddPanel = !showAddPanel
                showAddress()
                render()
            }

            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    companion object {
        private const val DRIFT_MS = 60_000L
    }
}

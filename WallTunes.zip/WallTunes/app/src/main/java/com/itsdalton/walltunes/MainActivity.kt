package com.itsdalton.walltunes

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.TransitionDrawable
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.LruCache
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.palette.graphics.Palette
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.random.Random

class MainActivity : Activity() {

    private var svc: PlaybackService? = null
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var wash: View
    private lateinit var nowPlaying: View
    private lateinit var art: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var progress: ProgressBar
    private lateinit var elapsed: TextView
    private lateinit var duration: TextView
    private lateinit var status: TextView
    private lateinit var clock: View
    private lateinit var addPanel: View
    private lateinit var emptyView: View
    private lateinit var nightDim: View
    private lateinit var version: TextView

    // Display modes. Each is a container in the layout; switching is a
    // visibility change, never an inflation.
    private lateinit var bgArt: ImageView
    private lateinit var scrim: View
    private lateinit var modeNowPlaying: View
    private lateinit var modeBigClock: View
    private lateinit var modeArtWall: ArtWallView
    private lateinit var bigClockTitle: TextView

    private val prefs by lazy { getSharedPreferences("walltunes", MODE_PRIVATE) }
    private var mode = DisplayMode.NOW_PLAYING

    private var lastArtKey: Any? = null
    private var currentWash: Drawable = ColorDrawable(Color.TRANSPARENT)
    private var showAddPanel = true

    // Fallback color pairs for songs without album art
    private val washes = listOf(
        0xFF3A2A6B to 0xFF10162B, 0xFF6B2A3F to 0xFF14102B, 0xFF1F4F5C to 0xFF0E1628,
        0xFF5C4A1F to 0xFF18142A, 0xFF2A5C3A to 0xFF0F1A24
    )

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = render()
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            svc = (binder as PlaybackService.LocalBinder).service.also { it.player.addListener(listener) }
            dimTarget = -1f      // force re-evaluation against the new service
            applyNight()
            showAddress()
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            svc = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        wash = findViewById(R.id.wash)
        nowPlaying = findViewById(R.id.nowPlaying)
        art = findViewById(R.id.art)
        title = findViewById(R.id.title)
        artist = findViewById(R.id.artist)
        progress = findViewById(R.id.progress)
        elapsed = findViewById(R.id.elapsed)
        duration = findViewById(R.id.duration)
        status = findViewById(R.id.status)
        clock = findViewById(R.id.clock)
        addPanel = findViewById(R.id.addPanel)
        emptyView = findViewById(R.id.empty)
        nightDim = findViewById(R.id.nightDim)
        version = findViewById(R.id.version)

        bgArt = findViewById(R.id.bgArt)
        scrim = findViewById(R.id.scrim)
        modeNowPlaying = findViewById(R.id.modeNowPlaying)
        modeBigClock = findViewById(R.id.modeBigClock)
        modeArtWall = findViewById(R.id.modeArtWall)
        bigClockTitle = findViewById(R.id.bigClockTitle)

        version.text = try {
            "v" + packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }

        // res/font only resolves from XML on API 26+, and minSdk is 22, so
        // the family is applied in code across the whole tree.
        Type.apply(findViewById(android.R.id.content))

        // Then the handful that carry weight. Doing it here, rather than
        // inferring from textStyle, keeps the type scale honest: Medium is a
        // deliberate choice on four elements, not a side effect of bold.
        val medium = Type.medium(this)
        title.typeface = medium
        findViewById<TextClock>(R.id.bigClock).typeface = medium

        // Come back in whichever mode the TV was left in.
        mode = try {
            DisplayMode.valueOf(prefs.getString("displayMode", null) ?: "")
        } catch (e: Exception) {
            DisplayMode.NOW_PLAYING
        }
        applyMode(animate = false)
        setUpBrowser()
    }

    override fun onStart() {
        super.onStart()
        val intent = Intent(this, PlaybackService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, connection, BIND_AUTO_CREATE)
        showAddress()
        ui.post(tick)
        ui.post(nightWatch)
        ui.postDelayed(drift, DRIFT_MS)
    }

    override fun onStop() {
        closeBrowser(immediate = true)
        svc?.player?.removeListener(listener)
        unbindService(connection)
        svc = null
        ui.removeCallbacksAndMessages(null)
        super.onStop()
    }

    override fun onDestroy() {
        modeArtWall.stop()
        coverCache.evictAll()
        kenBurnsRunning = false
        bgArt.animate().cancel()
        bg.shutdownNow()
        super.onDestroy()
    }

    // ---------- Drawing ----------

    private fun render() {
        val p = svc?.player ?: return
        val empty = p.mediaItemCount == 0
        emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        nowPlaying.visibility = if (empty) View.INVISIBLE else View.VISIBLE
        addPanel.visibility = if (!empty && showAddPanel) View.VISIBLE else View.GONE
        if (empty) return

        val md = p.mediaMetadata
        title.text = svc?.displayTitle()
        artist.text = md.artist ?: md.albumArtist ?: ""
        // Big Clock shows the song quietly under the time.
        bigClockTitle.text = svc?.displayTitle()
        status.text = when {
            !p.isPlaying && p.shuffleModeEnabled -> "Paused, shuffle on"
            !p.isPlaying -> "Paused"
            p.shuffleModeEnabled -> "Shuffle on"
            else -> ""
        }

        val key = Pair(p.currentMediaItem?.mediaId, md.artworkData?.size)
        if (key != lastArtKey) {
            lastArtKey = key
            showArt(md.artworkData, p.currentMediaItem?.mediaId ?: "")
        }
    }

    private fun showArt(data: ByteArray?, songId: String) {
        updateBackground(data, songId)
        easeInText()
        val bmp = data?.let { decodeSampled(it, 600) }
        if (bmp != null) {
            art.setImageBitmap(bmp)
            Palette.from(bmp).generate { pal ->
                val fallbackA = 0xFF3A2A6B.toInt()
                val fallbackB = 0xFF10162B.toInt()
                if (pal == null) {
                    setWash(fallbackA, fallbackB)
                } else {
                    val a = pal.getVibrantColor(pal.getMutedColor(fallbackA))
                    setWash(dim(a), pal.getDarkMutedColor(fallbackB))
                }
            }
        } else {
            art.setImageResource(R.drawable.art_placeholder)
            val (a, b) = washes[abs(songId.hashCode()) % washes.size]
            setWash(a.toInt(), b.toInt())
        }
    }

    /** Soft diagonal color wash that crossfades between songs. */
    private fun setWash(top: Int, bottom: Int) {
        val next = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(top, bottom, 0xFF0A0E1C.toInt())
        )
        val t = TransitionDrawable(arrayOf(currentWash, next)).apply { isCrossFadeEnabled = true }
        wash.background = t
        t.startTransition(2000)
        currentWash = next
    }

    private fun dim(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.6).toInt(), (Color.green(c) * 0.6).toInt(), (Color.blue(c) * 0.6).toInt()
    )

    /**
     * @param config RGB_565 halves the memory and is correct for album art,
     *   which is opaque. The sharp now-playing cover keeps ARGB_8888 because
     *   it is displayed large and banding would show.
     */
    private fun decodeSampled(
        data: ByteArray,
        target: Int,
        config: Bitmap.Config = Bitmap.Config.ARGB_8888
    ): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth <= 0) return null

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target) sample *= 2

        return BitmapFactory.decodeByteArray(
            data, 0, data.size,
            BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = config
            }
        )
    }

    private val tick = object : Runnable {
        override fun run() {
            svc?.player?.let { p ->
                val d = p.duration
                val pos = p.currentPosition
                if (d > 0) {
                    progress.progress = (pos * 1000 / d).toInt()
                    duration.text = fmt(d)
                } else {
                    progress.progress = 0
                    duration.text = ""
                }
                elapsed.text = fmt(pos)
            }
            ui.postDelayed(this, 500)
        }
    }

    // ---------- Cinematic background ----------
    //
    // The album cover, blurred and full-bleed behind everything. All of the
    // expense happens once per song: decode small, blur small, hand to the
    // GPU to scale up. Nothing here touches a frame.

    private var bgToken = 0

    private fun updateBackground(data: ByteArray?, songId: String) {
        // Guards against a slow blur landing after the song has moved on.
        val token = ++bgToken

        if (data == null) {
            // No cover: fade the background out and let the palette wash,
            // which already handles art-less songs, carry the room's colour.
            bgArt.animate().alpha(0f).setDuration(ART_FADE_MS).start()
            scrim.animate().alpha(0f).setDuration(ART_FADE_MS).start()
            return
        }

        bg.execute {
            // 72px source: large enough that the blur has real colour to
            // work with, small enough that three passes are trivial.
            val small = try {
                decodeSampled(data, 72)
            } catch (e: Exception) {
                null
            }
            val blurred = small?.let { Blur.blur(it) }
            if (small != null && small != blurred) small.recycle()

            ui.post {
                // Another song started while this was being blurred.
                if (token != bgToken || blurred == null) return@post
                crossfadeBackground(blurred)
            }
        }
    }

    private fun crossfadeBackground(next: Bitmap) {
        // The scrim only earns its darkness when there is artwork behind it.
        scrim.animate().alpha(1f).setDuration(ART_FADE_MS).start()
        val old = bgArt.drawable
        if (old == null || bgArt.alpha < 0.05f) {
            bgArt.setImageBitmap(next)
            bgArt.animate().alpha(1f).setDuration(ART_FADE_MS).start()
        } else {
            // TransitionDrawable does the blend on the GPU, and works happily
            // alongside the Ken Burns animation running on the same view.
            val fade = TransitionDrawable(arrayOf(old, BitmapDrawable(resources, next)))
            fade.isCrossFadeEnabled = true
            bgArt.setImageDrawable(fade)
            bgArt.alpha = 1f
            fade.startTransition(ART_FADE_MS.toInt())
        }
        startKenBurns()
    }

    /**
     * Very slow drift across the background.
     *
     * Forty seconds a leg, reversing, so it reads as the room breathing
     * rather than as something moving. It also doubles as burn-in protection
     * for the one layer that covers the whole screen.
     */
    private fun startKenBurns() {
        if (kenBurnsRunning) return
        kenBurnsRunning = true
        kenBurnsLeg()
    }

    private var kenBurnsRunning = false

    private fun kenBurnsLeg() {
        if (isFinishing) return
        val scale = 1.16f + Random.nextFloat() * 0.10f
        bgArt.animate()
            .scaleX(scale).scaleY(scale)
            .translationX(Random.nextInt(-46, 47).toFloat())
            .translationY(Random.nextInt(-34, 35).toFloat())
            .setDuration(KEN_BURNS_MS)
            .setInterpolator(LinearInterpolator())
            .withEndAction { kenBurnsLeg() }
            .start()
    }

    /** Song title and artist ease in behind the artwork, never snap. */
    private fun easeInText() {
        for (v in listOf<View>(title, artist)) {
            v.alpha = 0f
            v.translationY = 18f
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(TEXT_DELAY_MS)
                .setDuration(TEXT_EASE_MS)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    // ---------- Art Wall plumbing ----------

    /**
     * Decoded covers, capped by bytes rather than by count.
     *
     * Counting entries would be meaningless — what matters is megabytes on a
     * device that has very few. A quarter of the app's available heap is
     * plenty for 24 tiles and leaves room for everything else.
     */
    private val coverCache by lazy {
        val limit = (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtMost(8 * 1024 * 1024)
        object : LruCache<String, Bitmap>(limit) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }
    }

    private val artSource = object : ArtWallView.Source {
        override fun songNames(): List<String> =
            svc?.songFiles()?.map { it.name }.orEmpty()

        override fun loadCover(song: String, sizePx: Int, done: (Bitmap?) -> Unit) {
            coverCache.get(song)?.let { done(it); return }

            bg.execute {
                val bytes = svc?.artworkFor(song)
                val bmp = bytes?.let {
                    try {
                        // RGB_565: covers are opaque, and this halves the
                        // memory each tile costs.
                        decodeSampled(it, sizePx, Bitmap.Config.RGB_565)
                    } catch (e: Exception) {
                        null
                    }
                }
                if (bmp != null) coverCache.put(song, bmp)
                ui.post { done(bmp) }
            }
        }
    }

    // ---------- Display modes ----------

    /**
     * Show the current mode and hide the rest.
     *
     * Visibility only — every container is already inflated, so switching
     * costs a layout pass rather than an inflation. Art Wall will also
     * release its bitmaps here once it exists, so its ~6 MB does not sit
     * resident behind a screen that has no use for it.
     */
    private fun applyMode(animate: Boolean = true) {
        val containers = listOf(modeNowPlaying, modeBigClock, modeArtWall)
        val active = when (mode) {
            DisplayMode.NOW_PLAYING -> modeNowPlaying
            DisplayMode.BIG_CLOCK -> modeBigClock
            DisplayMode.ART_WALL -> modeArtWall
        }

        for (c in containers) {
            val show = c === active
            if (!animate) {
                c.visibility = if (show) View.VISIBLE else View.GONE
                c.alpha = 1f
                continue
            }
            if (show) {
                c.alpha = 0f
                c.visibility = View.VISIBLE
                c.animate().alpha(1f).setDuration(MODE_FADE_MS).start()
            } else if (c.visibility == View.VISIBLE) {
                c.animate().alpha(0f).setDuration(MODE_FADE_MS)
                    .withEndAction { c.visibility = View.GONE }.start()
            }
        }

        // Drift targets change with the mode, so reset any offsets left
        // behind by the mode we just left.
        for (c in containers) {
            c.translationX = 0f
            c.translationY = 0f
        }

        // Art Wall owns a few MB of bitmaps. Starting and stopping it with
        // the mode is what keeps that memory from sitting resident behind a
        // screen that has no use for it.
        if (mode == DisplayMode.ART_WALL) modeArtWall.start(artSource)
        else modeArtWall.stop()

        prefs.edit().putString("displayMode", mode.name).apply()
        render()
    }

    private fun cycleMode() {
        val all = DisplayMode.values()
        mode = all[(mode.ordinal + 1) % all.size]
        applyMode()
        Toast.makeText(this, mode.label, Toast.LENGTH_SHORT).show()
    }

    /**
     * Nudge the visible mode every minute so nothing burns in.
     *
     * Drifting the container rather than named views means every mode gets
     * burn-in protection for free, including ones added later — this is a
     * screen that is on permanently, so that has to be a property of the
     * app rather than a feature of one layout.
     */
    private val drift = object : Runnable {
        override fun run() {
            val d = resources.displayMetrics.density
            val active = when (mode) {
                DisplayMode.NOW_PLAYING -> modeNowPlaying
                DisplayMode.BIG_CLOCK -> modeBigClock
                DisplayMode.ART_WALL -> modeArtWall
            }
            active.animate()
                .translationX(Random.nextInt(-50, 51) * d)
                .translationY(Random.nextInt(-30, 31) * d)
                .setDuration(6000).start()
            ui.postDelayed(this, DRIFT_MS)
        }
    }

    // ---------- Night mode ----------

    /**
     * Re-checks the night window every half minute and eases the overlay to
     * match. Half a minute is plenty — the window only changes on the hour,
     * and the slow fade is the point: a wall display should never snap to
     * black while you are looking at it.
     */
    private val nightWatch = object : Runnable {
        override fun run() {
            applyNight()
            ui.postDelayed(this, 30_000)
        }
    }

    private var dimTarget = -1f

    private fun applyNight() {
        val s = svc ?: return
        val target = if (s.isNight()) (s.nightDim.coerceIn(0, 95) / 100f) else 0f
        if (target == dimTarget) return
        dimTarget = target

        // Long fade, so in a dark room the change is almost subliminal.
        nightDim.animate().alpha(target).setDuration(4000).start()

        // The QR panel is the brightest thing on screen. Hide it at night,
        // unless the library is empty and it is the only useful content.
        val hidePanel = target > 0f && s.player.mediaItemCount > 0
        addPanel.animate().alpha(if (hidePanel) 0f else 1f).setDuration(1500).start()
    }


    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ---------- Phone link ----------

    private fun showAddress() {
        val ip = localIp()
        val url = if (ip != null) "http://$ip:${PlaybackService.PORT}" else null
        val label = url ?: "Connect the TV to Wi-Fi to add songs"
        // The PIN gates uploads, deletes and settings. Showing it on the TV
        // is the whole security model: if you can read the screen you are in
        // the room, and anyone in the room may control the music. Without it
        // every device on the wifi could wipe the library.
        val pin = svc?.pin()
        findViewById<TextView>(R.id.addUrl).text =
            if (url != null && pin != null) "Add songs\n$url\nPIN $pin"
            else if (url != null) "Add songs\n$url"
            else label
        findViewById<TextView>(R.id.emptyUrl).text =
            if (url != null && pin != null) "$label\nPIN $pin" else label
        if (url != null) {
            findViewById<ImageView>(R.id.qr).setImageBitmap(qr(url, 300))
            findViewById<ImageView>(R.id.emptyQr).setImageBitmap(qr(url, 600))
        }
    }

    private fun localIp(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    } catch (e: Exception) {
        null
    }

    private fun qr(text: String, size: Int): Bitmap {
        val m = QRCodeWriter().encode(
            text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1)
        )
        val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) Color.BLACK else Color.WHITE }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.RGB_565)
    }

    // ---------- Remote ----------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // While the browser is up the D-pad belongs to its lists. Handing
        // the keys straight to the view system is what lets normal focus
        // traversal work, instead of reimplementing navigation here.
        if (browserOpen) {
            keepBrowserAwake()
            return super.onKeyDown(keyCode, event)
        }

        val s = svc ?: return super.onKeyDown(keyCode, event)
        when (keyCode) {
            // OK is now two controls: a tap plays or pauses, a hold opens the
            // browser. Deciding needs the release, so the action moves to
            // onKeyUp and this only arms long-press tracking.
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (event.repeatCount == 0) event.startTracking()
                return true
            }

            // The dedicated media key has no second meaning, so it still
            // fires on press and stays the fastest way to pause.
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> s.control("toggle")

            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_NEXT,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> s.control("next")

            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
            KeyEvent.KEYCODE_MEDIA_REWIND -> s.control("prev")

            KeyEvent.KEYCODE_DPAD_UP -> {
                s.control("shuffle")
                Toast.makeText(this, if (s.player.shuffleModeEnabled) "Shuffle on" else "Shuffle off", Toast.LENGTH_SHORT).show()
            }

            // Down cycles display modes. The QR panel moves to Menu, which
            // used to share this key — modes need a home, and Menu was the
            // only D-pad key not already doing transport work.
            KeyEvent.KEYCODE_DPAD_DOWN -> cycleMode()

            KeyEvent.KEYCODE_MENU -> {
                showAddPanel = !showAddPanel
                showAddress()
                render()
            }

            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (!browserOpen &&
            (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
        ) {
            openBrowser()
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (!browserOpen &&
            (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
        ) {
            // Android flags the release as cancelled once a long press has
            // been consumed, so this distinguishes a tap from a hold without
            // tracking any state of our own.
            if (!event.isCanceled) svc?.control("toggle")
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onBackPressed() {
        // Back normally closes the screen and leaves the music playing. With
        // the browser open it has to mean "close the browser" instead, or
        // there is no way out of it that does not also leave the app.
        if (browserOpen) closeBrowser() else super.onBackPressed()
    }

    // ---------- Library browser ----------
    //
    // The one thing the remote could never do before: choose a song. Opened
    // with a long press on OK, closed with Back.
    //
    // While it is open the D-pad belongs to the lists, so onKeyDown stops
    // intercepting and lets normal focus traversal do the work. That routing
    // is the whole trick — every D-pad key was already spoken for by
    // transport controls.

    private enum class Cat(val label: String) {
        ALL("All songs"),
        ARTISTS("By artist"),
        RECENT("Recently added"),
        PLAYLISTS("Playlists")
    }

    private var browserOpen = false
    private var cat = Cat.ALL
    private var browserSongNames: List<String> = emptyList()
    /** Playlist ids when the Playlists category is showing, else empty. */
    private var browserPlaylistIds: List<String> = emptyList()

    private lateinit var browser: View
    private lateinit var browserCategories: ListView
    private lateinit var browserSongs: ListView
    private lateinit var browserHeading: TextView
    private val catAdapter by lazy { RowAdapter(layoutInflater) }
    private val songAdapter by lazy { RowAdapter(layoutInflater) }

    /** Tag parsing is slow; it never runs on the main thread. */
    private val bg by lazy { Executors.newSingleThreadExecutor() }

    private class RowAdapter(private val inflater: LayoutInflater) : BaseAdapter() {
        private var rows: List<Pair<String, String>> = emptyList()

        fun submit(next: List<Pair<String, String>>) {
            rows = next
            notifyDataSetChanged()
        }

        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: inflater.inflate(R.layout.row_song, parent, false).also {
                // Rows are inflated after the initial pass, so they need the
                // family applying once — on inflate, not on every bind.
                Type.apply(it)
            }
            val (main, sub) = rows[position]
            v.findViewById<TextView>(R.id.rowTitle).text = main
            v.findViewById<TextView>(R.id.rowSub).apply {
                text = sub
                visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
            }
            return v
        }
    }

    private fun setUpBrowser() {
        browser = findViewById(R.id.browser)
        browserCategories = findViewById(R.id.browserCategories)
        browserSongs = findViewById(R.id.browserSongs)
        browserHeading = findViewById(R.id.browserHeading)

        browserCategories.adapter = catAdapter
        browserSongs.adapter = songAdapter
        catAdapter.submit(Cat.values().map { it.label to "" })

        // Moving through categories updates the song list immediately — on a
        // remote, needing OK just to preview a category is a press too many.
        browserCategories.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                cat = Cat.values()[pos]
                fillSongs()
                keepBrowserAwake()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        })

        browserCategories.setOnItemClickListener { _, _, pos, _ ->
            cat = Cat.values()[pos]
            fillSongs()
            browserSongs.requestFocus()
        }

        browserSongs.setOnItemClickListener { _, _, pos, _ ->
            if (cat == Cat.PLAYLISTS) {
                browserPlaylistIds.getOrNull(pos)?.let { id ->
                    // An empty or fully-stale playlist is a no-op rather than
                    // silence — say so instead of stopping the music.
                    if (svc?.playPlaylist(id) == true) closeBrowser()
                    else Toast.makeText(
                        this, "That playlist has no songs yet", Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                browserSongNames.getOrNull(pos)?.let { name ->
                    svc?.control("play", name)
                    closeBrowser()
                }
            }
        }
    }

    private fun openBrowser() {
        if (browserOpen) return
        browserOpen = true

        // Shows instantly from cached tags, then sharpens when the warm-up
        // lands. Parsing a few hundred files here would freeze the screen.
        fillSongs()
        bg.execute {
            svc?.warmTags()
            ui.post { if (browserOpen) fillSongs() }
        }

        browser.alpha = 0f
        browser.visibility = View.VISIBLE
        browser.animate().alpha(1f).setDuration(BROWSER_FADE_MS).start()

        browserCategories.setSelection(cat.ordinal)
        browserSongs.requestFocus()
        keepBrowserAwake()
    }

    /**
     * @param immediate skip the fade and hide now.
     *
     * onStop needs the immediate path: a fade that never finishes because the
     * activity went away leaves the overlay VISIBLE at alpha 0, where it is
     * invisible but can still take focus — so the next time you opened the
     * app, the D-pad would be driving a list nobody could see.
     */
    private fun closeBrowser(immediate: Boolean = false) {
        if (!browserOpen) return
        browserOpen = false
        ui.removeCallbacks(browserTimeout)

        if (immediate) {
            browser.animate().cancel()
            browser.alpha = 0f
            browser.visibility = View.GONE
            return
        }
        browser.animate().alpha(0f).setDuration(BROWSER_FADE_MS)
            .withEndAction { browser.visibility = View.GONE }.start()
    }

    private fun fillSongs() {
        if (cat == Cat.PLAYLISTS) {
            fillPlaylists()
            return
        }
        browserPlaylistIds = emptyList()

        val lib = svc?.libraryFast().orEmpty()

        val ordered = when (cat) {
            Cat.ALL -> lib.sortedBy { it.title.lowercase() }
            Cat.ARTISTS -> lib.sortedWith(
                compareBy({ it.artist.ifEmpty { "￿" }.lowercase() }, { it.title.lowercase() })
            )
            Cat.RECENT -> lib.sortedByDescending { it.added }
            // Handled above; listed so the when stays exhaustive.
            Cat.PLAYLISTS -> emptyList()
        }

        browserSongNames = ordered.map { it.name }
        songAdapter.submit(ordered.map { s ->
            val bits = listOfNotNull(
                s.artist.takeIf { it.isNotEmpty() },
                fmt(s.durationMs).takeIf { s.durationMs > 0 }
            )
            s.title to bits.joinToString("   ·   ")
        })

        browserHeading.text = when {
            lib.isEmpty() -> "No songs yet — add some from your phone"
            else -> cat.label + "   ·   " + lib.size + if (lib.size == 1) " song" else " songs"
        }

        // Land on whatever is playing, so the browser opens where you are.
        val playing = svc?.player?.currentMediaItem?.mediaId
        val at = browserSongNames.indexOf(playing)
        if (at >= 0) browserSongs.setSelection(at)
    }

    private fun fillPlaylists() {
        val existing = svc?.songFiles()?.map { it.name }?.toSet().orEmpty()
        val lists = svc?.library?.playlists().orEmpty()

        browserPlaylistIds = lists.map { it.id }
        browserSongNames = emptyList()

        songAdapter.submit(lists.map { pl ->
            val live = pl.songs.count { existing.contains(it) }
            pl.name to (if (live == 1) "1 song" else "$live songs")
        })

        browserHeading.text = if (lists.isEmpty()) {
            "No playlists yet — make one from your phone"
        } else {
            "Playlists   ·   " + lists.size + if (lists.size == 1) " list" else " lists"
        }
    }

    /** A menu left up on a wall is worse than no menu. */
    private val browserTimeout = Runnable { closeBrowser() }

    private fun keepBrowserAwake() {
        ui.removeCallbacks(browserTimeout)
        ui.postDelayed(browserTimeout, BROWSER_IDLE_MS)
    }

    companion object {
        private const val DRIFT_MS = 60_000L
        private const val MODE_FADE_MS = 350L
        private const val BROWSER_FADE_MS = 250L
        private const val BROWSER_IDLE_MS = 30_000L
        private const val ART_FADE_MS = 1200L
        private const val KEN_BURNS_MS = 40_000L
        private const val TEXT_DELAY_MS = 120L
        private const val TEXT_EASE_MS = 500L
    }
}

/**
 * What the TV is showing.
 *
 * Ordered as they cycle on the remote, so adding a mode here adds it to the
 * rotation with no other change. Lyrics joins in Phase 6 and will be skipped
 * when the current song has none, rather than showing an empty screen.
 */
enum class DisplayMode(val label: String) {
    NOW_PLAYING("Now playing"),
    BIG_CLOCK("Clock"),
    ART_WALL("Art wall")
}

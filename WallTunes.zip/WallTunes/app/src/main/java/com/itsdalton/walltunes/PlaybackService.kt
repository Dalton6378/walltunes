package com.itsdalton.walltunes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs the music 24/7. Lives in the background even when the screen app is closed,
 * and hosts the little web server your phone uses to add songs.
 */
class PlaybackService : Service() {

    inner class LocalBinder : Binder() {
        val service: PlaybackService get() = this@PlaybackService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("walltunes", MODE_PRIVATE) }
    private var server: UploadServer? = null

    lateinit var player: ExoPlayer
        private set

    val musicDir: File by lazy { File(filesDir, "music").apply { mkdirs() } }

    // When the TV wakes up, pick the music back up.
    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = resume()
    }

    override fun onCreate() {
        super.onCreate()
        startInForeground()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.repeatMode = Player.REPEAT_MODE_ALL
        player.shuffleModeEnabled = prefs.getBoolean("shuffle", true)
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // A broken file shouldn't stop the music: skip it and keep going.
                main.postDelayed({
                    if (player.mediaItemCount > 1) player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }, 3000)
            }

            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                item?.let { prefs.edit().putString("last", it.mediaId).apply() }
            }
        })

        musicDir.listFiles { f -> f.name.startsWith(".upload-") }?.forEach { it.delete() }
        loadLibrary()

        ContextCompat.registerReceiver(
            this, screenOn, IntentFilter(Intent.ACTION_SCREEN_ON), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        server = UploadServer(this, PORT).also {
            try {
                it.start(10_000, false)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        server?.stop()
        try { unregisterReceiver(screenOn) } catch (_: Exception) {}
        player.release()
        super.onDestroy()
    }

    // ---------- Library ----------

    fun songFiles(): List<File> =
        musicDir.listFiles { f -> f.isFile && !f.name.startsWith(".") }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()

    private fun itemFor(f: File) =
        MediaItem.Builder().setUri(Uri.fromFile(f)).setMediaId(f.name).build()

    private fun loadLibrary() {
        val items = songFiles().map { itemFor(it) }
        val last = prefs.getString("last", null)
        val start = items.indexOfFirst { it.mediaId == last }.coerceAtLeast(0)
        player.setMediaItems(items, start, 0)
        player.prepare()
        player.playWhenReady = true
    }

    fun addSong(f: File) = onMain {
        if (player.mediaItemCount == 0) loadLibrary()
        else player.addMediaItem(itemFor(f))
    }

    fun removeSong(name: String) = onMain {
        val index = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == name }
        if (index != null) player.removeMediaItem(index)
        File(musicDir, name).delete()
        Unit
    }

    // ---------- Controls (used by the remote and the phone page) ----------

    fun control(action: String, name: String? = null) = onMain {
        when (action) {
            "toggle" -> if (player.isPlaying) player.pause() else resume()
            "next" -> player.seekToNextMediaItem()
            "prev" -> player.seekToPreviousMediaItem()
            "shuffle" -> {
                player.shuffleModeEnabled = !player.shuffleModeEnabled
                prefs.edit().putBoolean("shuffle", player.shuffleModeEnabled).apply()
            }
            "play" -> {
                val i = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == name }
                if (i != null) { player.seekTo(i, 0); resume() }
            }
            else -> {}
        }
        Unit
    }

    private fun resume() {
        if (player.mediaItemCount == 0) return
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.play()
    }

    fun displayTitle(): String =
        player.mediaMetadata.title?.toString()
            ?: player.currentMediaItem?.mediaId?.substringBeforeLast('.') ?: ""

    fun stateJson(): String = onMain {
        val songs = JSONArray().apply { songFiles().forEach { put(it.name) } }
        val md = player.mediaMetadata
        JSONObject()
            .put("songs", songs)
            .put("current", player.currentMediaItem?.mediaId ?: JSONObject.NULL)
            .put("title", displayTitle())
            .put("artist", (md.artist ?: md.albumArtist ?: "").toString())
            .put("playing", player.isPlaying)
            .put("shuffle", player.shuffleModeEnabled)
            .toString()
    }

    /** ExoPlayer only likes the main thread; the web server runs on its own threads. */
    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        var result: Result<T>? = null
        main.post {
            result = runCatching(block)
            latch.countDown()
        }
        latch.await(5, TimeUnit.SECONDS)
        return result?.getOrThrow() ?: throw IllegalStateException("Player didn't respond in time")
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("playback", "Playback", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = NotificationCompat.Builder(this, "playback")
            .setContentTitle("WallTunes")
            .setContentText("Playing music")
            .setSmallIcon(R.drawable.ic_note)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
    }

    companion object {
        const val PORT = 8080
    }
}

package com.itsdalton.walltunes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Calendar
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs the music 24/7. Lives in the background even when the screen app is closed,
 * and hosts the little web server your phone uses to add songs.
 */
class PlaybackService : Service() {

    inner class LocalBinder : Binder() {
        val service: PlaybackService get() = this@PlaybackService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("walltunes", MODE_PRIVATE) }
    private var server: UploadServer? = null

    lateinit var player: ExoPlayer
        private set

    val musicDir: File by lazy { File(filesDir, "music").apply { mkdirs() } }

    /**
     * Playlists, favourites and play counts.
     *
     * Deliberately NOT in the playback path: the library is still whatever
     * [songFiles] finds on disk, so this file can be lost entirely without
     * costing a single song.
     */
    val library: Library by lazy { Library(filesDir) }

    /**
     * Phones listening over SSE.
     *
     * CopyOnWriteArraySet because it is read on every broadcast and written
     * only when a phone connects or leaves — exactly the shape it is for.
     */
    private val streams = java.util.concurrent.CopyOnWriteArraySet<EventStream>()

    fun addStream(s: EventStream) { streams.add(s) }
    fun removeStream(s: EventStream) { streams.remove(s) }

    /**
     * Tell every listening phone that something changed.
     *
     * Coalesced: the player fires events in bursts — a track change alone
     * produces several — and phones do not need to hear about each one.
     */
    private val broadcastNow = Runnable {
        if (streams.isEmpty()) return@Runnable
        val json = stateJson()
        for (s in streams) {
            val alive = try {
                s.push(json)
            } catch (e: Exception) {
                false
            }
            if (!alive) streams.remove(s)
        }
    }

    fun broadcast() {
        main.removeCallbacks(broadcastNow)
        main.postDelayed(broadcastNow, 120)
    }

    // When the TV wakes up, pick the music back up.
    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = resume()
    }

    override fun onCreate() {
        super.onCreate()
        startInForeground()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.repeatMode = Player.REPEAT_MODE_ALL
        player.shuffleModeEnabled = prefs.getBoolean("shuffle", true)
        player.addListener(object : Player.Listener {
            // Anything the phone renders — play state, track, shuffle —
            // arrives here. Position is not pushed: the phone extrapolates
            // it locally, which is what removes the need to poll at all.
            override fun onEvents(p: Player, events: Player.Events) = broadcast()

            override fun onPlayerError(error: PlaybackException) {
                // A broken file shouldn't stop the music: skip it and keep going.
                main.postDelayed({
                    if (player.mediaItemCount > 1) player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }, 3000)
            }

            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                // A song finished on its own and something is queued: go
                // there instead of wherever the player was heading. Only on
                // AUTO — a seek or an explicit play must not eat the queue.
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO &&
                    upNext.isNotEmpty() && consumeQueue()
                ) return

                item?.let {
                    prefs.edit().putString("last", it.mediaId).apply()
                    // Counted on transition rather than on play, so pausing
                    // and resuming a song does not inflate its count.
                    it.mediaId.let { id -> library.bumpPlayCount(id) }
                }
            }
        })

        musicDir.listFiles { f -> f.name.startsWith(".upload-") }?.forEach { it.delete() }
        loadLibrary()

        ContextCompat.registerReceiver(
            this, screenOn, IntentFilter(Intent.ACTION_SCREEN_ON), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Night mode, quiet hours and the sleep timer all ride on one ticker.
        main.post(scheduleTick)

        server = UploadServer(this, PORT).also {
            try {
                it.start(10_000, false)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        main.removeCallbacks(scheduleTick)
        streams.forEach { it.shutdown() }
        streams.clear()
        server?.stop()
        try { unregisterReceiver(screenOn) } catch (_: Exception) {}
        player.release()
        super.onDestroy()
    }

    // ---------- Library ----------

    /**
     * The library: audio files only.
     *
     * The extension filter is not cosmetic. Sidecar .lrc files live in this
     * same directory, and without it every set of lyrics would appear in the
     * library as an unplayable song.
     */
    fun songFiles(): List<File> =
        musicDir.listFiles { f ->
            f.isFile &&
                !f.name.startsWith(".") &&
                f.name.substringAfterLast('.', "").lowercase() in AUDIO_TYPES
        }?.sortedBy { it.name.lowercase() } ?: emptyList()

    private fun itemFor(f: File) =
        MediaItem.Builder().setUri(Uri.fromFile(f)).setMediaId(f.name).build()

    private fun loadLibrary() {
        val items = songFiles().map { itemFor(it) }
        val last = prefs.getString("last", null)
        val start = items.indexOfFirst { it.mediaId == last }.coerceAtLeast(0)
        player.setMediaItems(items, start, 0)
        player.prepare()
        player.playWhenReady = true
    }

    fun addSong(f: File) = onMain {
        if (player.mediaItemCount == 0) loadLibrary()
        else player.addMediaItem(itemFor(f))
    }

    fun removeSong(name: String) = onMain {
        val index = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == name }
        if (index != null) player.removeMediaItem(index)
        File(musicDir, name).delete()
        // Drop it from playlists, favourites, counts and the queue too, so
        // nothing keeps a reference to a file that no longer exists.
        library.forget(name)
        upNext.remove(name)
        Unit
    }

    /**
     * Replace what is playing with a playlist, in its saved order.
     *
     * Songs that no longer exist on disk are skipped rather than queued as
     * broken items. An empty result is a no-op: better to keep playing what
     * was on than to fall silent because a playlist went stale.
     */
    fun playPlaylist(id: String): Boolean = onMain {
        val existing = songFiles().map { it.name }.toSet()
        val names = library.songsIn(id, existing)
        if (names.isEmpty()) return@onMain false

        val items = names.map { itemFor(File(musicDir, it)) }
        player.setMediaItems(items, 0, 0)
        player.prepare()
        player.play()
        true
    }

    // ---------- Up Next ----------
    //
    // A queue kept beside the player rather than inside it.
    //
    // ExoPlayer's own playlist cannot express this: with shuffle on, the
    // item after the current one in the timeline is not the item that plays
    // next, and inserting into a shuffled order puts the new entry at a
    // random position. So the queue lives here and takes priority — when a
    // song ends naturally and something is queued, we jump to it.
    //
    // The deliberate consequence: queueing overrides shuffle. Ask for three
    // songs and you get those three, in that order, then shuffle resumes.
    // That is what people mean by "play next".

    private val upNext = mutableListOf<String>()

    fun queue(name: String, playNext: Boolean) = onMain {
        // Re-queueing a song moves it rather than listing it twice.
        upNext.remove(name)
        if (playNext) upNext.add(0, name) else upNext.add(name)
        broadcast()
        Unit
    }

    fun upNextNames(): List<String> = onMain { upNext.toList() }

    fun clearQueue() = onMain { upNext.clear(); broadcast() }

    fun removeFromQueue(name: String) = onMain { upNext.remove(name); broadcast(); Unit }

    /**
     * Jump to the next queued song that still exists.
     *
     * Entries whose files have gone are dropped rather than skipped over
     * forever, so a deleted song cannot wedge the queue.
     */
    private fun consumeQueue(): Boolean {
        while (upNext.isNotEmpty()) {
            val name = upNext.removeAt(0)
            val index = (0 until player.mediaItemCount)
                .firstOrNull { player.getMediaItemAt(it).mediaId == name }
            if (index != null) {
                player.seekTo(index, 0)
                return true
            }
        }
        return false
    }

    // ---------- Controls (used by the remote and the phone page) ----------

    fun control(action: String, name: String? = null) = onMain {
        when (action) {
            "toggle" -> if (player.isPlaying) player.pause() else resume()
            "next" -> player.seekToNextMediaItem()
            "prev" -> player.seekToPreviousMediaItem()
            "shuffle" -> {
                player.shuffleModeEnabled = !player.shuffleModeEnabled
                prefs.edit().putBoolean("shuffle", player.shuffleModeEnabled).apply()
            }
            "seek" -> name?.toLongOrNull()?.let { player.seekTo(it.coerceAtLeast(0L)) }
            "play" -> {
                val i = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == name }
                if (i != null) { player.seekTo(i, 0); resume() }
            }
            else -> {}
        }
        Unit
    }

    /**
     * Set the volume for whichever period we are currently in.
     *
     * Dragging the slider at 11pm should change the night level, not the day
     * one — otherwise the schedule would silently undo the change at the
     * next tick and the slider would appear broken.
     */
    fun setLiveVolume(percent: Int) = onMain {
        putSetting(if (isNight()) "nightVolume" else "dayVolume", percent)
    }

    private fun resume() {
        if (player.mediaItemCount == 0) return
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.play()
    }

    fun displayTitle(): String =
        player.mediaMetadata.title?.toString()
            ?: player.currentMediaItem?.mediaId?.substringBeforeLast('.') ?: ""

    fun stateJson(): String = onMain {
        val songs = JSONArray().apply { songFiles().forEach { put(it.name) } }
        val md = player.mediaMetadata
        JSONObject()
            .put("songs", songs)
            .put("library", libraryJson())
            .put("current", player.currentMediaItem?.mediaId ?: JSONObject.NULL)
            .put("title", displayTitle())
            .put("artist", (md.artist ?: md.albumArtist ?: "").toString())
            .put("playing", player.isPlaying)
            .put("shuffle", player.shuffleModeEnabled)
            .put("upNext", JSONArray().apply { upNext.forEach { put(it) } })
            .put("position", player.currentPosition.coerceAtLeast(0L))
            .put("duration", player.duration.coerceAtLeast(0L))
            .put("volume", if (isNight()) nightVolume else dayVolume)
            .toString()
    }

    /** ExoPlayer only likes the main thread; the web server runs on its own threads. */
    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        var result: Result<T>? = null
        main.post {
            result = runCatching(block)
            latch.countDown()
        }
        latch.await(5, TimeUnit.SECONDS)
        return result?.getOrThrow() ?: throw IllegalStateException("Player didn't respond in time")
    }

    // ---------- Song metadata ----------
    //
    // The library list used to show bare filenames. Reading the tags gives
    // real titles, artists and durations — but MediaMetadataRetriever opens
    // and parses the file, which is far too slow to do on every poll from
    // the phone (it polls every 3 seconds). So results are cached by file
    // path + size + modified time: a cache entry can only go stale if the
    // file itself changed, in which case the key changes with it.

    /**
     * Cached title/artist/duration for one file.
     *
     * Named Meta, not Tags: a private `Tags` here would shadow the top-level
     * Tags object inside this file, and Tags.Lyrics would silently resolve
     * against the wrong thing.
     */
    private data class Meta(val title: String, val artist: String, val durationMs: Long)

    /** What the TV browser and the phone both render a song from. */
    data class SongInfo(
        val name: String,
        val title: String,
        val artist: String,
        val durationMs: Long,
        val added: Long
    )

    private val tagCache = java.util.concurrent.ConcurrentHashMap<String, Meta>()

    /** Cache identity: a hit can only go stale if the file itself changed. */
    private fun cacheKey(f: File) = f.name + ":" + f.length() + ":" + f.lastModified()

    private fun tagsFor(f: File): Meta {
        val key = cacheKey(f)
        tagCache[key]?.let { return it }

        val fallback = Meta(f.name.substringBeforeLast('.'), "", 0L)
        val tags = try {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(f.absolutePath)
                Meta(
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        ?.takeIf { it.isNotBlank() } ?: fallback.title,
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        ?.takeIf { it.isNotBlank() }
                        ?: mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                            ?.takeIf { it.isNotBlank() } ?: "",
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                        ?.toLongOrNull() ?: 0L
                )
            } finally {
                // release() throws on some Fire OS builds; never let that
                // take down a library listing.
                try { mmr.release() } catch (e: Exception) {}
            }
        } catch (e: Exception) {
            fallback
        }

        // Unbounded growth is not a risk in practice, but a wall display runs
        // for months — keep a ceiling anyway.
        if (tagCache.size > 2000) tagCache.clear()
        tagCache[key] = tags
        return tags
    }

    /**
     * True if a song with the same tags (or the same size) is already here.
     *
     * Uploading the same file twice used to silently create "song (2).mp3",
     * so a library slowly filled with duplicates nobody noticed.
     */
    fun findDuplicate(name: String, size: Long): String? {
        val incomingTitle = name.substringBeforeLast('.').lowercase()
        return songFiles().firstOrNull { existing ->
            existing.length() == size ||
                existing.name.substringBeforeLast('.').lowercase() == incomingTitle
        }?.name
    }

    /**
     * The library using only tags already cached — never parses a file.
     *
     * This is what the TV browser opens with. Parsing is slow enough that
     * doing it for a few hundred songs on the main thread would freeze the
     * screen for seconds, so anything not yet cached falls back to its
     * filename and is filled in by [warmTags] a moment later. The list
     * appears instantly and sharpens, rather than making you wait.
     */
    fun libraryFast(): List<SongInfo> = songFiles().map { f ->
        val t = tagCache[cacheKey(f)]
        SongInfo(
            name = f.name,
            title = t?.title ?: f.name.substringBeforeLast('.'),
            artist = t?.artist ?: "",
            durationMs = t?.durationMs ?: 0L,
            added = f.lastModified()
        )
    }

    /**
     * Parse anything [libraryFast] had to guess at.
     *
     * Must be called off the main thread. Cheap on every call after the
     * first, because [tagsFor] caches.
     */
    fun warmTags() {
        for (f in songFiles()) {
            try {
                tagsFor(f)
            } catch (e: Exception) {
                // One unreadable file must not stop the rest being read.
            }
        }
    }

    /**
     * Embedded cover art for one song, as raw bytes.
     *
     * Only the currently playing track's art was ever available before, via
     * ExoPlayer's metadata. The Art Wall needs everyone's, which means
     * opening files directly.
     *
     * Must be called off the main thread — this opens and parses the file.
     * Songs found to have no art are remembered, so a library of untagged
     * MP3s is not reopened on every pass.
     */
    fun artworkFor(name: String): ByteArray? {
        if (noArtwork.contains(name)) return null
        val f = File(musicDir, name)
        if (!f.isFile) return null

        return try {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(f.absolutePath)
                val bytes = mmr.embeddedPicture
                if (bytes == null) noArtwork.add(name)
                bytes
            } finally {
                try { mmr.release() } catch (e: Exception) {}
            }
        } catch (e: Exception) {
            noArtwork.add(name)
            null
        }
    }

    /** Songs known to carry no embedded cover. Cheap negative cache. */
    private val noArtwork = java.util.Collections.newSetFromMap(
        java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    )

    /**
     * Lyrics for a song, or null.
     *
     * Cached on the same name+size+mtime identity as tags, including the
     * misses — a library with no lyrics must not reopen every file each time
     * the mode is shown. Must be called off the main thread.
     */
    fun lyricsFor(name: String): Tags.Lyrics? {
        val f = File(musicDir, name)
        if (!f.isFile) return null
        val key = cacheKey(f)

        lyricCache[key]?.let { return it.value }
        val found = try {
            Tags.lyricsFor(f)
        } catch (e: Exception) {
            null
        }
        if (lyricCache.size > 500) lyricCache.clear()
        lyricCache[key] = Boxed(found)
        return found
    }

    /** Boxed so a cached "no lyrics" is distinguishable from "not cached". */
    private class Boxed(val value: Tags.Lyrics?)

    private val lyricCache = java.util.concurrent.ConcurrentHashMap<String, Boxed>()

    fun libraryJson(): JSONArray {
        val arr = JSONArray()
        for (f in songFiles()) {
            val t = tagsFor(f)
            arr.put(
                JSONObject()
                    .put("name", f.name)
                    .put("title", t.title)
                    .put("artist", t.artist)
                    .put("duration", t.durationMs)
                    .put("size", f.length())
                    .put("added", f.lastModified())
                    .put("plays", library.playCount(f.name))
            )
        }
        return arr
    }

    // ---------- Settings ----------
    //
    // Everything below is stored in SharedPreferences and editable from the
    // phone page. Defaults are chosen for a wall-mounted screen that is on
    // all night: quiet and dim after 22:00, back to normal at 07:00.

    fun setting(key: String, fallback: Int): Int = prefs.getInt(key, fallback)

    /** Volume the music plays at during the day, 0-100. */
    val dayVolume: Int get() = setting("dayVolume", 100)

    /** Volume during the night window, 0-100. Lower, not silent. */
    val nightVolume: Int get() = setting("nightVolume", 35)

    /** Hour the night window opens, 0-23. */
    val nightStart: Int get() = setting("nightStart", 22)

    /** Hour the night window closes, 0-23. */
    val nightEnd: Int get() = setting("nightEnd", 7)

    /** How far the screen dims at night, 0-100 where 100 is fully black. */
    val nightDim: Int get() = setting("nightDim", 65)

    /** Whether the night window does anything at all. */
    val nightEnabled: Boolean get() = prefs.getBoolean("nightEnabled", true)

    /** Epoch millis the sleep timer fires at, or 0 when it is off. */
    val sleepAt: Long get() = prefs.getLong("sleepAt", 0L)

    fun putSetting(key: String, value: Int) {
        prefs.edit().putInt(key, value.coerceIn(0, 100)).apply()
        applySchedule()
        broadcast()
    }

    fun putHour(key: String, hour: Int) {
        prefs.edit().putInt(key, hour.coerceIn(0, 23)).apply()
        applySchedule()
    }

    fun putFlag(key: String, on: Boolean) {
        prefs.edit().putBoolean(key, on).apply()
        applySchedule()
    }

    /** Arm the sleep timer for [minutes] from now; 0 cancels it. */
    fun setSleep(minutes: Int) {
        val at = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
        prefs.edit().putLong("sleepAt", at).apply()
        applySchedule()
    }

    // ---------- Night window ----------

    /**
     * True when the clock is inside the night window.
     *
     * Handles the window wrapping past midnight, which is the normal case:
     * 22:00-07:00 means "at or after 22, OR before 7", not "between".
     */
    fun isNight(): Boolean {
        if (!nightEnabled) return false
        val start = nightStart
        val end = nightEnd
        if (start == end) return false
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (start < end) hour in start until end else hour >= start || hour < end
    }

    /**
     * Apply whatever the clock and the sleep timer say right now.
     *
     * Volume is ramped rather than stepped, so a song does not lurch quieter
     * the moment 22:00 arrives — it eases over a few seconds.
     */
    fun applySchedule() = onMain {
        val sleep = sleepAt
        if (sleep > 0L && System.currentTimeMillis() >= sleep) {
            prefs.edit().putLong("sleepAt", 0L).apply()
            fadeTo(0f) { player.pause(); player.volume = targetVolume() }
            return@onMain
        }
        fadeTo(targetVolume())
    }

    private fun targetVolume(): Float =
        (if (isNight()) nightVolume else dayVolume).coerceIn(0, 100) / 100f

    private var fading: Runnable? = null

    /** Ease the player volume toward [to] over about a second. */
    private fun fadeTo(to: Float, onDone: (() -> Unit)? = null) {
        fading?.let { main.removeCallbacks(it) }
        val step = object : Runnable {
            override fun run() {
                val from = player.volume
                val delta = to - from
                if (kotlin.math.abs(delta) < 0.02f) {
                    player.volume = to
                    onDone?.invoke()
                    return
                }
                player.volume = (from + delta * 0.25f).coerceIn(0f, 1f)
                main.postDelayed(this, 60)
            }
        }
        fading = step
        main.post(step)
    }

    /** Re-checks the schedule twice a minute. Cheap, and never drifts. */
    private val scheduleTick = object : Runnable {
        override fun run() {
            applySchedule()
            main.postDelayed(this, 30_000)
        }
    }

    // ---------- Storage ----------

    /** Bytes still writable in the music folder. */
    fun freeBytes(): Long = try { musicDir.usableSpace } catch (e: Exception) { 0L }

    /** Bytes the library currently occupies. */
    fun usedBytes(): Long = songFiles().sumOf { it.length() }

    // ---------- Pairing PIN ----------
    //
    // The upload server accepts anything on the local network, so without
    // this anyone on the wifi could delete the whole library with one
    // request. The PIN is shown on the TV screen: if you can see the screen,
    // you are allowed to control it.

    fun pin(): String {
        prefs.getString("pin", null)?.let { return it }
        val fresh = (1000..9999).random().toString()
        prefs.edit().putString("pin", fresh).apply()
        return fresh
    }

    fun checkPin(candidate: String?): Boolean = candidate != null && candidate == pin()

    fun settingsJson(): String = JSONObject()
        .put("dayVolume", dayVolume)
        .put("nightVolume", nightVolume)
        .put("nightStart", nightStart)
        .put("nightEnd", nightEnd)
        .put("nightDim", nightDim)
        .put("nightEnabled", nightEnabled)
        .put("isNight", isNight())
        .put("sleepAt", sleepAt)
        .put("freeBytes", freeBytes())
        .put("usedBytes", usedBytes())
        .toString()

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("playback", "Playback", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = NotificationCompat.Builder(this, "playback")
            .setContentTitle("WallTunes")
            .setContentText("Playing music")
            .setSmallIcon(R.drawable.ic_note)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
    }

    companion object {
        const val PORT = 8080

        /** Playable extensions. UploadServer validates against this too. */
        val AUDIO_TYPES = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "opus", "wav")
    }
}

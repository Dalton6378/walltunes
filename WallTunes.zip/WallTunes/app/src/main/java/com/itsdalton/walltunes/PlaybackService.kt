package com.itsdalton.walltunes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Calendar
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs the music 24/7. Lives in the background even when the screen app is closed,
 * and hosts the little web server your phone uses to add songs.
 */
class PlaybackService : Service() {

    inner class LocalBinder : Binder() {
        val service: PlaybackService get() = this@PlaybackService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("walltunes", MODE_PRIVATE) }
    private var server: UploadServer? = null

    lateinit var player: ExoPlayer
        private set

    val musicDir: File by lazy { File(filesDir, "music").apply { mkdirs() } }

    /**
     * Playlists, favourites and play counts.
     *
     * Deliberately NOT in the playback path: the library is still whatever
     * [songFiles] finds on disk, so this file can be lost entirely without
     * costing a single song.
     */
    val library: Library by lazy { Library(filesDir) }

    /**
     * Phones listening over SSE.
     *
     * CopyOnWriteArraySet because it is read on every broadcast and written
     * only when a phone connects or leaves — exactly the shape it is for.
     */
    private val streams = java.util.concurrent.CopyOnWriteArraySet<EventStream>()

    fun addStream(s: EventStream) { streams.add(s) }
    fun removeStream(s: EventStream) { streams.remove(s) }

    /**
     * Tell every listening phone that something changed.
     *
     * Coalesced: the player fires events in bursts — a track change alone
     * produces several — and phones do not need to hear about each one.
     */
    private val broadcastNow = Runnable {
        if (streams.isEmpty()) return@Runnable
        val json = stateJson()
        for (s in streams) {
            val alive = try {
                s.push(json)
            } catch (e: Exception) {
                false
            }
            if (!alive) streams.remove(s)
        }
    }

    fun broadcast() {
        main.removeCallbacks(broadcastNow)
        main.postDelayed(broadcastNow, 120)
    }

    // When the TV wakes up, pick the music back up.
    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = resume()
    }

    override fun onCreate() {
        super.onCreate()
        startInForeground()

        // Float output is the one change here that genuinely affects sound
        // quality. This app attenuates constantly — night volume at 35%,
        // ReplayGain trims, the sleep fade — and with 16-bit output every one
        // of those multiplications truncates. Quiet passages are where that
        // shows up, which on a player that runs all night is most of them.
        //
        // Decoder fallback matters for a different reason: one odd file that
        // the primary decoder refuses should drop to another decoder rather
        // than stopping the music at 3am.
        val renderers = DefaultRenderersFactory(this)
            .setEnableAudioFloatOutput(true)
            .setEnableDecoderFallback(true)

        player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // Trims the dead air that makes a shuffled library feel ragged.
        // Gapless is already native to ExoPlayer for same-format runs, so
        // albums recorded to flow together still do.
        player.skipSilenceEnabled = prefs.getBoolean("skipSilence", true)

        player.repeatMode = Player.REPEAT_MODE_ALL
        player.shuffleModeEnabled = prefs.getBoolean("shuffle", true)
        player.addListener(object : Player.Listener {
            // Anything the phone renders — play state, track, shuffle —
            // arrives here. Position is not pushed: the phone extrapolates
            // it locally, which is what removes the need to poll at all.
            override fun onEvents(p: Player, events: Player.Events) = broadcast()

            override fun onPlayerError(error: PlaybackException) {
                // A broken file shouldn't stop the music: skip it and keep going.
                main.postDelayed({
                    if (player.mediaItemCount > 1) player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }, 3000)
            }

            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                // A song finished on its own and something is queued: go
                // there instead of wherever the player was heading. Only on
                // AUTO — a seek or an explicit play must not eat the queue.
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO &&
                    upNext.isNotEmpty() && consumeQueue()
                ) return

                item?.let {
                    applyGainFor(it.mediaId)
                    prefs.edit().putString("last", it.mediaId).apply()
                    // Counted on transition rather than on play, so pausing
                    // and resuming a song does not inflate its count.
                    it.mediaId.let { id -> library.bumpPlayCount(id) }
                }
            }
        })

        musicDir.listFiles { f -> f.name.startsWith(".upload-") }?.forEach { it.delete() }
        loadLibrary()

        // Fill in any missing lyrics, a little after boot. Delayed because
        // the TV's wifi is often not up yet when the service starts, and a
        // sweep that runs too early just records a run of failures.
        main.postDelayed(sweepAgain, SWEEP_DELAY_MS)

        ContextCompat.registerReceiver(
            this, screenOn, IntentFilter(Intent.ACTION_SCREEN_ON), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Night mode, quiet hours and the sleep timer all ride on one ticker.
        main.post(scheduleTick)

        server = UploadServer(this, PORT).also {
            try {
                it.start(10_000, false)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        main.removeCallbacks(scheduleTick)
        streams.forEach { it.shutdown() }
        streams.clear()
        gainThread.shutdownNow()
        try { compressor?.release() } catch (e: Exception) {}
        compressor = null
        server?.stop()
        try { unregisterReceiver(screenOn) } catch (_: Exception) {}
        player.release()
        super.onDestroy()
    }

    // ---------- Library ----------

    /**
     * The library: audio files only.
     *
     * The extension filter is not cosmetic. Sidecar .lrc files live in this
     * same directory, and without it every set of lyrics would appear in the
     * library as an unplayable song.
     */
    fun songFiles(): List<File> =
        musicDir.listFiles { f ->
            f.isFile &&
                !f.name.startsWith(".") &&
                f.name.substringAfterLast('.', "").lowercase() in AUDIO_TYPES
        }?.sortedBy { it.name.lowercase() } ?: emptyList()

    private fun itemFor(f: File) =
        MediaItem.Builder().setUri(Uri.fromFile(f)).setMediaId(f.name).build()

    private fun loadLibrary() {
        val items = songFiles().map { itemFor(it) }
        val last = prefs.getString("last", null)
        val start = items.indexOfFirst { it.mediaId == last }.coerceAtLeast(0)
        player.setMediaItems(items, start, 0)
        player.prepare()
        player.playWhenReady = true
    }

    fun addSong(f: File) = onMain {
        if (player.mediaItemCount == 0) loadLibrary()
        else player.addMediaItem(itemFor(f))
        // Go and find its words now, so they are waiting rather than being
        // fetched the first time the song happens to come up.
        requestLyrics(f.name)
        Unit
    }

    /**
     * Forget what lyrics were resolved, after a .lrc arrives for a song
     * already on the TV. The song file is untouched by that upload, so its
     * cache key does not change and the memoised answer would otherwise
     * stay stale until reboot.
     */
    fun clearLyricCache() = lyricCache.clear()

    fun removeSong(name: String) = onMain {
        val index = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == name }
        if (index != null) player.removeMediaItem(index)
        File(musicDir, name).delete()
        // Drop it from playlists, favourites, counts and the queue too, so
        // nothing keeps a reference to a file that no longer exists.
        library.forget(name)
        upNext.remove(name)
        forgetLyrics(name)
        Unit
    }

    /**
     * Replace what is playing with a playlist, in its saved order.
     *
     * Songs that no longer exist on disk are skipped rather than queued as
     * broken items. An empty result is a no-op: better to keep playing what
     * was on than to fall silent because a playlist went stale.
     */
    fun playPlaylist(id: String): Boolean = onMain {
        val existing = songFiles().map { it.name }.toSet()
        val names = library.songsIn(id, existing)
        if (names.isEmpty()) return@onMain false

        val items = names.map { itemFor(File(musicDir, it)) }
        player.setMediaItems(items, 0, 0)
        player.prepare()
        player.play()
        true
    }

    // ---------- Up Next ----------
    //
    // A queue kept beside the player rather than inside it.
    //
    // ExoPlayer's own playlist cannot express this: with shuffle on, the
    // item after the current one in the timeline is not the item that plays
    // next, and inserting into a shuffled order puts the new entry at a
    // random position. So the queue lives here and takes priority — when a
    // song ends naturally and something is queued, we jump to it.
    //
    // The deliberate consequence: queueing overrides shuffle. Ask for three
    // songs and you get those three, in that order, then shuffle resumes.
    // That is what people mean by "play next".

    private val upNext = mutableListOf<String>()

    fun queue(name: String, playNext: Boolean) = onMain {
        // Re-queueing a song moves it rather than listing it twice.
        upNext.remove(name)
        if (playNext) upNext.add(0, name) else upNext.add(name)
        broadcast()
        Unit
    }

    fun upNextNames(): List<String> = onMain { upNext.toList() }

    fun clearQueue() = onMain { upNext.clear(); broadcast() }

    fun removeFromQueue(name: String) = onMain { upNext.remove(name); broadcast(); Unit }

    /**
     * Jump to the next queued song that still exists.
     *
     * Entries whose files have gone are dropped rather than skipped over
     * forever, so a deleted song cannot wedge the queue.
     */
    private fun consumeQueue(): Boolean {
        while (upNext.isNotEmpty()) {
            val name = upNext.removeAt(0)
            val index = (0 until player.mediaItemCount)
                .firstOrNull { player.getMediaItemAt(it).mediaId == name }
            if (index != null) {
                player.seekTo(index, 0)
                return true
            }
        }
        return false
    }

    // ---------- Controls (used by the remote and the phone page) ----------

    fun control(action: String, name: String? = null) = onMain {
        when (action) {
            "toggle" -> if (player.isPlaying) player.pause() else resume()
            "next" -> player.seekToNextMediaItem()
            "prev" -> player.seekToPreviousMediaItem()
            "shuffle" -> {
                player.shuffleModeEnabled = !player.shuffleModeEnabled
                prefs.edit().putBoolean("shuffle", player.shuffleModeEnabled).apply()
            }
            "seek" -> name?.toLongOrNull()?.let { player.seekTo(it.coerceAtLeast(0L)) }
            "play" -> {
                val i = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == name }
                if (i != null) { player.seekTo(i, 0); resume() }
            }
            else -> {}
        }
        Unit
    }

    /**
     * Set the volume for whichever period we are currently in.
     *
     * Dragging the slider at 11pm should change the night level, not the day
     * one — otherwise the schedule would silently undo the change at the
     * next tick and the slider would appear broken.
     */
    fun setLiveVolume(percent: Int) = onMain {
        putSetting(if (isNight()) "nightVolume" else "dayVolume", percent)
    }

    private fun resume() {
        if (player.mediaItemCount == 0) return
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.play()
    }

    fun displayTitle(): String =
        player.mediaMetadata.title?.toString()
            ?: player.currentMediaItem?.mediaId?.substringBeforeLast('.') ?: ""

    fun stateJson(): String = onMain {
        val songs = JSONArray().apply { songFiles().forEach { put(it.name) } }
        val md = player.mediaMetadata
        JSONObject()
            .put("songs", songs)
            .put("library", libraryJson())
            .put("current", player.currentMediaItem?.mediaId ?: JSONObject.NULL)
            .put("title", displayTitle())
            .put("artist", (md.artist ?: md.albumArtist ?: "").toString())
            .put("playing", player.isPlaying)
            .put("shuffle", player.shuffleModeEnabled)
            .put("upNext", JSONArray().apply { upNext.forEach { put(it) } })
            .put("position", player.currentPosition.coerceAtLeast(0L))
            .put("duration", player.duration.coerceAtLeast(0L))
            .put("volume", if (isNight()) nightVolume else dayVolume)
            .toString()
    }

    /** ExoPlayer only likes the main thread; the web server runs on its own threads. */
    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        var result: Result<T>? = null
        main.post {
            result = runCatching(block)
            latch.countDown()
        }
        latch.await(5, TimeUnit.SECONDS)
        return result?.getOrThrow() ?: throw IllegalStateException("Player didn't respond in time")
    }

    // ---------- Song metadata ----------
    //
    // The library list used to show bare filenames. Reading the tags gives
    // real titles, artists and durations — but MediaMetadataRetriever opens
    // and parses the file, which is far too slow to do on every poll from
    // the phone (it polls every 3 seconds). So results are cached by file
    // path + size + modified time: a cache entry can only go stale if the
    // file itself changed, in which case the key changes with it.

    /**
     * Cached title/artist/duration for one file.
     *
     * Named Meta, not Tags: a private `Tags` here would shadow the top-level
     * Tags object inside this file, and Tags.Lyrics would silently resolve
     * against the wrong thing.
     */
    private data class Meta(val title: String, val artist: String, val durationMs: Long)

    /** What the TV browser and the phone both render a song from. */
    data class SongInfo(
        val name: String,
        val title: String,
        val artist: String,
        val durationMs: Long,
        val added: Long
    )

    private val tagCache = java.util.concurrent.ConcurrentHashMap<String, Meta>()

    /** Cache identity: a hit can only go stale if the file itself changed. */
    private fun cacheKey(f: File) = f.name + ":" + f.length() + ":" + f.lastModified()

    private fun tagsFor(f: File): Meta {
        val key = cacheKey(f)
        tagCache[key]?.let { return it }

        val fallback = Meta(f.name.substringBeforeLast('.'), "", 0L)
        val tags = try {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(f.absolutePath)
                Meta(
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        ?.takeIf { it.isNotBlank() } ?: fallback.title,
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        ?.takeIf { it.isNotBlank() }
                        ?: mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                            ?.takeIf { it.isNotBlank() } ?: "",
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                        ?.toLongOrNull() ?: 0L
                )
            } finally {
                // release() throws on some Fire OS builds; never let that
                // take down a library listing.
                try { mmr.release() } catch (e: Exception) {}
            }
        } catch (e: Exception) {
            fallback
        }

        // Unbounded growth is not a risk in practice, but a wall display runs
        // for months — keep a ceiling anyway.
        if (tagCache.size > 2000) tagCache.clear()
        tagCache[key] = tags
        return tags
    }

    /**
     * True if a song with the same tags (or the same size) is already here.
     *
     * Uploading the same file twice used to silently create "song (2).mp3",
     * so a library slowly filled with duplicates nobody noticed.
     */
    fun findDuplicate(name: String, size: Long): String? {
        val incomingTitle = name.substringBeforeLast('.').lowercase()
        return songFiles().firstOrNull { existing ->
            existing.length() == size ||
                existing.name.substringBeforeLast('.').lowercase() == incomingTitle
        }?.name
    }

    /**
     * The library using only tags already cached — never parses a file.
     *
     * This is what the TV browser opens with. Parsing is slow enough that
     * doing it for a few hundred songs on the main thread would freeze the
     * screen for seconds, so anything not yet cached falls back to its
     * filename and is filled in by [warmTags] a moment later. The list
     * appears instantly and sharpens, rather than making you wait.
     */
    fun libraryFast(): List<SongInfo> = songFiles().map { f ->
        val t = tagCache[cacheKey(f)]
        SongInfo(
            name = f.name,
            title = t?.title ?: f.name.substringBeforeLast('.'),
            artist = t?.artist ?: "",
            durationMs = t?.durationMs ?: 0L,
            added = f.lastModified()
        )
    }

    /**
     * Parse anything [libraryFast] had to guess at.
     *
     * Must be called off the main thread. Cheap on every call after the
     * first, because [tagsFor] caches.
     */
    fun warmTags() {
        for (f in songFiles()) {
            try {
                tagsFor(f)
            } catch (e: Exception) {
                // One unreadable file must not stop the rest being read.
            }
        }
    }

    /**
     * Embedded cover art for one song, as raw bytes.
     *
     * Only the currently playing track's art was ever available before, via
     * ExoPlayer's metadata. The Art Wall needs everyone's, which means
     * opening files directly.
     *
     * Must be called off the main thread — this opens and parses the file.
     * Songs found to have no art are remembered, so a library of untagged
     * MP3s is not reopened on every pass.
     */
    fun artworkFor(name: String): ByteArray? {
        if (noArtwork.contains(name)) return null
        val f = File(musicDir, name)
        if (!f.isFile) return null

        return try {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(f.absolutePath)
                val bytes = mmr.embeddedPicture
                if (bytes == null) noArtwork.add(name)
                bytes
            } finally {
                try { mmr.release() } catch (e: Exception) {}
            }
        } catch (e: Exception) {
            noArtwork.add(name)
            null
        }
    }

    /** Songs known to carry no embedded cover. Cheap negative cache. */
    private val noArtwork = java.util.Collections.newSetFromMap(
        java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    )

    /**
     * Lyrics for a song, or null.
     *
     * Cached on the same name+size+mtime identity as tags, including the
     * misses — a library with no lyrics must not reopen every file each time
     * the mode is shown. Must be called off the main thread.
     */
    fun lyricsFor(name: String): Tags.Lyrics? {
        val f = File(musicDir, name)
        if (!f.isFile) return null
        val key = cacheKey(f)

        lyricCache[key]?.let { return it.value }
        val found = try {
            // A .lrc you put there, then the song's own tags, then anything
            // downloaded earlier. The order is the point: what you chose
            // always beats what the internet offered.
            Tags.lyricsFor(f) ?: downloaded(name)
        } catch (e: Exception) {
            null
        }
        if (lyricCache.size > 500) lyricCache.clear()
        lyricCache[key] = Boxed(found)

        // Nothing on disk: ask the network, and say so next time round.
        if (found == null) requestLyrics(name)
        return found
    }

    /** Boxed so a cached "no lyrics" is distinguishable from "not cached". */
    private class Boxed(val value: Tags.Lyrics?)

    private val lyricCache = java.util.concurrent.ConcurrentHashMap<String, Boxed>()

    // ------------------------------------------------------ Lyric downloads

    /**
     * Downloaded lyrics live apart from the music.
     *
     * [songFiles] treats the music directory as the library, so a cache file
     * in there would have to be filtered out of everything forever. Here it
     * can be deleted wholesale without touching a single song.
     */
    val lyricsDir: File by lazy { File(filesDir, "lyrics").apply { mkdirs() } }

    /** Fetching is opt-out: the point is that songs get words unattended. */
    val autoLyrics: Boolean get() = prefs.getBoolean("autoLyrics", true)

    /**
     * Bumped whenever lyrics land.
     *
     * The screen resolves lyrics once per song, which is right — but a
     * download can finish while that same song is still playing, and
     * without a signal the words would not appear until the next track.
     */
    @Volatile
    var lyricsRevision: Int = 0
        private set

    /**
     * One thread, so a library sweep can never saturate a weak device and
     * never runs two lookups at once against a free public service.
     */
    private val lyricNet by lazy {
        java.util.concurrent.Executors.newSingleThreadExecutor { r ->
            Thread(r, "lyrics").apply {
                isDaemon = true
                priority = Thread.MIN_PRIORITY
            }
        }
    }

    /**
     * Why the last lookup failed, if it did.
     *
     * One field rather than one per song: the causes are things like "no
     * internet" that affect every song at once, and it is the first thing
     * anyone needs to see when nothing is appearing.
     */
    @Volatile
    var lastLyricError: String? = null
        private set

    /** Consecutive failures per song, so a bad run eventually gives up. */
    private val lyricFails = java.util.concurrent.ConcurrentHashMap<String, Int>()

    /** Songs already queued, so a redraw cannot enqueue the same one twice. */
    private val lyricPending =
        java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())

    /** Read a previously downloaded file, honouring the miss markers. */
    private fun downloaded(name: String): Tags.Lyrics? {
        if (LyricsNet.instrumentalFile(lyricsDir, name).isFile) return null
        val f = LyricsNet.cacheFile(lyricsDir, name)
        if (!f.isFile || f.length() <= 0) return null
        return try {
            Tags.parseAny(f.readText())
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Should we go and look for this song's lyrics?
     *
     * A permanent marker means never. A recorded miss means not yet: the
     * database is added to by people over time, so a song nobody has words
     * for today may well have them next month — but asking again on every
     * screen redraw would be rude and pointless.
     */
    private fun worthFetching(name: String): Boolean {
        if (!autoLyrics) return false
        if (LyricsNet.instrumentalFile(lyricsDir, name).isFile) return false
        if (LyricsNet.cacheFile(lyricsDir, name).isFile) return false
        val miss = LyricsNet.missFile(lyricsDir, name)
        if (miss.isFile && System.currentTimeMillis() - miss.lastModified() < MISS_RETRY_MS) return false
        return true
    }

    /** Queue one song for lookup. Cheap and safe to call repeatedly. */
    fun requestLyrics(name: String) {
        if (!worthFetching(name)) return
        if (!lyricPending.add(name)) return
        try {
            lyricNet.execute { fetchLyrics(name) }
        } catch (e: Exception) {
            lyricPending.remove(name)       // executor shutting down
        }
    }

    /**
     * Look one song up and write down whatever came back, including the
     * disappointments. Runs on the lyrics thread.
     */
    private fun fetchLyrics(name: String) {
        try {
            val f = File(musicDir, name)
            if (!f.isFile) return
            val meta = tagsFor(f)

            val result = LyricsNet.lookup(
                title = meta.title,
                artist = meta.artist,
                album = "",
                durationMs = meta.durationMs
            )

            when (result) {
                is LyricsNet.Result.Found -> {
                    writeAtomic(LyricsNet.cacheFile(lyricsDir, name), result.text)
                    LyricsNet.missFile(lyricsDir, name).delete()
                    // Drop the memoised "no lyrics" so the next read sees them.
                    lyricCache.remove(cacheKey(f))
                    lyricFails.remove(name)
                    lastLyricError = null
                    lyricsRevision++
                    broadcast()
                }
                is LyricsNet.Result.Instrumental -> {
                    writeAtomic(LyricsNet.instrumentalFile(lyricsDir, name), "")
                    lyricsRevision++
                }
                is LyricsNet.Result.Missing -> {
                    writeAtomic(LyricsNet.missFile(lyricsDir, name), "")
                    // Reaching the service to be told "no" still proves the
                    // connection works.
                    lyricFails.remove(name)
                    lastLyricError = null
                    lyricsRevision++
                }
                is LyricsNet.Result.Failed -> {
                    // Remember why, so the screen can say something true
                    // instead of "looking" for the rest of time.
                    lastLyricError = result.reason
                    val n = (lyricFails[name] ?: 0) + 1
                    lyricFails[name] = n
                    if (n >= MAX_FAILS) {
                        // Stop claiming to be busy. A miss marker still
                        // expires, so this retries on its own later.
                        writeAtomic(LyricsNet.missFile(lyricsDir, name), "")
                        lyricFails.remove(name)
                    }
                    lyricsRevision++
                }
            }
        } catch (e: Exception) {
            Log.w("WallTunes", "lyric fetch failed for " + name + ": " + e.javaClass.simpleName)
        } finally {
            lyricPending.remove(name)
            // Spacing between lookups. This is a free service run by
            // volunteers, and a hundred-song sweep should read as a trickle
            // rather than a flood.
            try {
                Thread.sleep(LYRIC_GAP_MS)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }

    /**
     * Go looking for every song that has no words yet.
     *
     * This is what makes lyrics require nothing of anyone: rather than
     * fetching a song's lyrics the first time it happens to be shown, the
     * library fills itself in quietly in the background, so the words are
     * already there when the song comes round.
     */
    fun sweepLyrics() {
        if (!autoLyrics) return
        lyricNet.execute {
            for (f in songFiles()) {
                if (!autoLyrics) return@execute
                requestLyrics(f.name)
            }
        }
    }

    /**
     * Look this song up again from scratch.
     *
     * The escape hatch for when the automatic match picked the wrong
     * version — a live take, or a cover by someone else. Clearing the
     * markers is what makes it a genuine retry rather than a no-op.
     */
    fun refetchLyrics(name: String) {
        forgetLyrics(name)
        File(musicDir, name).takeIf { it.isFile }?.let { lyricCache.remove(cacheKey(it)) }
        lyricsRevision++
        requestLyrics(name)
        broadcast()
    }

    /**
     * One song's words, for the phone to render.
     *
     * Always answers, even when there is nothing to show, because "still
     * looking" and "this song has none" need to look different to whoever
     * is staring at the screen waiting for words to appear.
     */
    fun lyricsJson(name: String): String {
        val found = lyricsFor(name)
        val o = JSONObject().put("name", name)

        if (found == null) {
            val err = lastLyricError
            val state = when {
                LyricsNet.instrumentalFile(lyricsDir, name).isFile -> "none"
                lyricPending.contains(name) -> "looking"
                !autoLyrics -> "off"
                // A failure outranks a miss marker written because of it:
                // "no lyrics for this song" would be a guess, and the wrong
                // one, when the real answer is that nothing got through.
                err != null -> "error"
                LyricsNet.missFile(lyricsDir, name).isFile -> "none"
                else -> "looking"
            }
            return o.put("state", state).put("synced", false)
                .put("error", err ?: JSONObject.NULL)
                .put("lines", JSONArray()).toString()
        }

        val arr = JSONArray()
        for (line in found.lines) {
            arr.put(JSONObject().put("t", line.atMs).put("text", line.text))
        }
        return o.put("state", "ok").put("synced", found.synced).put("lines", arr).toString()
    }

    /**
     * How far the sweep has got, so the phone can show progress rather than
     * leaving someone wondering whether anything is happening.
     */
    fun lyricsStateJson(): String {
        var have = 0
        var none = 0
        val songs = songFiles()
        for (f in songs) {
            when {
                LyricsNet.instrumentalFile(lyricsDir, f.name).isFile -> none++
                LyricsNet.cacheFile(lyricsDir, f.name).isFile -> have++
                // A song with its own .lrc or embedded words never needs the
                // network, so it counts as done.
                Tags.lyricsFor(f) != null -> have++
                LyricsNet.missFile(lyricsDir, f.name).isFile -> none++
            }
        }
        return JSONObject()
            .put("enabled", autoLyrics)
            .put("error", lastLyricError ?: JSONObject.NULL)
            .put("total", songs.size)
            .put("have", have)
            .put("none", none)
            .put("pending", lyricPending.size)
            .toString()
    }

    /**
     * Is this song's lyric question answered for now?
     *
     * True once there is nothing more to wait for: either the words are
     * here, or we asked and there are none. False while a lookup is queued
     * or still to be made, which is what lets the screen say "looking"
     * rather than "none" and be telling the truth.
     */
    fun lyricsSettled(name: String): Boolean {
        if (lyricPending.contains(name)) return false
        if (LyricsNet.instrumentalFile(lyricsDir, name).isFile) return true
        if (LyricsNet.cacheFile(lyricsDir, name).isFile) return true
        if (LyricsNet.missFile(lyricsDir, name).isFile) return true
        // Never asked: a lookup is still owed, so this is not settled.
        return false
    }

    /** Re-runs the sweep on a slow loop; see [SWEEP_REPEAT_MS]. */
    private val sweepAgain = object : Runnable {
        override fun run() {
            sweepLyrics()
            main.postDelayed(this, SWEEP_REPEAT_MS)
        }
    }

    /**
     * A live check of whether the lyrics service can be reached at all.
     *
     * Worth having as its own thing: "no lyrics yet" and "this TV cannot
     * get online" look identical from the sofa, and guessing between them
     * wastes far more time than one deliberate request costs.
     */
    fun diagnoseLyrics(): String {
        val o = JSONObject().put("enabled", autoLyrics)
        val err = LyricsNet.probe()
        if (err == null) {
            lastLyricError = null
            o.put("ok", true).put("message", "The lyrics service is reachable.")
        } else {
            lastLyricError = err
            o.put("ok", false).put("message", err)
        }
        return o.toString()
    }

    /** Forget a deleted song's downloads, so the cache cannot outlive it. */
    private fun forgetLyrics(name: String) {
        LyricsNet.cacheFile(lyricsDir, name).delete()
        LyricsNet.missFile(lyricsDir, name).delete()
        LyricsNet.instrumentalFile(lyricsDir, name).delete()
    }

    /** Write via a temp file, the same way uploads land. */
    private fun writeAtomic(target: File, text: String) {
        val tmp = File(target.parentFile, "." + target.name + ".tmp")
        try {
            tmp.writeText(text)
            if (!tmp.renameTo(target)) {
                target.delete()
                tmp.renameTo(target)
            }
        } catch (e: Exception) {
            tmp.delete()
        }
    }

    fun libraryJson(): JSONArray {
        val arr = JSONArray()
        for (f in songFiles()) {
            val t = tagsFor(f)
            arr.put(
                JSONObject()
                    .put("name", f.name)
                    .put("title", t.title)
                    .put("artist", t.artist)
                    .put("duration", t.durationMs)
                    .put("size", f.length())
                    .put("added", f.lastModified())
                    .put("plays", library.playCount(f.name))
            )
        }
        return arr
    }

    // ---------- Settings ----------
    //
    // Everything below is stored in SharedPreferences and editable from the
    // phone page. Defaults are chosen for a wall-mounted screen that is on
    // all night: quiet and dim after 22:00, back to normal at 07:00.

    fun setting(key: String, fallback: Int): Int = prefs.getInt(key, fallback)

    /** Volume the music plays at during the day, 0-100. */
    val dayVolume: Int get() = setting("dayVolume", 100)

    /** Volume during the night window, 0-100. Lower, not silent. */
    val nightVolume: Int get() = setting("nightVolume", 35)

    /** Hour the night window opens, 0-23. */
    val nightStart: Int get() = setting("nightStart", 22)

    /** Hour the night window closes, 0-23. */
    val nightEnd: Int get() = setting("nightEnd", 7)

    /** How far the screen dims at night, 0-100 where 100 is fully black. */
    val nightDim: Int get() = setting("nightDim", 65)

    /** Whether the night window does anything at all. */
    val nightEnabled: Boolean get() = prefs.getBoolean("nightEnabled", true)

    /** Epoch millis the sleep timer fires at, or 0 when it is off. */
    val sleepAt: Long get() = prefs.getLong("sleepAt", 0L)

    fun putSetting(key: String, value: Int) {
        prefs.edit().putInt(key, value.coerceIn(0, 100)).apply()
        applySchedule()
        broadcast()
    }

    fun putHour(key: String, hour: Int) {
        prefs.edit().putInt(key, hour.coerceIn(0, 23)).apply()
        applySchedule()
    }

    fun putFlag(key: String, on: Boolean) {
        prefs.edit().putBoolean(key, on).apply()
        // Two of these change the player rather than just the schedule.
        if (key == "skipSilence") onMain { player.skipSilenceEnabled = on }
        if (key == "leveling") {
            trackGain = 1f
            player.currentMediaItem?.mediaId?.let { applyGainFor(it) }
        }
        // Switching it back on should start catching up straight away
        // rather than waiting for each song to come round.
        if (key == "autoLyrics" && on) sweepLyrics()
        applySchedule()
        broadcast()
    }

    /** Arm the sleep timer for [minutes] from now; 0 cancels it. */
    fun setSleep(minutes: Int) {
        val at = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
        prefs.edit().putLong("sleepAt", at).apply()
        applySchedule()
    }

    // ---------- Volume leveling ----------
    //
    // Albums are mastered at wildly different levels, and on shuffle that
    // means reaching for the remote between songs. ReplayGain tags say how
    // far each track sits from a reference loudness; applying that evens
    // them out without touching the files.

    /** Multiplier for the current track, 0..1. Never above 1 — see below. */
    @Volatile
    private var trackGain = 1f

    private val gainCache = java.util.concurrent.ConcurrentHashMap<String, Float>()

    /** Whether leveling is on. Off means every track plays at face value. */
    val levelingEnabled: Boolean get() = prefs.getBoolean("leveling", true)

    /**
     * Work out the gain for a song and apply it.
     *
     * Runs off the main thread: reading tags opens the file.
     *
     * Positive gain is deliberately discarded. A quiet track tagged +6dB
     * would need the signal amplified, and there is no headroom above full
     * scale — it would clip, which sounds far worse than being quiet. So
     * loud tracks are brought DOWN to meet the quiet ones, never the
     * reverse. The result is a slightly quieter library that never
     * distorts, and the day/night volume makes up the difference.
     */
    private fun applyGainFor(name: String) {
        if (!levelingEnabled) {
            trackGain = 1f
            applySchedule()
            return
        }

        gainCache[name]?.let {
            trackGain = it
            applySchedule()
            return
        }

        gainThread.execute {
            val db = try {
                Tags.replayGainDb(File(musicDir, name))
            } catch (e: Exception) {
                null
            }
            // Untagged songs play unchanged rather than being guessed at.
            val linear = when {
                db == null -> 1f
                db >= 0f -> 1f
                else -> Math.pow(10.0, (db / 20f).toDouble()).toFloat()
            }.coerceIn(MIN_GAIN, 1f)

            gainCache[name] = linear
            trackGain = linear
            main.post { applySchedule() }
        }
    }

    private val gainThread = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "walltunes-gain").apply { isDaemon = true }
    }

    // ---------- Night window ----------

    /**
     * True when the clock is inside the night window.
     *
     * Handles the window wrapping past midnight, which is the normal case:
     * 22:00-07:00 means "at or after 22, OR before 7", not "between".
     */
    fun isNight(): Boolean {
        if (!nightEnabled) return false
        val start = nightStart
        val end = nightEnd
        if (start == end) return false
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (start < end) hour in start until end else hour >= start || hour < end
    }

    /**
     * Apply whatever the clock and the sleep timer say right now.
     *
     * Volume is ramped rather than stepped, so a song does not lurch quieter
     * the moment 22:00 arrives — it eases over a few seconds.
     */
    fun applySchedule() = onMain {
        applyCompression()
        val sleep = sleepAt
        if (sleep > 0L && System.currentTimeMillis() >= sleep) {
            prefs.edit().putLong("sleepAt", 0L).apply()
            fadeTo(0f) { player.pause(); player.volume = targetVolume() }
            return@onMain
        }
        fadeTo(targetVolume())
    }

    private fun targetVolume(): Float {
        val night = nightVolume.coerceIn(0, 100) / 100f
        val day = dayVolume.coerceIn(0, 100) / 100f
        // Inside the wake window the level walks from night up to day.
        val base = if (isNight()) night + (day - night) * wakeFactor() else day
        return (base * trackGain).coerceIn(0f, 1f)
    }

    private var fading: Runnable? = null

    /** Ease the player volume toward [to] over about a second. */
    private fun fadeTo(to: Float, onDone: (() -> Unit)? = null) {
        fading?.let { main.removeCallbacks(it) }
        val step = object : Runnable {
            override fun run() {
                val from = player.volume
                val delta = to - from
                if (kotlin.math.abs(delta) < 0.02f) {
                    player.volume = to
                    onDone?.invoke()
                    return
                }
                player.volume = (from + delta * 0.25f).coerceIn(0f, 1f)
                main.postDelayed(this, 60)
            }
        }
        fading = step
        main.post(step)
    }

    /** Re-checks the schedule twice a minute. Cheap, and never drifts. */
    private val scheduleTick = object : Runnable {
        override fun run() {
            applySchedule()
            main.postDelayed(this, 30_000)
        }
    }

    // ---------- Night sound ----------
    //
    // Quiet passages are the problem at night, not loud ones. Turning the
    // volume down makes the quiet parts inaudible long before it makes the
    // loud parts acceptable — so instead the dynamic range is squeezed,
    // which lifts the quiet and caps the loud.

    private var compressor: android.media.audiofx.DynamicsProcessing? = null

    val nightCompression: Boolean get() = prefs.getBoolean("nightCompression", true)

    /**
     * Turn night compression on or off to match the clock.
     *
     * DynamicsProcessing is API 28+. On older Fire OS this does nothing and
     * the lower night volume carries the job alone — worse, but not broken,
     * and not worth a second implementation.
     */
    private fun applyCompression() {
        val want = nightCompression && isNight()

        if (!want) {
            compressor?.let {
                try { it.enabled = false; it.release() } catch (e: Exception) {}
            }
            compressor = null
            return
        }
        if (compressor != null) return
        if (Build.VERSION.SDK_INT < 28) return

        try {
            val sessionId = player.audioSessionId
            if (sessionId == C.AUDIO_SESSION_ID_UNSET) return

            val config = android.media.audiofx.DynamicsProcessing.Config.Builder(
                android.media.audiofx.DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2,                       // channels
                false, 0,                // pre-EQ: not wanted
                true, 1,                 // one multiband compressor stage
                false, 0,                // post-EQ: not wanted
                true                     // limiter, to catch the peaks
            ).build()

            compressor = android.media.audiofx.DynamicsProcessing(0, sessionId, config).apply {
                enabled = true
            }
        } catch (e: Exception) {
            // Some Fire OS builds refuse the effect outright. Losing
            // compression is a shame; crashing the music is not acceptable.
            compressor = null
        }
    }

    /**
     * Ease the volume up as the night window ends.
     *
     * Jumping from 35% to 100% at exactly 07:00 is an unpleasant way to be
     * woken. Within the last stretch of the window the level is interpolated
     * instead, so the room brightens over minutes.
     */
    private fun wakeFactor(): Float {
        if (!isNight()) return 1f
        val cal = Calendar.getInstance()
        val minsNow = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val endMins = nightEnd * 60

        // Minutes until the window closes, allowing for the wrap past midnight.
        var until = endMins - minsNow
        if (until < 0) until += 24 * 60
        if (until > WAKE_MINUTES) return 0f

        return ((WAKE_MINUTES - until).toFloat() / WAKE_MINUTES).coerceIn(0f, 1f)
    }

    // ---------- Storage ----------

    /** Bytes still writable in the music folder. */
    fun freeBytes(): Long = try { musicDir.usableSpace } catch (e: Exception) { 0L }

    /** Bytes the library currently occupies. */
    fun usedBytes(): Long = songFiles().sumOf { it.length() }

    // ---------- Pairing PIN ----------
    //
    // The upload server accepts anything on the local network, so without
    // this anyone on the wifi could delete the whole library with one
    // request. The PIN is shown on the TV screen: if you can see the screen,
    // you are allowed to control it.

    fun pin(): String {
        prefs.getString("pin", null)?.let { return it }
        val fresh = (1000..9999).random().toString()
        prefs.edit().putString("pin", fresh).apply()
        return fresh
    }

    fun checkPin(candidate: String?): Boolean = candidate != null && candidate == pin()

    fun settingsJson(): String = JSONObject()
        .put("dayVolume", dayVolume)
        .put("nightVolume", nightVolume)
        .put("nightStart", nightStart)
        .put("nightEnd", nightEnd)
        .put("nightDim", nightDim)
        .put("nightEnabled", nightEnabled)
        .put("isNight", isNight())
        .put("sleepAt", sleepAt)
        .put("leveling", levelingEnabled)
        .put("nightCompression", nightCompression)
        .put("skipSilence", player.skipSilenceEnabled)
        .put("autoLyrics", autoLyrics)
        .put("freeBytes", freeBytes())
        .put("usedBytes", usedBytes())
        .toString()

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("playback", "Playback", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = NotificationCompat.Builder(this, "playback")
            .setContentTitle("WallTunes")
            .setContentText("Playing music")
            .setSmallIcon(R.drawable.ic_note)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
    }

    companion object {
        const val PORT = 8080

        /**
         * Never attenuate past this.
         *
         * A badly tagged file claiming -40dB would otherwise be inaudible,
         * and a silent song looks like a broken app rather than a bad tag.
         */
        private const val MIN_GAIN = 0.25f

        /** How long before the night window ends the volume starts rising. */
        private const val WAKE_MINUTES = 20

        /**
         * How long a recorded lyric miss stands before trying again.
         *
         * The database grows as people contribute to it, so a miss is
         * "not yet" rather than "never" — but two weeks is long enough
         * that a library of obscure tracks is not re-asking constantly.
         */
        private const val MISS_RETRY_MS = 14L * 24 * 60 * 60 * 1000

        /** Pause between lookups, so a sweep trickles rather than floods. */
        private const val LYRIC_GAP_MS = 700L

        /** Grace period after boot before the lyric sweep starts. */
        private const val SWEEP_DELAY_MS = 20_000L

        /**
         * Tries before a song is left alone for a while.
         *
         * Three is enough to ride out a router rebooting or wifi coming up
         * late, and few enough that a genuinely unreachable service stops
         * pretending to be busy within a minute.
         */
        private const val MAX_FAILS = 3

        /**
         * How often the sweep runs again.
         *
         * Songs whose lookups failed carry a miss marker that expires, and
         * this is what comes back for them — so an evening with no internet
         * repairs itself by morning without anyone touching anything.
         */
        private const val SWEEP_REPEAT_MS = 30L * 60 * 1000

        /** Playable extensions. UploadServer validates against this too. */
        val AUDIO_TYPES = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "opus", "wav")
    }
}

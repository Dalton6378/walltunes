plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.itsdalton.walltunes"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.itsdalton.walltunes"
        minSdk = 22
        targetSdk = 34
        // Derived from the CI run number so every build is distinguishable.
        // Locally it stays 1, which is fine — Android happily reinstalls the
        // same versionCode over itself. What it will NOT do is install an
        // older versionCode over a newer one, which is why this only ever
        // goes up.
        //
        // The version is shown on the TV screen, so you can always tell which
        // build is actually running up there.
        versionCode = (System.getenv("BUILD_NUMBER") ?: "1").toInt()
        versionName = System.getenv("BUILD_NAME") ?: "2.0-dev"
    }

    // One fixed key, so every new build installs over the old one
    // and your uploaded songs survive updates.
    signingConfigs {
        create("walltunes") {
            storeFile = file("keys/walltunes.jks")
            storePassword = "walltunes"
            keyAlias = "walltunes"
            keyPassword = "walltunes"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("walltunes") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("walltunes")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.palette:palette:1.0.0")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("com.google.zxing:core:3.3.3")
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.itsdalton.walltunes"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.itsdalton.walltunes"
        minSdk = 22
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // One fixed key, so every new build installs over the old one
    // and your uploaded songs survive updates.
    signingConfigs {
        create("walltunes") {
            storeFile = file("keys/walltunes.jks")
            storePassword = "walltunes"
            keyAlias = "walltunes"
            keyPassword = "walltunes"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("walltunes") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("walltunes")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.palette:palette:1.0.0")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("com.google.zxing:core:3.3.3")
}
